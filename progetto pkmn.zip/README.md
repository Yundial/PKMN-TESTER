# PKM Tester

App per provare i propri mazzi del Gioco di Carte Collezionabili Pokémon contro un avversario virtuale.
È la "sorella" di YGO Tester, con la stessa struttura:

- **iPhone (e qualsiasi browser)**: web app pubblicata gratis su GitHub Pages, da aggiungere alla schermata Home;
- **Android**: APK compilato da GitHub Actions (contiene la stessa web app, funziona anche offline a parte le immagini).

## Cosa fa

- **Archivio mazzi**: crea, modifica, duplica, rinomina, elimina; importa ed esporta liste nel formato di
  Pokémon TCG Live / Limitless (`4 Dreepy TWM 128`), anche con nomi italiani (`8 Energia Fuoco`).
- **Ricerca carte** in italiano o inglese per nome o per **codice di stampa** (sigla + numero, es. `TWM 130`),
  con filtri incrociati: tipo, fase, regola (ex, Mega ex, Teracristal, V, Radiosi), abilità, debolezza, ritirata, PS,
  categoria degli Allenatori (Strumento, Aiuto, Stadio, Oggetto, Asso Tattico), Energie base/speciali,
  formato (Standard/Expanded), simbolo di regolamento ed espansione.
- **Regole della partita** gestite dal motore: mano iniziale e mulligan, 6 carte Premio, Attivo e Panchina,
  evoluzioni (anche con Caramella Rara), un'Energia per turno, un Aiuto e uno Stadio per turno, ritirata,
  primo turno (chi inizia non attacca e non gioca Aiuti), Debolezza e Resistenza, condizioni speciali e controllo
  Pokémon tra i turni, Pokémon-ex/V (2 premi), Mega ex/VMAX (3 premi), protezione dei Teracristal in Panchina,
  Oggetti Pokémon, Stadi, Energie speciali, fine partita per premi, Pokémon finiti o mazzo vuoto.
- **Effetti automatici**:
  - scritti a mano per le carte più giocate (Ultra Ball, Rare Candy, Iono, Professor's Research, Boss's Orders,
    Arven, Earthen Vessel, Lillie's Determination, Defiance Band, Hero's Cape, Area Zero Underdepths, Jet Energy…)
    e per tutti i Pokémon dei mazzi avversari (Dragapult ex, Raging Bolt ex, Charizard ex, Gardevoir ex,
    Mega Lucario ex, Terapagos ex, Dusknoir, Ogerpon…);
  - **interpretati dal testo** per tutte le altre carte: pesca, ricerche nel mazzo, monete, condizioni speciali,
    danni alla Panchina, cure, scarti di Energie, effetti "durante il prossimo turno", segnalini danno e simili.
- **Strumenti manuali** (pulsante ⚙ sul tavolo): per gli effetti rari che il motore non sa applicare.
  Quando una carta ha una parte non automatica, l'app lo dice e mostra il testo da applicare a mano
  (segnalini, condizioni, prendere carte dal mazzo o dagli scarti, spostare Energie, scambiare Pokémon…).
- **Avversario a 4 livelli** (Difficile e Incubo usano gli stessi mazzi):
  - *Facile*: Pikachu e amici, Fiamme di Charmander, Onde di Squirtle, Giardino di Bulbasaur, Palestra di Machop, Ombre di Gastly
  - *Medio*: Charizard ex/Pidgeot ex, Gardevoir ex, Miraidon ex/Iron Hands ex, Roaring Moon ex, Chien-Pao ex/Baxcalibur, Gholdengo ex
  - *Difficile* e *Incubo*: Dragapult ex, Raging Bolt ex/Ogerpon, Mega Lucario ex, Terapagos ex/Noctowl, Archaludon ex
  - *Incubo* prova ogni mossa possibile in simulazione fino alla fine del turno e sceglie la migliore.
- **Mazzi dell'avversario modificabili**: prima della partita puoi vederli e cambiarli; la modifica resta salvata.
- **Backup / Ripristino** di mazzi e modifiche in un file `.json`, valido sia per Android sia per iPhone.

## Pubblicare l'app (GitHub)

1. Crea un nuovo repository su GitHub (pubblico, così GitHub Pages è gratuito).
2. Carica il file **`progetto.zip`** così com'è (Add file → Upload files).
3. Crea il file del workflow: Add file → Create new file, nome `.github/workflows/build.yml`,
   e incolla il contenuto di `build.yml`. Salva (Commit).
4. Vai in **Settings → Pages → Source: GitHub Actions**.
5. Scheda **Actions** → *Compila APK e sito*: se non è partito da solo, *Run workflow*.
   - il primo passaggio scarica tutte le carte da TCGdex (circa 10 minuti la prima volta, poi molto meno);
   - **APK**: in fondo alla pagina dell'esecuzione, artefatto **PKM-Tester-APK** (scompatta lo zip e installa l'APK);
   - **iPhone**: il sito sarà su `https://<utente>.github.io/<repo>/`. Aprilo con Safari → Condividi → Aggiungi alla schermata Home.

Il workflow riparte da solo ogni lunedì per aggiungere le carte delle nuove espansioni.
L'APK è firmato sempre con la stessa chiave (`keystore/`), quindi gli aggiornamenti si installano sopra.

Il job *prova* fa giocare i bot tra loro con tutti i mazzi avversari e i dati veri: se qualcosa si blocca, diventa rosso.

## Modificare i mazzi dell'avversario

I mazzi di partenza sono in `tools/bot_decks.txt` (formato lista, nomi inglesi, sigla e numero facoltativi).
Basta cambiarli lì e ricaricare il progetto; oppure modificarli direttamente nell'app (restano salvati sul telefono).

## Struttura

```
web/                      la web app (HTML/CSS/JavaScript senza librerie)
  js/engine/core.js       regole: turni, attacchi, danni, KO, premi, condizioni
  js/engine/effects.js    effetti scritti a mano (Allenatori, Oggetti, Stadi, Energie, abilità, attacchi)
  js/engine/textfx.js     interprete dei testi delle carte
  js/engine/bot.js        avversario virtuale (4 livelli)
  js/ui_*.js              schermate (mazzi, editor, partita, strumenti manuali)
app/                      app Android (WebView che apre la web app inclusa nell'APK)
tools/build_data.py       scarica le carte da TCGdex (inglese + italiano) e risolve i mazzi avversari
tools/bot_decks.txt       mazzi dell'avversario
tools/test_engine.mjs     partite bot contro bot per verificare il motore
tools/make_fixture.mjs    piccolo database finto per provare il motore senza rete
```

Prova in locale senza rete: `node tools/make_fixture.mjs f.json && python3 tools/build_data.py --out web/data --fixture f.json && node tools/test_engine.mjs web/data`.

## Note

- Dati e immagini delle carte: [TCGdex](https://tcgdex.dev). Dove manca l'immagine italiana si usa quella inglese.
- I nomi delle carte in partita sono in italiano quando TCGdex li ha; la logica degli effetti usa il testo inglese.
- Pokémon e i nomi delle carte sono marchi dei rispettivi proprietari: app non ufficiale, per uso personale.
