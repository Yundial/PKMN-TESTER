plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.yundial.pkmtester"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.yundial.pkmtester"
        minSdk = 26
        targetSdk = 34
        // il numero di versione arriva da GitHub Actions, così ogni APK si installa sopra il precedente
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    signingConfigs {
        create("tester") {
            storeFile = rootProject.file("keystore/pkmtester.jks")
            storePassword = "pkmtester"
            keyAlias = "pkmtester"
            keyPassword = "pkmtester"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("tester")
        }
        debug {
            signingConfig = signingConfigs.getByName("tester")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.webkit:webkit:1.11.0")
}
