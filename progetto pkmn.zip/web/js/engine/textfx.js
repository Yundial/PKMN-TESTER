// Interprete dei testi delle carte (in inglese, dai dati TCGdex): riconosce le frasi più comuni
// degli effetti e le trasforma in operazioni del motore. Le frasi non riconosciute finiscono in `unknown`
// e in partita vengono segnalate al giocatore, che può applicarle con gli strumenti manuali.
import { isBasicPokemon, isPokemon, isTrainer, isEnergy, isBasicEnergy, isSupporter, isItem, isStadium, isTool, isEvolution,
  energyTypeOfName, TYPES, isPokemonEx, isPokemonV, hasRuleBox } from './core.js';

const NUM = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10 };
const num = s => s == null ? 1 : (NUM[s] ?? (parseInt(s, 10) || 1));
const CONDS = { asleep: 'asleep', burned: 'burned', confused: 'confused', paralyzed: 'paralyzed', poisoned: 'poisoned' };
const typeWord = w => TYPES.find(t => t.toLowerCase() === (w || '').trim().toLowerCase()) || null;

export function normText(t) {
  return (t || '').replace(/Pokémon/g, 'Pokemon').replace(/[’‘]/g, "'").replace(/[“”]/g, '"').replace(/\s+/g, ' ')
    .replace(/\{([GRWLPFDMYCN])\}/g, (_, x) => ({ G: 'Grass', R: 'Fire', W: 'Water', L: 'Lightning', P: 'Psychic', F: 'Fighting', D: 'Darkness', M: 'Metal', Y: 'Fairy', C: 'Colorless', N: 'Dragon' })[x] + ' ')
    .replace(/\s+/g, ' ').trim().toLowerCase();
}

// ------------------------------------------------------------------ filtri per le carte ("basic pokemon", "fire energy card"...)
export function cardFilter(phrase) {
  let p = (phrase || '').trim().replace(/^any\s+/, '').replace(/\s*\(.*?\)\s*/g, ' ').replace(/,$/, '').trim();
  const sing = p.replace(/\bcards\b/, 'card').replace(/\bpokemons?\b/, 'pokemon');
  let m;
  if (/^cards?$/.test(sing)) return { f: () => true, label: 'carta' };
  if (/^basic pokemon$/.test(sing)) return { f: c => isBasicPokemon(c), label: 'Pokémon Base' };
  if (/^pokemon$/.test(sing)) return { f: c => isPokemon(c), label: 'Pokémon' };
  if (/^evolution pokemon$/.test(sing)) return { f: c => isEvolution(c), label: 'Pokémon Evoluzione' };
  if ((m = sing.match(/^basic (\w+) pokemon$/)) && typeWord(m[1])) { const t = typeWord(m[1]); return { f: c => isBasicPokemon(c) && c.t?.includes(t), label: `Pokémon Base ${t}` }; }
  if ((m = sing.match(/^(\w+) pokemon$/)) && typeWord(m[1])) { const t = typeWord(m[1]); return { f: c => isPokemon(c) && c.t?.includes(t), label: `Pokémon ${t}` }; }
  if ((m = sing.match(/^pokemon with (\d+) hp or less$/))) { const h = +m[1]; return { f: c => isPokemon(c) && c.hp <= h, label: `Pokémon con ${h} PS o meno` }; }
  if ((m = sing.match(/^basic pokemon with (\d+) hp or less$/))) { const h = +m[1]; return { f: c => isBasicPokemon(c) && c.hp <= h, label: `Pokémon Base con ${h} PS o meno` }; }
  if (/^basic energy( card)?$/.test(sing)) return { f: c => isBasicEnergy(c), label: 'Energia base' };
  if ((m = sing.match(/^basic (\w+) energy( card)?$/)) && typeWord(m[1])) { const t = typeWord(m[1]); return { f: c => isBasicEnergy(c) && energyTypeOfName(c.e) === t, label: `Energia ${t} base` }; }
  if ((m = sing.match(/^(\w+) energy( card)?$/)) && typeWord(m[1])) { const t = typeWord(m[1]); return { f: c => isBasicEnergy(c) && energyTypeOfName(c.e) === t, label: `Energia ${t}` }; }
  if (/^energy( card)?$/.test(sing)) return { f: c => isEnergy(c), label: 'Energia' };
  if (/^trainer( card)?$/.test(sing)) return { f: c => isTrainer(c), label: 'Allenatore' };
  if (/^item( card)?$/.test(sing)) return { f: c => isItem(c), label: 'Strumento' };
  if (/^supporter( card)?$/.test(sing)) return { f: c => isSupporter(c), label: 'Aiuto' };
  if (/^stadium( card)?$/.test(sing)) return { f: c => isStadium(c), label: 'Stadio' };
  if (/^pokemon tool( card)?$/.test(sing)) return { f: c => isTool(c), label: 'Oggetto Pokémon' };
  if (/^pokemon and\/or basic energy( card)?$/.test(sing) || /^pokemon and basic energy( card)?$/.test(sing)) return { f: c => isPokemon(c) || isBasicEnergy(c), label: 'Pokémon o Energia base' };
  if (/^pokemon or basic energy( card)?$/.test(sing)) return { f: c => isPokemon(c) || isBasicEnergy(c), label: 'Pokémon o Energia base' };
  return null;
}

// ------------------------------------------------------------------ operazioni comuni (usate anche dalla libreria)
export const H = {
  /** Cerca nel mazzo: sceglie fino a max carte che soddisfano f e le sposta in "to" */
  async search(g, pl, f, { max = 1, min = 0, to = 'hand', title = 'Cerca nel mazzo', purpose = 'search', shuffle = true, attachTo = null } = {}) {
    const p = g.P(pl);
    const cand = p.deck.filter(u => f(g.card(u), u));
    let space = to === 'bench' ? g.benchSize(pl) - p.bench.length : Infinity;
    const lim = Math.min(max, space);
    let picked = [];
    if (lim > 0 && cand.length) picked = await g.choose(pl, { t: 'cards', uids: cand, min: Math.min(min, cand.length), max: lim, title, purpose, from: 'deck', to, always: true, fullDeck: p.deck });
    else if (!g.sim && g.agents[pl].reveal) await g.agents[pl].reveal(g, pl, { title: title + ' — nessuna carta valida', uids: [...p.deck] });
    for (const u of picked) {
      if (to === 'hand') g.moveTo(u, 'hand', pl);
      else if (to === 'bench') { g.removeFromZones(u); p.bench.push(g.newSlot(u, pl)); g.log(`${p.name} mette in Panchina ${g.nameOf(u)}`); }
      else if (to === 'discard') g.moveTo(u, 'discard', pl);
      else if (to === 'top') { g.removeFromZones(u); }
    }
    if (picked.length && to === 'hand') g.log(`${p.name} prende dal mazzo: ${picked.map(u => g.nameOf(u)).join(', ')}`);
    if (shuffle) g.shuffleDeck(pl);
    if (to === 'top') for (const u of picked) p.deck.push(u);
    if (attachTo && picked.length) await attachTo(picked);
    return picked;
  },
  async fromDiscard(g, pl, f, { max = 1, min = 0, to = 'hand', title = 'Scegli dagli scarti', purpose = 'recover' } = {}) {
    const p = g.P(pl);
    const cand = p.discard.filter(u => f(g.card(u), u));
    if (!cand.length) return [];
    const picked = await g.choose(pl, { t: 'cards', uids: cand, min: Math.min(min, cand.length), max: Math.min(max, cand.length), title, purpose, from: 'discard', always: true });
    if (to === 'deck') g.shuffleInto(pl, picked);
    else for (const u of picked) g.moveTo(u, to, pl);
    if (picked.length) g.log(`${p.name} recupera dagli scarti: ${picked.map(u => g.nameOf(u)).join(', ')}`);
    return picked;
  },
  async discardFromHand(g, pl, n, { f = () => true, exclude = null, title = 'Scegli le carte da scartare', purpose = 'discardCost', min = n } = {}) {
    const p = g.P(pl);
    const cand = p.hand.filter(u => u !== exclude && f(g.card(u), u));
    const picked = await g.choose(pl, { t: 'cards', uids: cand, min: Math.min(min, cand.length), max: Math.min(n, cand.length), title, purpose, from: 'hand', always: true });
    for (const u of picked) g.discardCard(u);
    if (picked.length) g.log(`${p.name} scarta ${picked.map(u => g.nameOf(u)).join(', ')}`);
    return picked;
  },
  async drawUntil(g, pl, n) { const k = n - g.P(pl).hand.length; if (k > 0) g.draw(pl, k); },
  async shuffleHandDraw(g, pl, n, bottom = false) {
    const p = g.P(pl);
    const hand = [...p.hand];
    if (bottom) { g.shuffle(hand); for (const u of hand) { g.removeFromZones(u); p.deck.unshift(u); } }
    else g.shuffleInto(pl, hand);
    g.draw(pl, n);
  },
  /** Distribuisce n Energie (carte) sui Pokémon scelti */
  async attachEach(g, pl, uids, slots, { title = 'A quale Pokémon assegni questa Energia?', purpose = 'attachTarget' } = {}) {
    for (const u of uids) {
      const ok = slots.filter(sl => g.slots(pl).includes(sl));
      if (!ok.length) break;
      const [sl] = await g.chooseSlot(pl, ok, `${title} (${g.nameOf(u)})`, purpose, { energy: u });
      if (sl) await g.attachEnergy(u, sl);
    }
  },
  /** Mette n segnalini danno distribuiti a scelta sui Pokémon indicati */
  async distribute(g, pl, ctx, slots, n, { title = 'Distribuisci i segnalini danno', purpose = 'distribute', counters = true } = {}) {
    if (!slots.length || n <= 0) return;
    const res = await g.choose(pl, { t: 'dist', sids: slots.map(s => s.sid), total: n, title, purpose });
    for (const [sid, k] of Object.entries(res || {})) {
      const sl = g.slot(sid);
      if (sl && k > 0) await g.placeCounters(ctx, sl, k);
    }
  },
  async discardEnergyFrom(g, pl, sl, n, { type = null, title = 'Scegli le Energie da scartare', purpose = 'discardOwnEnergy', chooser = pl } = {}) {
    const cand = g.energyCards(sl, type);
    if (!cand.length) return [];
    const picked = cand.length <= n ? cand : await g.choose(chooser, { t: 'cards', uids: cand, min: n, max: n, title, purpose, sid: sl.sid, always: true });
    for (const u of picked) g.discardCard(u);
    if (picked.length) g.log(`Scartate ${picked.length} Energie da ${g.slotName(sl)}`);
    return picked;
  },
  isTurnOf(g, pl) { return g.s.cur === pl; },
};

// ------------------------------------------------------------------ conteggi ("for each ...")
function counter(phrase) {
  const p = phrase.replace(/\.$/, '').trim();
  let m;
  if ((m = p.match(/^(?:(\w+) )?energy attached to (this pokemon|your opponent's active pokemon|both active pokemon|all of your pokemon|the defending pokemon)$/))) {
    const t = typeWord(m[1]);
    const cnt = (g, sl) => sl ? g.provided(sl).filter(x => !t || x === t || x === 'ANY').length : 0;
    const who = m[2];
    return (g, c) => who === 'this pokemon' ? cnt(g, c.attacker) : who.startsWith('both') ? cnt(g, c.attacker) + cnt(g, g.P(c.opp).active)
      : who.startsWith('all') ? g.slots(c.pl).reduce((s, x) => s + cnt(g, x), 0) : cnt(g, g.P(c.opp).active);
  }
  if (/^of your benched pokemon$/.test(p)) return (g, c) => g.P(c.pl).bench.length;
  if (/^of your opponent's benched pokemon$/.test(p)) return (g, c) => g.P(c.opp).bench.length;
  if (/^benched pokemon \(both yours and your opponent's\)$/.test(p) || /^benched pokemon$/.test(p)) return (g, c) => g.P(c.pl).bench.length + g.P(c.opp).bench.length;
  if (/^of your pokemon in play$/.test(p)) return (g, c) => g.slots(c.pl).length;
  if ((m = p.match(/^of your (\w+) pokemon in play$/)) && typeWord(m[1])) { const t = typeWord(m[1]); return (g, c) => g.slots(c.pl).filter(s => g.hasType(s, t)).length; }
  if (/^damage counter on this pokemon$/.test(p)) return (g, c) => Math.floor(c.attacker.dmg / 10);
  if (/^damage counter on your opponent's active pokemon$/.test(p) || /^damage counter on the defending pokemon$/.test(p)) return (g, c) => Math.floor((g.P(c.opp).active?.dmg || 0) / 10);
  if (/^prize card your opponent has taken$/.test(p)) return (g, c) => 6 - g.P(c.opp).prizes.length;
  if (/^prize card you have taken$/.test(p)) return (g, c) => 6 - g.P(c.pl).prizes.length;
  if (/^card in your hand$/.test(p)) return (g, c) => g.P(c.pl).hand.length;
  if (/^card in your opponent's hand$/.test(p)) return (g, c) => g.P(c.opp).hand.length;
  if ((m = p.match(/^(?:(\w+) )?pokemon in your discard pile$/))) { const t = typeWord(m[1]); return (g, c) => g.P(c.pl).discard.filter(u => isPokemon(g.card(u)) && (!t || g.card(u).t?.includes(t))).length; }
  if (/^energy in your opponent's active pokemon's retreat cost$/.test(p)) return (g, c) => g.P(c.opp).active ? g.retreatCost(g.P(c.opp).active) : 0;
  if (/^of your opponent's pokemon ex in play$/.test(p)) return (g, c) => g.slots(c.opp).filter(s => g.isEx(s)).length;
  return null;
}

// ------------------------------------------------------------------ bersagli
function targetsOf(phrase) {
  const p = phrase.trim();
  if (/^your opponent's active pokemon$|^the defending pokemon$/.test(p)) return { kind: 'oppActive' };
  if (/^1 of your opponent's benched pokemon$/.test(p)) return { kind: 'oppBench1' };
  if (/^1 of your opponent's pokemon$/.test(p)) return { kind: 'opp1' };
  if (/^each of your opponent's benched pokemon$/.test(p)) return { kind: 'oppBenchAll' };
  if (/^each of your opponent's pokemon$/.test(p)) return { kind: 'oppAll' };
  if (/^1 of your benched pokemon$/.test(p)) return { kind: 'ownBench1' };
  if (/^each of your benched pokemon$/.test(p)) return { kind: 'ownBenchAll' };
  if (/^this pokemon$/.test(p)) return { kind: 'self' };
  if (/^1 of your pokemon$/.test(p)) return { kind: 'own1' };
  if (/^each of your pokemon$/.test(p)) return { kind: 'ownAll' };
  if (/^your active pokemon$/.test(p)) return { kind: 'ownActive' };
  return null;
}
async function pickTargets(g, c, tg, title, purpose) {
  const opp = g.P(c.opp), me = g.P(c.pl);
  switch (tg.kind) {
    case 'oppActive': return opp.active ? [opp.active] : [];
    case 'oppBench1': return opp.bench.length ? g.chooseSlot(c.pl, opp.bench, title, purpose) : [];
    case 'opp1': return g.slots(c.opp).length ? g.chooseSlot(c.pl, g.slots(c.opp), title, purpose) : [];
    case 'oppBenchAll': return [...opp.bench];
    case 'oppAll': return g.slots(c.opp);
    case 'ownBench1': return me.bench.length ? g.chooseSlot(c.pl, me.bench, title, purpose === 'damageTarget' ? 'selfDamageTarget' : purpose) : [];
    case 'ownBenchAll': return [...me.bench];
    case 'self': return c.attacker ? [c.attacker] : c.source ? [c.source] : [];
    case 'own1': return g.chooseSlot(c.pl, g.slots(c.pl), title, purpose);
    case 'ownAll': return g.slots(c.pl);
    case 'ownActive': return me.active ? [me.active] : [];
  }
  return [];
}

// ------------------------------------------------------------------ condizioni ("if ...")
function condition(phrase) {
  const p = phrase.trim();
  let m;
  if (/^your opponent's active pokemon is a pokemon ex$/.test(p)) return (g, c) => !!g.P(c.opp).active && g.isEx(g.P(c.opp).active);
  if (/^your opponent's active pokemon is a pokemon v$/.test(p)) return (g, c) => !!g.P(c.opp).active && g.isV(g.P(c.opp).active);
  if (/^your opponent's active pokemon is a pokemon ex or pokemon v$|^your opponent's active pokemon is a pokemon v or pokemon ex$/.test(p)) return (g, c) => !!g.P(c.opp).active && (g.isEx(g.P(c.opp).active) || g.isV(g.P(c.opp).active));
  if (/^your opponent's active pokemon has an ability$/.test(p)) return (g, c) => !!g.top(g.P(c.opp).active || { cards: [] })?.b?.length;
  if ((m = p.match(/^your opponent's active pokemon is (asleep|burned|confused|paralyzed|poisoned)$/))) return (g, c) => { const a = g.P(c.opp).active; return !!a && !!a.cond[m[1]]; };
  if (/^your opponent's active pokemon is affected by a special condition$/.test(p)) return (g, c) => { const a = g.P(c.opp).active; return !!a && Object.entries(a.cond).some(([k, v]) => k !== 'paraTurn' && v); };
  if (/^your opponent's active pokemon has any damage counters on it$|^the defending pokemon has any damage counters on it$/.test(p)) return (g, c) => (g.P(c.opp).active?.dmg || 0) > 0;
  if (/^this pokemon has any damage counters on it$/.test(p)) return (g, c) => (c.attacker || c.source)?.dmg > 0;
  if (/^this pokemon has no damage counters on it$/.test(p)) return (g, c) => !((c.attacker || c.source)?.dmg > 0);
  if (/^your opponent's active pokemon is an evolution pokemon$/.test(p)) return (g, c) => !!g.P(c.opp).active && g.isEvolved(g.P(c.opp).active);
  if (/^your opponent's active pokemon is a basic pokemon$/.test(p)) return (g, c) => !!g.P(c.opp).active && !g.isEvolved(g.P(c.opp).active);
  if ((m = p.match(/^you have (\d+) or more cards in your hand$/))) return (g, c) => g.P(c.pl).hand.length >= +m[1];
  if ((m = p.match(/^your opponent has (\d+) or fewer prize cards remaining$/))) return (g, c) => g.P(c.opp).prizes.length <= +m[1];
  if ((m = p.match(/^you have (\d+) or fewer prize cards remaining$/))) return (g, c) => g.P(c.pl).prizes.length <= +m[1];
  if ((m = p.match(/^you have (?:a |an )?(.+?) in play$/))) { const n = m[1]; return (g, c) => g.slots(c.pl).some(s => normText(g.top(s).e) === n); }
  if ((m = p.match(/^you don't have (?:a |an )?(.+?) on your bench$/))) { const n = m[1]; return (g, c) => !g.P(c.pl).bench.some(s => normText(g.top(s).e) === n); }
  if ((m = p.match(/^you have (?:a |an )?(.+?) on your bench$/))) { const n = m[1]; return (g, c) => g.P(c.pl).bench.some(s => normText(g.top(s).e) === n); }
  if ((m = p.match(/^this pokemon has (?:at least )?(\d+) extra energy attached$/))) return (g, c) => g.energyCount(c.attacker) - (c.atk?.c?.length || 0) >= +m[1];
  if (/^any of your pokemon were knocked out by damage from an attack during your opponent's last turn$/.test(p)) return (g, c) => g.s.tf.koByOpp;
  if (/^there is a stadium in play$/.test(p)) return g => !!g.s.stadium;
  return null;
}

// ------------------------------------------------------------------ singole frasi -> operazione
// Ogni regola: re (ancorata all'inizio), phase: 'before'|'after', make(m) -> async (g, ctx)
const RULES = [];
const R = (re, phase, make) => RULES.push({ re, phase, make });

R(/^this attack does nothing/, 'before', () => async (g, c) => { c.skip = true; c.damage = 0; });
R(/^this attack does (\d+) more damage/, 'before', m => async (g, c) => { c.damage += +m[1]; });
R(/^this attack does (\d+) less damage/, 'before', m => async (g, c) => { c.damage = Math.max(0, c.damage - +m[1]); });
R(/^this attack does (\d+) (more )?damage for each (.+?)$/, 'before', m => {
  const cnt = counter(m[3]);
  if (!cnt) return null;
  return async (g, c) => { const k = cnt(g, c); if (m[2]) c.damage += +m[1] * k; else c.damage = +m[1] * k; };
});
R(/^this attack does (\d+) (?:more )?damage to (1 of your opponent's benched pokemon|1 of your opponent's pokemon|each of your opponent's benched pokemon|each of your opponent's pokemon|1 of your benched pokemon|each of your benched pokemon)$/, 'after', m => {
  const tg = targetsOf(m[2]);
  return async (g, c) => {
    for (const t of await pickTargets(g, c, tg, `Scegli il Pokémon che subisce ${m[1]} danni`, 'damageTarget')) {
      if (g.isActive(t) && t.owner === c.opp) await g.applyDamage(c, t, g.computeDamage(c, t, +m[1], true));
      else await g.benchDamage(c, t, +m[1]);
    }
  };
});
R(/^this attack also does (\d+) damage to (.+?)$/, 'after', m => {
  const tg = targetsOf(m[2]);
  if (!tg) return null;
  return async (g, c) => { for (const t of await pickTargets(g, c, tg, `Scegli il Pokémon che subisce ${m[1]} danni`, 'damageTarget')) await g.benchDamage(c, t, +m[1]); };
});
R(/^\(don't apply weakness and resistance for benched pokemon\.?\)/, 'after', () => async () => {});
R(/^this pokemon also does (\d+) damage to itself/, 'after', m => async (g, c) => { await g.applyDamage(c, c.attacker, +m[1]); });
R(/^this attack's damage isn't affected by weakness or resistance(?:,? or by any effects on your opponent's active pokemon)?/, 'before', m => async (g, c) => { c.noWR = true; if (/effects/.test(m[0])) c.ignoreEffects = true; });
R(/^this attack's damage isn't affected by resistance/, 'before', () => async (g, c) => { c.noR = true; });
R(/^this attack's damage isn't affected by weakness/, 'before', () => async (g, c) => { c.noW = true; });
R(/^this attack's damage isn't affected by any effects on your opponent's active pokemon/, 'before', () => async (g, c) => { c.ignoreEffects = true; });
// condizioni speciali
R(/^(?:your opponent's active pokemon|the defending pokemon) is now (asleep|burned|confused|paralyzed|poisoned)(?:,? and (asleep|burned|confused|paralyzed|poisoned))?/, 'after', m => async (g, c) => {
  const a = g.P(c.opp).active; g.setCondition(a, m[1]); if (m[2]) g.setCondition(a, m[2]);
});
R(/^this pokemon is now (asleep|burned|confused|paralyzed|poisoned)/, 'after', m => async (g, c) => { g.setCondition(c.attacker, m[1]); });
R(/^put (\d+|\w+) damage counters? instead of 1 on that pokemon for poison/, 'after', m => async (g, c) => { const a = g.P(c.opp).active; if (a?.cond.poisoned) a.cond.poisoned = num(m[1]); });
R(/^this pokemon recovers from all special conditions/, 'after', () => async (g, c) => { g.clearConditions(c.attacker || c.source); });
// Energie
R(/^discard (an|a|1|2|3|4|\d+|all) (?:(\w+) )?energy(?: cards?)? from this pokemon/, 'after', m => async (g, c) => {
  const sl = c.attacker || c.source;
  const t = typeWord(m[2]);
  if (m[1] === 'all') { for (const u of g.energyCards(sl, t)) g.discardCard(u); g.log(`Scartate tutte le Energie${t ? ' ' + t : ''} da ${g.slotName(sl)}`); }
  else await H.discardEnergyFrom(g, c.pl, sl, num(m[1]), { type: t, purpose: 'discardOwnEnergy' });
});
R(/^discard (an|a|1|2|all) energy from (?:your opponent's active pokemon|the defending pokemon)/, 'after', m => async (g, c) => {
  const a = g.P(c.opp).active; if (!a) return;
  if (m[1] === 'all') for (const u of [...a.energy]) g.discardCard(u);
  else await H.discardEnergyFrom(g, c.pl, a, num(m[1]), { purpose: 'discardOppEnergy', title: "Scegli l'Energia dell'avversario da scartare" });
});
R(/^(?:you may )?attach (?:a|an|1|up to (\d+)) basic (?:(\w+) )?energy(?: cards?)? from your (discard pile|hand) to (this pokemon|1 of your pokemon|1 of your benched pokemon|your pokemon in any way you like|your benched pokemon in any way you like|1 of your benched (\w+) pokemon|1 of your (\w+) pokemon)/, 'after', m => async (g, c) => {
  const t = typeWord(m[2]);
  const n = m[1] ? +m[1] : 1;
  const zone = m[3] === 'hand' ? 'hand' : 'discard';
  const p = g.P(c.pl);
  const cand = p[zone].filter(u => isBasicEnergy(g.card(u)) && (!t || energyTypeOfName(g.card(u).e) === t));
  if (!cand.length) return;
  const picked = await g.choose(c.pl, { t: 'cards', uids: cand, min: 0, max: Math.min(n, cand.length), title: 'Scegli le Energie da assegnare', purpose: 'attachPick', from: zone, always: true });
  const self = c.attacker || c.source;
  const typ = typeWord(m[5] || m[6]);
  let slots = m[4] === 'this pokemon' ? [self] : /benched/.test(m[4]) ? p.bench : g.slots(c.pl);
  if (typ) slots = slots.filter(s => g.hasType(s, typ));
  await H.attachEach(g, c.pl, picked, slots);
});
// cure
R(/^heal (\d+) damage from (this pokemon|1 of your pokemon|each of your pokemon|each of your benched pokemon|your active pokemon|1 of your benched pokemon)/, 'after', m => {
  const tg = targetsOf(m[2]);
  return async (g, c) => { for (const t of await pickTargets(g, c, tg, 'Quale Pokémon curi?', 'healTarget')) g.heal(t, +m[1]); };
});
R(/^heal all damage from this pokemon/, 'after', () => async (g, c) => { g.heal(c.attacker || c.source, 9999); });
R(/^heal from this pokemon the same amount of damage you did to your opponent's active pokemon/, 'after', () => async (g, c) => { g.heal(c.attacker, c.dealt); });
// pescare
R(/^draw (\d+|a|an|one|two|three|four|five|six|seven) cards?/, 'after', m => async (g, c) => { g.draw(c.pl, num(m[1])); });
R(/^draw cards until you have (\d+) cards in your hand/, 'after', m => async (g, c) => { await H.drawUntil(g, c.pl, +m[1]); });
R(/^shuffle your hand into your deck/, 'after', () => async (g, c) => { g.shuffleInto(c.pl, [...g.P(c.pl).hand]); });
R(/^discard your hand(?:,)? and draw (\d+) cards/, 'after', m => async (g, c) => { const p = g.P(c.pl); for (const u of [...p.hand]) g.discardCard(u); g.draw(c.pl, +m[1]); });
R(/^each player shuffles their hand into their deck and draws (\d+) cards/, 'after', m => async (g, c) => { for (const x of [c.pl, c.opp]) await H.shuffleHandDraw(g, x, +m[1]); });
R(/^your opponent shuffles their hand into their deck and draws (\d+) cards/, 'after', m => async (g, c) => { await H.shuffleHandDraw(g, c.opp, +m[1]); });
// ricerche
R(/^search your deck for (up to (\w+)|a|an|1|\w+) (.+?),? (?:reveal (?:it|them),? )?(?:and )?put (?:it|them) (into your hand|onto your bench|on your bench)/, 'after', m => {
  const flt = cardFilter(m[3]);
  if (!flt) return null;
  const n = m[2] ? num(m[2]) : num(m[1]);
  const to = /bench/.test(m[4]) ? 'bench' : 'hand';
  return async (g, c) => {
    const f = to === 'bench' ? (x => flt.f(x) && isBasicPokemon(x)) : flt.f;
    await H.search(g, c.pl, f, { max: n, to, title: `Cerca nel mazzo: ${flt.label} (max ${n})`, purpose: to === 'bench' ? 'searchBench' : 'searchHand' });
  };
});
R(/^search your deck for (up to (\w+)|a|an|1) basic (?:(\w+) )?energy(?: cards?)? and attach (?:it|them) to (this pokemon|1 of your pokemon|your pokemon in any way you like|your benched pokemon in any way you like|1 of your benched pokemon)/, 'after', m => async (g, c) => {
  const t = typeWord(m[3]);
  const n = m[2] ? num(m[2]) : 1;
  const self = c.attacker || c.source;
  const slots = m[4] === 'this pokemon' ? [self] : /benched/.test(m[4]) ? g.P(c.pl).bench : g.slots(c.pl);
  await H.search(g, c.pl, x => isBasicEnergy(x) && (!t || energyTypeOfName(x.e) === t), { max: n, to: 'none', title: `Cerca Energie base${t ? ' ' + t : ''} da assegnare`, purpose: 'searchEnergy', attachTo: async uids => H.attachEach(g, c.pl, uids, slots) });
});
R(/^(?:then, )?shuffle your deck$/, 'after', () => async () => {});
R(/^(?:put|choose) (up to (\w+)|a|an|1|\w+) (.+?) from your discard pile (?:and put (?:it|them) )?into your hand/, 'after', m => {
  const flt = cardFilter(m[3]); if (!flt) return null;
  const n = m[2] ? num(m[2]) : num(m[1]);
  return async (g, c) => { await H.fromDiscard(g, c.pl, flt.f, { max: n, to: 'hand', title: `Scegli dagli scarti: ${flt.label}` }); };
});
R(/^shuffle (up to (\w+)|a|an|1|\w+) (.+?) from your discard pile into your deck/, 'after', m => {
  const flt = cardFilter(m[3]); if (!flt) return null;
  const n = m[2] ? num(m[2]) : num(m[1]);
  return async (g, c) => { await H.fromDiscard(g, c.pl, flt.f, { max: n, to: 'deck', title: `Rimescola nel mazzo: ${flt.label}` }); };
});
// scambi
R(/^(you may )?switch this pokemon with 1 of your benched pokemon/, 'after', m => async (g, c) => {
  if (!g.P(c.pl).bench.length) return;
  if (m[1] && !(await g.yesno(c.pl, 'Vuoi scambiare questo Pokémon con uno in Panchina?', 'switchSelf'))) return;
  await g.switchOwn(c.pl, 'switchOwn');
});
R(/^switch your active pokemon with 1 of your benched pokemon/, 'after', () => async (g, c) => { await g.switchOwn(c.pl); });
R(/^choose 1 of your opponent's benched pokemon and switch it with their active pokemon/, 'after', () => async (g, c) => { await g.gust(c.pl); });
R(/^(?:switch out your opponent's active pokemon to the bench|your opponent switches their active pokemon with 1 of their benched pokemon)/, 'after', () => async (g, c) => { await g.opponentSwitches(c.pl); });
R(/^\(your opponent chooses the new active pokemon\.?\)/, 'after', () => async () => {});
R(/^(?:before doing damage, )?(you may )?switch (?:in )?1 of your opponent's benched pokemon (?:with their active pokemon|to the active spot)/, 'before', m => async (g, c) => {
  if (m[1] && !(await g.yesno(c.pl, "Vuoi mandare in posizione attiva un Pokémon in Panchina dell'avversario?", 'gustMay'))) return;
  await g.gust(c.pl);
});
// effetti fino al prossimo turno
R(/^during your opponent's next turn, this pokemon takes (\d+) less damage from attacks(?: \(after applying weakness and resistance\))?/, 'after', m => async (g, c) => {
  g.addMark({ kind: 'reduceDamage', sid: c.attacker.sid, until: g.s.turn + 1, data: { n: +m[1] } });
});
R(/^during your opponent's next turn, prevent all (?:damage from and effects of attacks|damage done to this pokemon by attacks|effects of attacks, including damage,? done to this pokemon)(?: from (basic|evolution) pokemon| from pokemon ex| from pokemon that have an ability)?/, 'after', m => async (g, c) => {
  g.addMark({ kind: 'preventDamage', sid: c.attacker.sid, until: g.s.turn + 1, data: { from: m[1] || (/pokemon ex/.test(m[0]) ? 'ex' : /ability/.test(m[0]) ? 'ability' : null) } });
});
R(/^prevent all effects of attacks, including damage, done to this pokemon during your opponent's next turn/, 'after', () => async (g, c) => {
  g.addMark({ kind: 'preventDamage', sid: c.attacker.sid, until: g.s.turn + 1, data: {} });
});
R(/^during your opponent's next turn, (?:the defending pokemon|that pokemon) can't (attack|retreat)/, 'after', m => async (g, c) => {
  const d = g.P(c.opp).active; if (!d) return;
  g.addMark({ kind: m[1] === 'attack' ? 'noAttack' : 'noRetreat', sid: d.sid, until: g.s.turn + 1 });
});
R(/^during your next turn, this pokemon can't (attack|use (.+?))$/, 'after', m => async (g, c) => {
  g.addMark({ kind: 'noAttack', sid: c.attacker.sid, until: g.s.turn + 2, persist: true, data: m[2] ? { name: c.atk?.e } : null });
});
R(/^this pokemon can't attack during your next turn/, 'after', () => async (g, c) => { g.addMark({ kind: 'noAttack', sid: c.attacker.sid, until: g.s.turn + 2, persist: true }); });
R(/^during your opponent's next turn, (?:any )?damage done by attacks from the defending pokemon is reduced by (\d+)/, 'after', m => async (g, c) => {
  const d = g.P(c.opp).active; if (d) g.addMark({ kind: 'defenderWeaker', sid: d.sid, until: g.s.turn + 1, data: { n: +m[1] } });
});
R(/^during your opponent's next turn, the defending pokemon's attacks do (\d+) less damage/, 'after', m => async (g, c) => {
  const d = g.P(c.opp).active; if (d) g.addMark({ kind: 'defenderWeaker', sid: d.sid, until: g.s.turn + 1, data: { n: +m[1] } });
});
R(/^during your opponent's next turn, your opponent can't play any item cards from their hand/, 'after', () => async (g, c) => { g.addMark({ kind: 'itemLock', pl: c.opp, until: g.s.turn + 1 }); });
// segnalini danno
R(/^put (\d+|\w+) damage counters? on (your opponent's active pokemon|the defending pokemon|1 of your opponent's pokemon|1 of your opponent's benched pokemon|each of your opponent's pokemon|each of your opponent's benched pokemon|this pokemon)/, 'after', m => {
  const tg = targetsOf(m[2]);
  return async (g, c) => { for (const t of await pickTargets(g, c, tg, 'Su quale Pokémon metti i segnalini?', 'damageTarget')) await g.placeCounters(c, t, num(m[1])); };
});
R(/^put (\d+|\w+) damage counters on your opponent's (?:benched )?pokemon in any way you like/, 'after', m => async (g, c) => {
  const bench = /benched/.test(m[0]);
  await H.distribute(g, c.pl, c, bench ? g.P(c.opp).bench : g.slots(c.opp), num(m[1]));
});
// mazzo
R(/^discard the top (\d+ cards|card) of your opponent's deck/, 'after', m => async (g, c) => {
  const n = parseInt(m[1], 10) || 1; const d = g.P(c.opp).deck;
  for (let i = 0; i < n && d.length; i++) g.P(c.opp).discard.push(d.pop());
  g.log(`Scartate ${n} carte dalla cima del mazzo avversario`);
});
R(/^discard the top (\d+ cards|card) of your deck/, 'after', m => async (g, c) => {
  const n = parseInt(m[1], 10) || 1; const d = g.P(c.pl).deck;
  for (let i = 0; i < n && d.length; i++) g.P(c.pl).discard.push(d.pop());
});
R(/^shuffle this pokemon and all attached cards into your deck/, 'after', () => async (g, c) => {
  const sl = c.attacker || c.source; const p = g.P(c.pl);
  const cards = [...sl.cards, ...sl.energy, ...sl.tools];
  if (p.active === sl) p.active = null; else p.bench.splice(p.bench.indexOf(sl), 1);
  for (const u of cards) p.deck.push(u);
  g.shuffleDeck(c.pl);
  g.log(`${g.nameOf(cards[cards.length - 1])} torna nel mazzo`);
});
R(/^your opponent reveals their hand/, 'after', () => async () => {});

// ------------------------------------------------------------------ parser
/**
 * @returns {{ before: Function[], after: Function[], unknown: string[], costDiscard: number, mayFlip: boolean }}
 */
export function parseText(raw) {
  const text = normText(raw);
  const out = { before: [], after: [], unknown: [], costDiscard: 0, needsBench: false };
  if (!text) return out;
  let rest = text;
  // costo di alcuni Allenatori
  let m = rest.match(/^you can use this card only if you discard (\d+|\w+) other cards? from your hand\.\s*/);
  if (m) { out.costDiscard = num(m[1]); rest = rest.slice(m[0].length); }
  for (let guard = 0; rest && guard < 40; guard++) {
    rest = rest.replace(/^[\s.]+/, '');
    if (!rest) break;
    const r = parseOne(rest, out);
    if (r > 0) { rest = rest.slice(r); continue; }
    // frase non riconosciuta: salta fino al prossimo punto
    const end = sentenceEnd(rest);
    out.unknown.push(rest.slice(0, end).trim());
    rest = rest.slice(end);
  }
  return out;
}
function sentenceEnd(s) {
  let depth = 0;
  for (let i = 0; i < s.length; i++) {
    if (s[i] === '(') depth++;
    else if (s[i] === ')') depth = Math.max(0, depth - 1);
    else if (s[i] === '.' && depth === 0) return i + 1;
  }
  return s.length;
}

/** Prova a riconoscere una o più frasi all'inizio di s; restituisce i caratteri consumati (0 = niente) */
function parseOne(s, out) {
  let m;
  // monete: "flip a coin. if heads, X. if tails, Y."
  if ((m = s.match(/^flip a coin\. if (heads|tails), ([^.]+?)\.(?:\s*if (heads|tails), ([^.]+?)\.)?/))) {
    const a = clause(m[2]), b = m[4] ? clause(m[4]) : null;
    if (a && (!m[4] || b)) {
      const key = {};
      const flip = async (g, c) => { c.coins = c.coins || new Map(); if (!c.coins.has(key)) c.coins.set(key, g.flip()); return c.coins.get(key); };
      const want = m[1] === 'heads';
      const bind = (cl, onHeads) => async (g, c) => { const h = await flip(g, c); if (h === onHeads) await cl.fn(g, c); };
      out.before.push(async (g, c) => { await flip(g, c); });
      (a.phase === 'before' ? out.before : out.after).push(bind(a, want));
      if (b) (b.phase === 'before' ? out.before : out.after).push(bind(b, m[3] === 'heads'));
      return m[0].length;
    }
  }
  if ((m = s.match(/^flip (\d+|\w+) coins\. this attack does (\d+) (more )?damage for each heads\./))) {
    const n = num(m[1]), d = +m[2], more = !!m[3];
    out.before.push(async (g, c) => { let h = 0; for (let i = 0; i < n; i++) if (g.flip()) h++; c.damage = (more ? c.damage : 0) + h * d; });
    return m[0].length;
  }
  if ((m = s.match(/^flip a coin until you get tails\. this attack does (\d+) (more )?damage for each heads\./))) {
    const d = +m[1], more = !!m[2];
    out.before.push(async (g, c) => { let h = 0; while (g.flip() && h < 30) h++; c.damage = (more ? c.damage : 0) + h * d; });
    return m[0].length;
  }
  if ((m = s.match(/^flip a coin for each (.+?)\. this attack does (\d+) (more )?damage for each heads\./))) {
    const cnt = counter(m[1].replace(/^/, '')) || (/energy attached to this pokemon/.test(m[1]) ? (g, c) => g.energyCount(c.attacker) : null);
    if (cnt) {
      const d = +m[2], more = !!m[3];
      out.before.push(async (g, c) => { const n = cnt(g, c); let h = 0; for (let i = 0; i < n; i++) if (g.flip()) h++; c.damage = (more ? c.damage : 0) + h * d; });
      return m[0].length;
    }
  }
  if ((m = s.match(/^flip (\d+|\w+) coins\. if (?:both of them are heads|all of them are heads), ([^.]+?)\./))) {
    const cl = clause(m[2]); const n = num(m[1]);
    if (cl) {
      const key = {};
      out.before.push(async (g, c) => { c.coins = c.coins || new Map(); let all = true; for (let i = 0; i < n; i++) if (!g.flip()) all = false; c.coins.set(key, all); });
      (cl.phase === 'before' ? out.before : out.after).push(async (g, c) => { if (c.coins.get(key)) await cl.fn(g, c); });
      return m[0].length;
    }
  }
  // "look at the top N cards of your deck. you may reveal a X you find there and put it into your hand. shuffle the other cards back into your deck."
  if ((m = s.match(/^look at the top (\d+|\w+) cards of your deck\. you may reveal (?:a|an|up to (\w+)) (.+?) you find there(?:,)? and put (?:it|them) into your hand\. shuffle the other cards back into your deck\./))) {
    const flt = cardFilter(m[3]);
    if (flt) {
      const n = num(m[1]), k = m[2] ? num(m[2]) : 1;
      out.after.push(async (g, c) => {
        const p = g.P(c.pl); const top = p.deck.slice(-n);
        const pick = await g.choose(c.pl, { t: 'cards', uids: top.filter(u => flt.f(g.card(u))), min: 0, max: k, title: `Prime ${n} carte: prendi ${flt.label}`, purpose: 'searchHand', from: 'deck', always: true, fullDeck: top });
        for (const u of pick) g.moveTo(u, 'hand', c.pl);
        g.shuffleDeck(c.pl);
      });
      return m[0].length;
    }
  }
  // condizioni: "if X, Y."
  if ((m = s.match(/^if ([^,]+), ([^.]+?)\./))) {
    const cond = condition(m[1]); const cl = clause(m[2]);
    if (cond && cl) {
      (cl.phase === 'before' ? out.before : out.after).push(async (g, c) => { if (cond(g, c)) await cl.fn(g, c); });
      return m[0].length;
    }
  }
  // "you may X. if you do, Y."
  if ((m = s.match(/^you may ([^.]+?)\. if you do, ([^.]+?)\./))) {
    const a = clause(m[1]), b = clause(m[2]);
    if (a && b) {
      out.after.push(async (g, c) => {
        if (!(await g.yesno(c.pl, 'Vuoi applicare l\'effetto facoltativo?', 'may', m[0]))) return;
        await a.fn(g, c); await b.fn(g, c);
      });
      return m[0].length;
    }
  }
  const end = sentenceEnd(s);
  const sentence = s.slice(0, end).replace(/\.$/, '').trim();
  const cl = clause(sentence) || (sentence.startsWith('you may ') ? clause(sentence.slice(8)) : null);
  if (cl) { (cl.phase === 'before' ? out.before : out.after).push(cl.fn); return end; }
  return 0;
}

function clause(text) {
  const t = text.trim().replace(/\.$/, '').replace(/^(?:then|and),?\s+/, '');
  for (const r of RULES) {
    const m = t.match(r.re);
    if (m && m[0].length >= t.length - 1) {
      const fn = r.make(m);
      if (fn) return { phase: r.phase, fn };
    }
  }
  return null;
}

/** Quante parti del testo sono state comprese (per mostrare "effetto automatico" o "manuale") */
export function coverage(raw) { const p = parseText(raw); return { ok: !p.unknown.length, unknown: p.unknown }; }
export { condition as parseCondition, counter as parseCounter, isPokemonEx, isPokemonV, hasRuleBox };
