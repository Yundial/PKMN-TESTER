// Motore delle regole del GCC Pokémon: stato della partita, turni, attacchi, danni, KO e premi.
// Lo stato (this.s) è un oggetto semplice: si può copiare con structuredClone per le simulazioni del bot.
// Le decisioni passano dagli "agenti" (giocatore umano o bot): act() sceglie l'azione, choose() risponde alle richieste.

export const TYPES = ['Grass', 'Fire', 'Water', 'Lightning', 'Psychic', 'Fighting', 'Darkness', 'Metal', 'Fairy', 'Dragon', 'Colorless'];
export const TYPE_IT = { Grass: 'Erba', Fire: 'Fuoco', Water: 'Acqua', Lightning: 'Lampo', Psychic: 'Psico', Fighting: 'Lotta', Darkness: 'Oscurità', Metal: 'Metallo', Fairy: 'Folletto', Dragon: 'Drago', Colorless: 'Incolore', ANY: 'qualsiasi' };
export const COND_IT = { asleep: 'Addormentato', confused: 'Confuso', paralyzed: 'Paralizzato', poisoned: 'Avvelenato', burned: 'Bruciato' };

const TERA = new Set(['Dragapult ex', 'Terapagos ex', 'Teal Mask Ogerpon ex', 'Wellspring Mask Ogerpon ex', 'Hearthflame Mask Ogerpon ex',
  'Cornerstone Mask Ogerpon ex', 'Charizard ex', 'Noivern ex', 'Hydrapple ex', 'Galvantula ex', 'Sylveon ex', 'Glaceon ex', 'Leafeon ex',
  'Umbreon ex', 'Espeon ex', 'Flareon ex', 'Jolteon ex', 'Vaporeon ex', 'Pecharunt ex', 'Lapras ex', 'Bouffalant ex', 'Cinccino ex', 'Archaludon ex',
  'Hydreigon ex', 'Ceruledge ex', 'Pidgeot ex', 'Kyurem ex', 'Tatsugiri ex', 'Ursaluna ex']);
const NOT_TERA_SETS = { 'Charizard ex': ['sv03.5', 'svp', 'sv04.5x'], 'Pidgeot ex': ['sv03'], 'Lapras ex': ['sv03.5'] };
export const ANCIENT = new Set(['Raging Bolt ex', 'Raging Bolt', 'Roaring Moon ex', 'Roaring Moon', 'Great Tusk ex', 'Great Tusk', 'Walking Wake ex', 'Walking Wake',
  'Flutter Mane', 'Scream Tail', 'Slither Wing', 'Brute Bonnet', 'Sandy Shocks ex', 'Sandy Shocks', 'Gouging Fire ex', 'Gouging Fire', 'Koraidon ex', 'Koraidon']);
export const FUTURE = new Set(['Iron Hands ex', 'Iron Hands', 'Iron Valiant ex', 'Iron Valiant', 'Iron Bundle', 'Iron Crown ex', 'Iron Leaves ex', 'Iron Leaves',
  'Iron Thorns ex', 'Iron Thorns', 'Iron Jugulis', 'Iron Moth', 'Iron Treads', 'Iron Boulder ex', 'Miraidon ex', 'Miraidon']);

// ------------------------------------------------------------------ dati delle carte
export function energyTypeOfName(name) { return TYPES.find(t => t !== 'Colorless' && (name || '').includes(t)) || null; }
export const isPokemon = c => c && c.c === 'P';
export const isTrainer = c => c && c.c === 'T';
export const isEnergy = c => c && c.c === 'E';
export const isBasicEnergy = c => isEnergy(c) && (c.et === 'Basic' || (/^(Basic )?\w+ Energy$/.test(c.e) && !!energyTypeOfName(c.e) && c.et !== 'Special'));
export const isBasicPokemon = c => isPokemon(c) && (c.s === 'Basic' || (!c.f && !['Stage1', 'Stage2', 'VMAX', 'VSTAR', 'BREAK', 'LEVEL-UP', 'VUNION', 'MEGA'].includes(c.s)));
export const isEvolution = c => isPokemon(c) && !isBasicPokemon(c);
export const isSupporter = c => isTrainer(c) && /supporter/i.test(c.tt);
export const isItem = c => isTrainer(c) && /^item$/i.test(c.tt);
export const isStadium = c => isTrainer(c) && /stadium/i.test(c.tt);
export const isTool = c => isTrainer(c) && /tool/i.test(c.tt);
export const isAceSpec = c => !!c && (/ace spec/i.test(c.ra || '') || ACE_NAMES.has(c.e));
const ACE_NAMES = new Set(['Prime Catcher', 'Master Ball', 'Maximum Belt', "Hero's Cape", 'Unfair Stamp', 'Awakening Drum', 'Secret Box', 'Neo Upper Energy',
  'Reboot Pod', 'Survival Brace', 'Precious Trolley', 'Scramble Switch', 'Dangerous Laser', 'Neutralization Zone', 'Sparkling Crystal', 'Grand Tree',
  'Poké Vital A', 'Deluxe Bomb', 'Megaton Blower', 'Hyper Aroma', 'Treasure Tracker', 'Legacy Energy', 'Enriching Energy', 'Amulet of Hope', 'Brilliant Blender', 'Energy Search Pro', 'Max Rod', 'Glass Trumpet']);
export const isRadiant = c => isPokemon(c) && /^Radiant /.test(c.e);
export function prizeValueOf(c) {
  if (!isPokemon(c)) return 1;
  const n = c.e;
  if (/ ex$/.test(n)) return /^Mega /.test(n) ? 3 : 2;
  if (/VMAX$|V-UNION$/.test(n) || (/&/.test(n) && /GX$/.test(n))) return 3;
  if (/ (V|VSTAR|GX|EX)$/.test(n) || /^M .* EX$/.test(n)) return 2;
  return 1;
}
export const hasRuleBox = c => prizeValueOf(c) > 1 || isRadiant(c) || / (Prism Star|◇)$/.test(c?.e || '');
export const isPokemonEx = c => isPokemon(c) && / ex$/.test(c.e);
export const isPokemonV = c => isPokemon(c) && / (V|VMAX|VSTAR|V-UNION)$/.test(c.e);
export function isTeraCard(c) { return isPokemon(c) && TERA.has(c.e) && !(NOT_TERA_SETS[c.e] || []).includes(c.st); }

/** Generatore pseudo-casuale riproducibile (lo stato sta in s.rng) */
function rnd(s) {
  let t = (s.rng = (s.rng + 0x6D2B79F5) >>> 0);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

export class GameOver extends Error { constructor() { super('fine partita'); } }

// ------------------------------------------------------------------ partita
export class Game {
  /**
   * @param db funzione id -> carta
   * @param lib libreria effetti (vedi effects.js)
   */
  constructor(db, lib, state = null) {
    this.db = db; this.lib = lib;
    this.s = state;
    this.agents = [null, null];
    this.listeners = [];
    this.sim = false;     // true durante le simulazioni del bot (niente log/attese)
    this.manualNotes = []; // effetti non automatici da segnalare
  }

  static create(db, lib, decks, names, { first = -1, seed = (Math.random() * 2 ** 32) >>> 0 } = {}) {
    const g = new Game(db, lib, null);
    const s = g.s = { rng: seed >>> 0, nextUid: 1, cards: {}, turn: 0, cur: 0, first: 0, stadium: null, log: [], winner: null, reason: '',
      tf: {}, marks: [], phase: 'setup', p: [], lastKO: [-1, -1], vstarUsed: [false, false], gxUsed: [false, false] };
    for (let pl = 0; pl < 2; pl++) {
      const deck = decks[pl].map(id => g.newCard(id, pl));
      s.p.push({ name: names[pl], deck, hand: [], discard: [], prizes: [], lost: [], active: null, bench: [], mulligans: 0 });
    }
    s.firstChoice = first;
    return g;
  }

  // ---------------------------------------------------------------- utilità di base
  newCard(id, owner) { const uid = 'c' + this.s.nextUid++; this.s.cards[uid] = { uid, id, owner }; return uid; }
  card(uid) { const x = this.s.cards[uid]; return x ? this.db(x.id) : null; }
  cid(uid) { return this.s.cards[uid]?.id; }
  ownerOf(uid) { return this.s.cards[uid]?.owner; }
  random() { return rnd(this.s); }
  flip(label = '') {
    const h = this.random() < 0.5;
    this.log(`Moneta${label ? ' (' + label + ')' : ''}: ${h ? 'testa' : 'croce'}`);
    return h;
  }
  shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(this.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
    return arr;
  }
  log(t) { if (!this.sim) { this.s.log.push(t); if (this.s.log.length > 400) this.s.log.splice(0, 100); } }
  changed() { if (!this.sim) for (const f of this.listeners) f(); }
  opp(pl) { return 1 - pl; }
  P(pl) { return this.s.p[pl]; }
  nameOf(uid) { return this.card(uid)?.n || '?'; }
  slotName(sl) { return sl ? this.nameOf(this.topUid(sl)) : '?'; }

  // ---------------------------------------------------------------- Pokémon in gioco ("slot")
  newSlot(uid, pl) {
    return { sid: 's' + this.s.nextUid++, owner: pl, cards: [uid], energy: [], tools: [], dmg: 0,
      cond: { asleep: false, confused: false, paralyzed: false, poisoned: 0, burned: false }, playedTurn: this.s.turn, evolvedTurn: -1, used: {} };
  }
  slots(pl) { const p = this.P(pl); return p.active ? [p.active, ...p.bench] : [...p.bench]; }
  allSlots() { return [...this.slots(0), ...this.slots(1)]; }
  slot(sid) { return this.allSlots().find(x => x.sid === sid) || null; }
  isActive(sl) { return !!sl && this.P(sl.owner).active === sl; }
  topUid(sl) { return sl.cards[sl.cards.length - 1]; }
  top(sl) { return this.card(this.topUid(sl)); }
  slotOfCard(uid) { return this.allSlots().find(sl => sl.cards.includes(uid) || sl.energy.includes(uid) || sl.tools.includes(uid)) || null; }
  isTera(sl) { return isTeraCard(this.top(sl)); }
  isAncient(sl) { return ANCIENT.has(this.top(sl)?.e); }
  isFuture(sl) { return FUTURE.has(this.top(sl)?.e); }
  types(sl) {
    let t = [...(this.top(sl)?.t || ['Colorless'])];
    return this.hook('types', sl, t);
  }
  hasType(sl, type) { return this.types(sl).includes(type); }
  maxHp(sl) {
    const base = this.top(sl)?.hp || 0;
    return Math.max(10, this.hook('hp', sl, base));
  }
  remainingHp(sl) { return this.maxHp(sl) - sl.dmg; }
  prizeValue(sl) { return this.hook('prizeValue', sl, prizeValueOf(this.top(sl))); }
  ruleBox(sl) { return hasRuleBox(this.top(sl)); }
  isEx(sl) { return isPokemonEx(this.top(sl)); }
  isV(sl) { return isPokemonV(this.top(sl)); }
  stageOf(sl) { const c = this.top(sl); return isBasicPokemon(c) ? 'Basic' : c.s; }
  isEvolved(sl) { return sl.cards.length > 1 || isEvolution(this.top(sl)); }

  /** Tipi forniti dalle Energie assegnate: lista di unità ('Fire', 'Colorless', 'ANY'...) per ogni carta */
  energyUnits(uid, sl) {
    const c = this.card(uid);
    if (!c) return [];
    if (isBasicEnergy(c)) return [energyTypeOfName(c.e) || 'Colorless'];
    const e = this.lib.energy?.[c.e];
    if (e?.provides) return e.provides(this, sl, uid);
    if (isPokemon(c)) return ['Colorless'];   // Pokémon usati come Energia (rari)
    return ['Colorless'];
  }
  provided(sl) { return sl.energy.flatMap(u => this.energyUnits(u, sl)); }
  energyCount(sl) { return this.provided(sl).length; }
  energyCards(sl, type = null) { return sl.energy.filter(u => !type || this.energyUnits(u, sl).some(t => t === type || t === 'ANY')); }

  /** Controlla se le unità di Energia pagano il costo */
  static canPay(units, cost) {
    const need = {};
    let colorless = 0;
    for (const t of cost) { if (t === 'Colorless') colorless++; else need[t] = (need[t] || 0) + 1; }
    const pool = {};
    let any = 0;
    for (const u of units) { if (u === 'ANY') any++; else pool[u] = (pool[u] || 0) + 1; }
    let left = 0;
    for (const [t, n] of Object.entries(need)) {
      const have = pool[t] || 0;
      if (have >= n) pool[t] = have - n;
      else { pool[t] = 0; any -= (n - have); if (any < 0) return false; }
    }
    for (const v of Object.values(pool)) left += v;
    return left + any >= colorless;
  }
  attackCost(sl, atk) { return this.hook('attackCost', sl, [...(atk.c || [])], atk); }
  canPayAttack(sl, atk) { return Game.canPay(this.provided(sl), this.attackCost(sl, atk)); }
  retreatCost(sl) { return Math.max(0, this.hook('retreat', sl, this.top(sl)?.rt || 0)); }

  // ---------------------------------------------------------------- effetti continui
  /** Effetti temporanei: { kind, sid?, pl?, until, data } -- until = numero del turno in cui scadono (alla fine) */
  addMark(m) { this.s.marks.push(m); }
  marks(kind, filter = () => true) { return this.s.marks.filter(m => m.kind === kind && filter(m)); }
  hasMark(kind, sl) { return this.s.marks.some(m => m.kind === kind && (!sl || m.sid === sl.sid)); }

  /** Raccoglie i modificatori: Strumenti, Stadio, abilità passive in gioco, segnalini temporanei */
  hook(name, sl, value, extra) {
    const L = this.lib;
    // Stadio
    if (this.s.stadium) {
      const st = L.stadium?.[this.card(this.s.stadium.uid)?.e];
      if (st?.[name]) value = st[name](this, sl, value, extra, this.s.stadium.owner);
    }
    // Strumenti dello slot
    if (sl) for (const t of sl.tools) {
      const f = L.tool?.[this.card(t)?.e];
      if (f?.[name] && !this.toolsBlocked(sl)) value = f[name](this, sl, value, extra);
    }
    // abilità passive di tutti i Pokémon in gioco
    for (const other of this.allSlots()) {
      const c = this.top(other);
      const pas = L.passive?.[c?.e];
      if (pas?.[name] && !this.abilityBlocked(other)) value = pas[name](this, other, sl, value, extra);
    }
    for (const m of this.s.marks) {
      const f = L.marks?.[m.kind]?.[name];
      if (f) value = f(this, m, sl, value, extra);
    }
    return value;
  }
  abilityBlocked(sl) {
    if (!sl) return false;
    return !!this.hook0('blockAbility', sl);
  }
  toolsBlocked(sl) { return !!this.hook0('blockTools', sl); }
  /** come hook ma senza Strumenti (evita ricorsioni infinite) */
  hook0(name, sl) {
    const L = this.lib;
    let v = false;
    if (this.s.stadium) { const st = L.stadium?.[this.card(this.s.stadium.uid)?.e]; if (st?.[name]) v = st[name](this, sl, v, null, this.s.stadium.owner) || v; }
    for (const other of this.allSlots()) {
      if (other === sl) continue;
      const pas = L.passive?.[this.top(other)?.e];
      if (pas?.[name]) v = pas[name](this, other, sl, v) || v;
    }
    for (const m of this.s.marks) { const f = L.marks?.[m.kind]?.[name]; if (f) v = f(this, m, sl, v) || v; }
    return v;
  }

  // ---------------------------------------------------------------- spostamenti di carte
  removeFromZones(uid) {
    for (const p of this.s.p) for (const z of ['deck', 'hand', 'discard', 'prizes', 'lost']) {
      const i = p[z].indexOf(uid); if (i >= 0) { p[z].splice(i, 1); return z; }
    }
    for (const sl of this.allSlots()) for (const z of ['energy', 'tools', 'cards']) {
      const i = sl[z].indexOf(uid);
      if (i >= 0) { sl[z].splice(i, 1); return 'play'; }
    }
    if (this.s.stadium?.uid === uid) { this.s.stadium = null; return 'stadium'; }
    return null;
  }
  moveTo(uid, zone, pl = this.ownerOf(uid), top = true) {
    this.removeFromZones(uid);
    const arr = this.P(pl)[zone];
    if (zone === 'deck' && !top) arr.unshift(uid); else arr.push(uid);
  }
  discardCard(uid) { this.moveTo(uid, 'discard', this.ownerOf(uid)); }
  /** Pesca: la cima del mazzo è la fine dell'array */
  draw(pl, n = 1, quiet = false) {
    const p = this.P(pl);
    let k = 0;
    for (; k < n && p.deck.length; k++) p.hand.push(p.deck.pop());
    if (!quiet && k) this.log(`${p.name} pesca ${k} cart${k === 1 ? 'a' : 'e'}`);
    return k;
  }
  shuffleDeck(pl) { this.shuffle(this.P(pl).deck); }
  shuffleInto(pl, uids) { for (const u of uids) this.moveTo(u, 'deck', pl); this.shuffleDeck(pl); }

  // ---------------------------------------------------------------- richieste agli agenti
  async choose(pl, req) {
    const a = this.agents[pl];
    if (req.t === 'cards' || req.t === 'slot') {
      const list = req.t === 'cards' ? req.uids : req.sids;
      req.min = Math.min(req.min ?? 1, list.length);
      req.max = Math.min(req.max ?? 1, list.length);
      if (req.max <= 0) return [];
      if (req.min === list.length && req.max === list.length && !req.always) return [...list];
      if (req.min === 1 && req.max === 1 && list.length === 1 && !req.always) return [...list];
    }
    const r = await a.choose(this, pl, req);
    return r;
  }
  async chooseSlot(pl, sids, title, purpose, opt = {}) {
    const r = await this.choose(pl, { t: 'slot', sids: sids.map(x => x.sid || x), title, purpose, min: opt.min ?? 1, max: opt.max ?? 1, ...opt });
    return (r || []).map(sid => this.slot(sid)).filter(Boolean);
  }
  async yesno(pl, title, purpose = 'may', text = '') { return !!(await this.agents[pl].choose(this, pl, { t: 'yesno', title, purpose, text })); }

  // ---------------------------------------------------------------- preparazione
  async setup() {
    const s = this.s;
    for (let pl = 0; pl < 2; pl++) this.shuffleDeck(pl);
    // mano iniziale e mulligan
    const hasBasic = pl => this.P(pl).hand.some(u => isBasicPokemon(this.card(u)));
    for (let pl = 0; pl < 2; pl++) {
      const p = this.P(pl);
      if (!p.deck.some(u => isBasicPokemon(this.card(u)))) { this.end(1 - pl, `${p.name} non ha Pokémon Base nel mazzo`); return; }
      for (;;) {
        this.draw(pl, 7, true);
        if (hasBasic(pl)) break;
        p.mulligans++;
        this.log(`${p.name} non ha Pokémon Base: mulligan (${p.mulligans})`);
        this.shuffleInto(pl, [...p.hand]);
        if (p.mulligans > 30) { this.end(1 - pl, 'troppi mulligan'); return; }
      }
    }
    // chi inizia
    if (s.firstChoice === 0 || s.firstChoice === 1) s.first = s.firstChoice;
    else {
      const heads = this.random() < 0.5;
      this.log(`Testa o croce: ${heads ? 'testa' : 'croce'}`);
      s.first = heads ? 0 : 1;
      // chi vince il lancio sceglie: qui decide sempre di iniziare (scelta più comune)
    }
    this.log(`Inizia ${this.P(s.first).name}`);
    // Pokémon Attivo e Panchina (in segreto, poi rivelati)
    for (let pl = 0; pl < 2; pl++) {
      const p = this.P(pl);
      const basics = p.hand.filter(u => isBasicPokemon(this.card(u)));
      const [act] = await this.choose(pl, { t: 'cards', uids: basics, min: 1, max: 1, title: 'Scegli il Pokémon Attivo', purpose: 'setupActive', always: true });
      this.removeFromZones(act);
      p.active = this.newSlot(act, pl);
      p.active.playedTurn = 0;
      const rest = p.hand.filter(u => isBasicPokemon(this.card(u)));
      if (rest.length) {
        const bench = await this.choose(pl, { t: 'cards', uids: rest, min: 0, max: Math.min(5, rest.length), title: 'Metti in Panchina (facoltativo)', purpose: 'setupBench', always: true });
        for (const u of bench) { this.removeFromZones(u); const sl = this.newSlot(u, pl); sl.playedTurn = 0; p.bench.push(sl); }
      }
    }
    for (let pl = 0; pl < 2; pl++) for (let i = 0; i < 6; i++) { const p = this.P(pl); if (p.deck.length) p.prizes.push(p.deck.pop()); }
    // carte extra per i mulligan dell'avversario
    for (let pl = 0; pl < 2; pl++) {
      const extra = this.P(1 - pl).mulligans;
      if (extra > 0) {
        const opts = Array.from({ length: extra + 1 }, (_, i) => i === 0 ? 'Nessuna' : `${i} carta/e`);
        const k = await this.choose(pl, { t: 'option', title: `L'avversario ha fatto ${extra} mulligan: quante carte vuoi pescare?`, options: opts, purpose: 'mulliganDraw' });
        if (k > 0) this.draw(pl, k);
      }
    }
    for (let pl = 0; pl < 2; pl++) this.log(`${this.P(pl).name}: Attivo ${this.slotName(this.P(pl).active)}, ${this.P(pl).bench.length} in Panchina`);
    s.phase = 'play';
    s.cur = s.first;
    s.turn = 0;
    this.changed();
  }

  /** Effetti non automatici: il giocatore umano li applica con gli strumenti manuali */
  async flushManual(pl) {
    if (!this.manualNotes.length) return;
    const notes = this.manualNotes.filter(n => n.pl === pl);
    this.manualNotes = [];
    if (notes.length && this.agents[pl].manual) { this.changed(); await this.agents[pl].manual(this, pl, notes); }
  }

  end(winner, reason) {
    if (this.s.winner != null) return;
    this.s.winner = winner; this.s.reason = reason; this.s.phase = 'over';
    this.log(winner === -1 ? `Pareggio: ${reason}` : `Vince ${this.P(winner).name}: ${reason}`);
    this.changed();
    throw new GameOver();
  }

  // ---------------------------------------------------------------- ciclo dei turni
  async run() {
    try {
      if (this.s.phase === 'setup') await this.setup();
      for (let guard = 0; guard < 400 && this.s.winner == null; guard++) await this.playTurn();
      if (this.s.winner == null) this.end(-1, 'partita troppo lunga');
    } catch (e) {
      if (!(e instanceof GameOver)) throw e;
    }
  }

  isFirstTurn() { return this.s.turn === 1; }
  /** Il giocatore di turno è al suo primo turno? */
  isOwnFirstTurn(pl = this.s.cur) { return this.s.turn <= 2 && (this.s.turn === 1 ? pl === this.s.first : pl !== this.s.first); }

  async playTurn() {
    const s = this.s;
    s.turn++;
    const pl = s.cur;
    const p = this.P(pl);
    s.tf = { energy: false, supporter: false, stadium: false, retreat: false, attacked: false, itemsBlocked: false, koByOpp: s.lastKO[pl] === s.turn - 1 };
    this.log(`— Turno ${s.turn}: ${p.name} —`);
    if (!p.deck.length) { this.end(1 - pl, `${p.name} non può pescare: mazzo finito`); }
    this.draw(pl, 1);
    this.changed();
    // fase principale
    for (let guard = 0; guard < 200; guard++) {
      const acts = this.legalActions(pl);
      const a = await this.agents[pl].act(this, pl, acts);
      if (!a || a.k === 'end') break;
      if (a.k === 'attack') { await this.attack(pl, a.idx); break; }
      await this.doAction(pl, a);
      await this.flushManual(pl);
      this.checkKO();
      await this.resolvePromotions();
      this.changed();
    }
    await this.endTurn(pl);
  }

  async endTurn(pl) {
    const s = this.s;
    // effetti "fino alla fine del turno"
    await this.betweenTurns(pl);
    s.marks = s.marks.filter(m => m.until == null || m.until > s.turn);
    s.cur = 1 - pl;
    this.changed();
  }

  /** Controllo Pokémon tra un turno e l'altro */
  async betweenTurns(pl) {
    for (const who of [this.s.cur, 1 - this.s.cur]) {
      const a = this.P(who).active;
      if (!a) continue;
      const c = a.cond;
      if (c.poisoned) { a.dmg += 10 * c.poisoned; this.log(`${this.slotName(a)} è Avvelenato: ${10 * c.poisoned} danni`); }
      if (c.burned) {
        a.dmg += 20; this.log(`${this.slotName(a)} è Bruciato: 20 danni`);
        if (this.flip('Bruciato')) { c.burned = false; this.log(`${this.slotName(a)} non è più Bruciato`); }
      }
      if (c.asleep) { if (this.flip('Addormentato')) { c.asleep = false; this.log(`${this.slotName(a)} si sveglia`); } }
    }
    // la Paralisi dura fino alla fine del turno successivo del proprietario
    const mine = this.P(pl).active;
    if (mine?.cond.paralyzed && mine.cond.paraTurn < this.s.turn) { mine.cond.paralyzed = false; this.log(`${this.slotName(mine)} non è più Paralizzato`); }
    await this.lib.betweenTurns?.(this, pl);
    this.checkKO();
    await this.resolvePromotions();
  }

  // ---------------------------------------------------------------- azioni disponibili
  legalActions(pl) {
    const s = this.s, p = this.P(pl), out = [];
    if (s.winner != null) return out;
    const first = this.isOwnFirstTurn(pl);
    const itemsLocked = this.itemLockFor(pl);
    for (const uid of p.hand) {
      const c = this.card(uid);
      if (!c) continue;
      if (isBasicPokemon(c) && p.bench.length < this.benchSize(pl)) {
        if (!this.lib.cannotBench?.(this, pl, uid)) out.push({ k: 'bench', uid });
      }
      if (isEvolution(c) && !first) {
        for (const sl of this.slots(pl)) if (this.canEvolve(sl, c)) out.push({ k: 'evolve', uid, sid: sl.sid });
      }
      if (isEnergy(c) && !s.tf.energy) for (const sl of this.slots(pl)) out.push({ k: 'energy', uid, sid: sl.sid });
      if (isTrainer(c)) {
        if (isSupporter(c) && (s.tf.supporter || (first && pl === s.first && s.turn === 1 && !this.lib.trainer?.[c.e]?.firstTurnOK))) continue;
        if (isSupporter(c) && this.supporterLockFor(pl)) continue;
        if (isItem(c) && (itemsLocked || s.tf.itemsBlocked)) continue;
        if (isStadium(c) && (s.tf.stadium || (s.stadium && this.cid(s.stadium.uid) && this.card(s.stadium.uid).e === c.e))) continue;
        if (isTool(c)) {
          if (itemsLocked) continue;
          for (const sl of this.slots(pl)) if (sl.tools.length < this.toolLimit(sl) && this.canAttachTool(sl, uid)) out.push({ k: 'tool', uid, sid: sl.sid });
          continue;
        }
        const t = this.lib.trainer?.[c.e];
        if (t?.canPlay && !t.canPlay(this, pl, uid)) continue;
        if (!t && this.lib.parsedTrainer && !this.lib.parsedTrainer(this, c).canPlay(this, pl, uid)) continue;
        out.push({ k: 'trainer', uid });
      }
    }
    // abilità
    for (const sl of this.slots(pl)) {
      const c = this.top(sl);
      (c.b || []).forEach((ab, idx) => {
        if (this.abilityBlocked(sl)) return;
        const def = this.lib.abilityDef(this, c, ab);
        if (!def || def.passive || def.onEvolve || def.onBench || !def.use) return;
        if (def.vstar && s.vstarUsed[pl]) return;
        if (def.once !== false && sl.used[ab.e] === s.turn) return;
        if (def.activeOnly && !this.isActive(sl)) return;
        if (def.canUse && !def.canUse(this, pl, sl)) return;
        out.push({ k: 'ability', sid: sl.sid, idx, name: ab.n });
      });
    }
    // stadio con effetto da usare
    if (s.stadium) {
      const st = this.lib.stadium?.[this.card(s.stadium.uid)?.e];
      if (st?.use && (!s.tf.stadiumUsed) && (!st.canUse || st.canUse(this, pl))) out.push({ k: 'stadiumUse' });
    }
    // ritirata
    if (p.active && p.bench.length && !s.tf.retreat && this.canRetreat(p.active)) {
      const cost = this.retreatCost(p.active);
      if (this.energyCount(p.active) >= cost) for (const b of p.bench) out.push({ k: 'retreat', sid: b.sid, cost });
    }
    // attacchi
    if (p.active && !(first && pl === s.first && s.turn === 1)) {
      const a = p.active;
      const atks = this.attacksOf(a);
      atks.forEach((atk, idx) => { if (this.canAttackWith(a, atk, idx)) out.push({ k: 'attack', idx, name: atk.n }); });
    }
    out.push({ k: 'end' });
    return out;
  }
  benchSize(pl) { return this.hook('benchSize', null, 5, pl); }
  toolLimit(sl) { return this.hook('toolLimit', sl, 1); }
  canAttachTool(sl, uid) { const t = this.lib.tool?.[this.card(uid)?.e]; return !t?.canAttach || t.canAttach(this, sl); }
  itemLockFor(pl) { return this.marks('itemLock', m => m.pl === pl).length > 0 || !!this.hook('itemLock', null, false, pl); }
  supporterLockFor(pl) { return this.marks('supporterLock', m => m.pl === pl).length > 0 || !!this.hook('supporterLock', null, false, pl); }
  attacksOf(sl) { return this.hook('attacks', sl, [...(this.top(sl).a || [])]); }
  canRetreat(sl) {
    if (sl.cond.asleep || sl.cond.paralyzed) return false;
    if (this.marks('noRetreat', m => m.sid === sl.sid).length) return false;
    return !this.hook('cannotRetreat', sl, false);
  }
  canAttackWith(sl, atk, idx) {
    if (sl.cond.asleep || sl.cond.paralyzed) return false;
    if (this.marks('noAttack', m => m.sid === sl.sid && (!m.data?.name || m.data.name === atk.e)).length) return false;
    if (!this.canPayAttack(sl, atk)) return false;
    const def = this.lib.attackDef(this, this.top(sl), atk);
    if (def?.canUse && !def.canUse(this, sl.owner, sl)) return false;
    return true;
  }
  canEvolve(sl, c) {
    const top = this.top(sl);
    if (!c.f || !top) return false;
    if (sl.playedTurn === this.s.turn || sl.evolvedTurn === this.s.turn) return false;
    if (this.lib.cannotEvolve?.(this, sl)) return false;
    return sameName(c.f, top.e);
  }

  // ---------------------------------------------------------------- esecuzione delle azioni
  async doAction(pl, a) {
    const s = this.s, p = this.P(pl);
    switch (a.k) {
      case 'bench': {
        this.removeFromZones(a.uid);
        const sl = this.newSlot(a.uid, pl);
        p.bench.push(sl);
        this.log(`${p.name} mette in Panchina ${this.nameOf(a.uid)}`);
        await this.lib.onPlayToBench?.(this, pl, sl);
        break;
      }
      case 'evolve': await this.evolve(pl, a.uid, this.slot(a.sid)); break;
      case 'energy': {
        s.tf.energy = true;
        await this.attachEnergy(a.uid, this.slot(a.sid), true);
        break;
      }
      case 'tool': {
        const sl = this.slot(a.sid);
        this.removeFromZones(a.uid);
        sl.tools.push(a.uid);
        this.log(`${p.name} assegna ${this.nameOf(a.uid)} a ${this.slotName(sl)}`);
        await this.lib.tool?.[this.card(a.uid).e]?.onAttach?.(this, sl, a.uid);
        break;
      }
      case 'trainer': await this.playTrainer(pl, a.uid); break;
      case 'ability': {
        const sl = this.slot(a.sid);
        const c = this.top(sl);
        const ab = c.b[a.idx];
        const def = this.lib.abilityDef(this, c, ab);
        sl.used[ab.e] = s.turn;
        if (def.vstar) s.vstarUsed[pl] = true;
        this.log(`${p.name} usa l'abilità ${ab.n} di ${c.n}`);
        await def.use(this, pl, sl, ab);
        break;
      }
      case 'stadiumUse': {
        s.tf.stadiumUsed = true;
        const st = this.lib.stadium[this.card(s.stadium.uid).e];
        this.log(`${p.name} usa lo Stadio ${this.nameOf(s.stadium.uid)}`);
        await st.use(this, pl);
        break;
      }
      case 'retreat': await this.retreat(pl, this.slot(a.sid)); break;
    }
  }

  async evolve(pl, uid, sl, { fromEffect = false } = {}) {
    const from = this.slotName(sl);
    this.removeFromZones(uid);
    sl.cards.push(uid);
    sl.evolvedTurn = this.s.turn;
    sl.cond = { asleep: false, confused: false, paralyzed: false, poisoned: 0, burned: false };
    sl.used = {};
    this.s.marks = this.s.marks.filter(m => m.sid !== sl.sid || m.keepOnEvolve);
    this.log(`${this.P(pl).name} fa evolvere ${from} in ${this.nameOf(uid)}`);
    await this.lib.onEvolve?.(this, pl, sl, uid, fromEffect);
  }

  async attachEnergy(uid, sl, fromHandManual = false) {
    this.removeFromZones(uid);
    sl.energy.push(uid);
    this.log(`${this.P(sl.owner).name} assegna ${this.nameOf(uid)} a ${this.slotName(sl)}`);
    const e = this.lib.energy?.[this.card(uid)?.e];
    if (e?.onAttach && fromHandManual) await e.onAttach(this, sl, uid);
    await this.lib.onAttachEnergy?.(this, sl, uid, fromHandManual);
  }

  async playTrainer(pl, uid) {
    const s = this.s, c = this.card(uid), p = this.P(pl);
    this.removeFromZones(uid);
    if (isStadium(c)) {
      s.tf.stadium = true;
      if (s.stadium) { const old = s.stadium.uid; s.stadium = null; this.P(this.ownerOf(old)).discard.push(old); this.log(`${this.nameOf(old)} viene scartato`); }
      s.stadium = { uid, owner: pl };
      this.log(`${p.name} gioca lo Stadio ${c.n}`);
      await this.lib.stadium?.[c.e]?.onPlay?.(this, pl);
      return;
    }
    if (isSupporter(c)) s.tf.supporter = true;
    this.log(`${p.name} gioca ${c.n}`);
    // la carta resta "in gioco" mentre si risolve, poi va negli scarti
    s.resolving = uid;
    const t = this.lib.trainer?.[c.e] || this.lib.parsedTrainer?.(this, c);
    try {
      if (t?.play) await t.play(this, pl, uid);
    } finally {
      s.resolving = null;
    }
    if (!this.removeFromZonesPeek(uid)) this.P(pl).discard.push(uid);
    await this.lib.afterTrainer?.(this, pl, uid);
  }
  /** la carta è già stata spostata altrove dall'effetto? */
  removeFromZonesPeek(uid) {
    for (const p of this.s.p) for (const z of ['deck', 'hand', 'discard', 'prizes', 'lost']) if (p[z].includes(uid)) return true;
    return !!this.slotOfCard(uid) || this.s.stadium?.uid === uid;
  }

  async retreat(pl, to) {
    const p = this.P(pl), a = p.active;
    const cost = this.retreatCost(a);
    if (cost > 0) {
      const pay = await this.payEnergy(pl, a, cost, 'Scegli le Energie da scartare per la ritirata', 'retreatCost');
      for (const u of pay) this.discardCard(u);
    }
    this.s.tf.retreat = true;
    this.log(`${p.name} ritira ${this.slotName(a)}`);
    this.switchActive(pl, to);
  }
  /** Sceglie carte Energia assegnate che forniscono almeno n unità */
  async payEnergy(pl, sl, n, title, purpose) {
    if (n <= 0) return [];
    const cards = [...sl.energy];
    const units = u => this.energyUnits(u, sl).length;
    if (cards.reduce((t, u) => t + units(u), 0) <= n) return cards;
    for (let tries = 0; tries < 3; tries++) {
      const r = await this.choose(pl, { t: 'cards', uids: cards, min: 1, max: n, title, purpose, sid: sl.sid, units: n });
      if (r.reduce((t, u) => t + units(u), 0) >= n) return r;
    }
    // fallback: le prime che bastano
    const out = []; let got = 0;
    for (const u of cards) { if (got >= n) break; out.push(u); got += units(u); }
    return out;
  }

  /** Scambia l'Attivo con un Pokémon in Panchina (rimuove le condizioni speciali dell'Attivo) */
  switchActive(pl, benchSlot) {
    const p = this.P(pl);
    if (!benchSlot || !p.bench.includes(benchSlot)) return;
    const old = p.active;
    p.bench[p.bench.indexOf(benchSlot)] = old;
    p.active = benchSlot;
    if (old) {
      old.cond = { asleep: false, confused: false, paralyzed: false, poisoned: 0, burned: false };
      this.s.marks = this.s.marks.filter(m => !(m.sid === old.sid && m.clearOnSwitch !== false && ['noRetreat', 'noAttack', 'reduceDamage', 'preventDamage', 'defenderWeaker'].includes(m.kind) && !m.persist));
    }
    if (!this.sim) this.log(`${this.slotName(benchSlot)} diventa il Pokémon Attivo di ${p.name}`);
  }
  async switchOwn(pl, purpose = 'switchOwn', title = 'Scegli il nuovo Pokémon Attivo') {
    const p = this.P(pl);
    if (!p.bench.length) return false;
    const [to] = await this.chooseSlot(pl, p.bench, title, purpose);
    if (to) this.switchActive(pl, to);
    return !!to;
  }
  /** L'avversario sceglie con cosa sostituire il suo Attivo */
  async opponentSwitches(pl) { const o = 1 - pl; if (this.P(o).bench.length) await this.switchOwn(o, 'promote', "Scegli il nuovo Pokémon Attivo"); }
  /** Il giocatore sceglie quale Pokémon in Panchina dell'avversario diventa Attivo */
  async gust(pl, title = "Scegli il Pokémon dell'avversario da mandare in posizione attiva") {
    const o = this.P(1 - pl);
    if (!o.bench.length) return false;
    const [t] = await this.chooseSlot(pl, o.bench, title, 'gust');
    if (t) this.switchActive(1 - pl, t);
    return !!t;
  }

  // ---------------------------------------------------------------- attacco
  async attack(pl, idx) {
    const s = this.s, p = this.P(pl), a = p.active;
    const atk = this.attacksOf(a)[idx];
    const o = 1 - pl;
    s.tf.attacked = true;
    this.log(`${this.slotName(a)} usa ${atk.n}`);
    if (a.cond.confused) {
      if (!this.flip('Confuso')) { a.dmg += 30; this.log(`${this.slotName(a)} è Confuso: si fa 30 danni e l'attacco fallisce`); this.checkKO(); await this.resolvePromotions(); return; }
    }
    const def = this.lib.attackDef(this, this.top(a), atk) || {};
    const ctx = { pl, opp: o, attacker: a, atk, def, defender: this.P(o).active, base: parseInt(atk.d, 10) || 0, damage: parseInt(atk.d, 10) || 0,
      skip: false, noWR: false, noW: false, noR: false, ignoreEffects: false, dealt: 0, after: [], koTargets: [] };
    // effetti prima del danno (monete, condizioni per il danno, scelte)
    if (def.before) await def.before(this, ctx);
    if (!ctx.skip && ctx.damage > 0 && !def.noBaseDamage && this.P(o).active) {
      ctx.defender = this.P(o).active;
      const dmg = this.computeDamage(ctx, ctx.defender, ctx.damage, true);
      await this.applyDamage(ctx, ctx.defender, dmg);
    }
    if (!ctx.skip && def.after) await def.after(this, ctx);
    for (const f of ctx.after) await f();
    if (!ctx.skip) await this.lib.afterAttack?.(this, ctx);
    if (!this.sim && def.manual && !ctx.skip) this.manualNotes.push({ pl, text: def.manual, it: atk.x || atk.y, card: this.top(a).n, what: atk.n });
    await this.flushManual(pl);
    this.checkKO(ctx);
    await this.resolvePromotions();
  }

  /** Danno all'Attivo con Debolezza e Resistenza e tutti i modificatori */
  computeDamage(ctx, target, amount, isActiveTarget = this.isActive(target)) {
    if (amount <= 0) return 0;
    let d = amount;
    d = this.hook('attackBonus', ctx.attacker, d, { ctx, target });                // es. Fascia Sfida, Fascia Vitalità
    if (isActiveTarget && !ctx.noWR) {
      const tc = this.top(target);
      const atypes = this.types(ctx.attacker);
      const weak = this.hook('weakness', target, [...(tc.w || [])]);
      if (!ctx.noW) for (const w of weak) if (atypes.includes(w.t)) {
        const v = String(w.v || '×2');
        d = /\+/.test(v) ? d + (parseInt(v.replace(/\D/g, ''), 10) || 0) : d * (parseInt(v.replace(/\D/g, ''), 10) || 2);
      }
      if (!ctx.noR) for (const r of (tc.r || [])) if (atypes.includes(r.t)) d -= Math.abs(parseInt(String(r.v).replace(/[^\d]/g, ''), 10) || 30);
    }
    if (!ctx.ignoreEffects) d = this.hook('damageTaken', target, d, { ctx, isActive: isActiveTarget });
    return Math.max(0, d);
  }
  async applyDamage(ctx, target, dmg, { counters = false } = {}) {
    if (dmg <= 0) return 0;
    // la protezione dei Pokémon Teracristal in Panchina
    if (!counters && !this.isActive(target) && this.isTera(target)) { this.log(`${this.slotName(target)} (Teracristal) non subisce danni in Panchina`); return 0; }
    if (!counters && this.hook('preventDamage', target, false, { ctx })) { this.log(`I danni a ${this.slotName(target)} sono stati prevenuti`); return 0; }
    if (counters && this.hook('preventCounters', target, false, { ctx })) { this.log(`I segnalini su ${this.slotName(target)} sono stati prevenuti`); return 0; }
    target.dmg += dmg;
    if (ctx && target.owner === ctx.opp && this.isActive(target)) ctx.dealt += dmg;
    this.log(counters ? `${dmg / 10} segnalini danno su ${this.slotName(target)}` : `${this.slotName(target)} subisce ${dmg} danni`);
    if (ctx && !counters) await this.lib.onDamaged?.(this, ctx, target, dmg);
    return dmg;
  }
  /** Danno a un Pokémon in Panchina (senza Debolezza/Resistenza) */
  async benchDamage(ctx, target, amount) {
    const d = this.computeDamage({ ...ctx, noWR: true }, target, amount, false);
    return this.applyDamage(ctx, target, d);
  }
  async placeCounters(ctx, target, n) { if (n > 0) return this.applyDamage(ctx, target, n * 10, { counters: true }); return 0; }

  // ---------------------------------------------------------------- KO e premi
  checkKO(ctx = null) {
    const s = this.s;
    if (s.winner != null) return;
    const taken = [0, 0];
    for (const pl of [s.cur, 1 - s.cur]) {
      const p = this.P(pl);
      for (const sl of [...this.slots(pl)]) {
        if (sl.dmg < this.maxHp(sl)) continue;
        const prizes = this.prizeValue(sl);
        this.log(`${this.slotName(sl)} di ${p.name} è esausto!`);
        this.lib.onKO?.(this, sl, ctx);
        // carte del Pokémon negli scarti
        for (const u of [...sl.cards, ...sl.energy, ...sl.tools]) p.discard.push(u);
        if (p.active === sl) p.active = null; else p.bench.splice(p.bench.indexOf(sl), 1);
        s.marks = s.marks.filter(m => m.sid !== sl.sid);
        s.lastKO[pl] = s.turn;
        if (!this.hook('noPrizes', sl, false)) taken[1 - pl] += prizes;
      }
    }
    for (const pl of [0, 1]) {
      const p = this.P(pl);
      const n = Math.min(taken[pl], p.prizes.length);
      for (let i = 0; i < n; i++) p.hand.push(p.prizes.pop());
      if (n) this.log(`${p.name} prende ${n} cart${n === 1 ? 'a' : 'e'} Premio (ne restano ${p.prizes.length})`);
    }
    // vittoria
    const win = [0, 1].map(pl => (taken[pl] > 0 && this.P(pl).prizes.length === 0) || (!this.slots(1 - pl).length));
    if (win[0] && win[1]) this.end(-1, 'entrambi hanno vinto nello stesso momento');
    if (win[0]) this.end(0, this.P(0).prizes.length === 0 ? 'ha preso tutte le carte Premio' : "l'avversario non ha più Pokémon in gioco");
    if (win[1]) this.end(1, this.P(1).prizes.length === 0 ? 'ha preso tutte le carte Premio' : "l'avversario non ha più Pokémon in gioco");
  }
  async resolvePromotions() {
    for (const pl of [this.s.cur, 1 - this.s.cur]) {
      const p = this.P(pl);
      if (!p.active && p.bench.length) {
        const [sl] = await this.chooseSlot(pl, p.bench, 'Scegli il nuovo Pokémon Attivo', 'promote');
        p.bench.splice(p.bench.indexOf(sl), 1);
        p.active = sl;
        this.log(`${p.name} manda in campo ${this.slotName(sl)}`);
      } else if (!p.active && !p.bench.length && this.s.winner == null) this.end(1 - pl, `${p.name} non ha più Pokémon in gioco`);
    }
    this.changed();
  }

  // ---------------------------------------------------------------- condizioni speciali
  setCondition(sl, cond, extra = {}) {
    if (!sl || !this.isActive(sl)) return;
    if (this.hook('preventCondition', sl, false, cond)) { this.log(`${this.slotName(sl)} non può essere ${COND_IT[cond]}`); return; }
    const c = sl.cond;
    if (cond === 'asleep' || cond === 'confused' || cond === 'paralyzed') { c.asleep = c.confused = c.paralyzed = false; }
    if (cond === 'poisoned') c.poisoned = Math.max(c.poisoned || 0, extra.counters || 1);
    else c[cond] = true;
    if (cond === 'paralyzed') c.paraTurn = this.s.turn;
    this.log(`${this.slotName(sl)} ora è ${COND_IT[cond]}`);
  }
  clearConditions(sl) { sl.cond = { asleep: false, confused: false, paralyzed: false, poisoned: 0, burned: false }; }
  heal(sl, n) {
    const h = Math.min(sl.dmg, n);
    if (h > 0) { sl.dmg -= h; this.log(`${this.slotName(sl)} recupera ${h} PS`); }
    return h;
  }

  // ---------------------------------------------------------------- vista per l'interfaccia
  info(sl) {
    if (!sl) return null;
    return { sid: sl.sid, uid: this.topUid(sl), card: this.top(sl), hp: this.maxHp(sl), dmg: sl.dmg, energy: sl.energy, tools: sl.tools, cond: sl.cond,
      under: sl.cards.slice(0, -1), types: this.types(sl), retreat: this.retreatCost(sl) };
  }
}

export function sameName(a, b) {
  const n = x => (x || '').toLowerCase().replace(/[’']/g, "'").replace(/é/g, 'e').trim();
  return n(a) === n(b);
}
