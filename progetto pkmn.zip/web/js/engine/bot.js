// Avversario virtuale a 4 livelli.
//  0 Facile    – gioca per divertirsi: mosse spesso a caso, attacca appena può.
//  1 Medio     – gioca per vincere con calma: euristiche semplici, usa poco Capo e simili.
//  2 Difficile – euristiche complete: cerca i KO, sposta l'Attivo avversario, prepara gli attaccanti.
//  3 Incubo    – come Difficile ma prova ogni mossa in simulazione (fino alla fine del turno) e sceglie la migliore.
import { Game, GameOver, isBasicPokemon, isPokemon, isTrainer, isEnergy, isBasicEnergy, isSupporter, isItem, isStadium, isTool, isEvolution,
  energyTypeOfName, sameName } from './core.js';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const DRAW_SUPPORTERS = new Set(["Professor's Research", 'Iono', 'Judge', "Lillie's Determination", 'Lacey', 'Carmine', "Morty's Conviction"]);
const GUST = new Set(["Boss's Orders", 'Counter Catcher', 'Prime Catcher', 'Pokémon Catcher']);
const HAND_DISCARDERS = new Set(["Professor's Research", 'Carmine']);

export class BotAgent {
  constructor(level, { delay = 0 } = {}) { this.level = level; this.delay = delay; this.rand = Math.random; }

  // ---------------------------------------------------------------- scelta dell'azione
  async act(g, pl, actions) {
    if (this.delay && !g.sim) await sleep(this.delay);
    if (this.level >= 3 && !g.sim) {
      const best = await this.lookahead(g, pl, actions);
      if (best) return best;
    }
    return this.greedy(g, pl, actions);
  }

  greedy(g, pl, actions) {
    const lv = this.level;
    const acts = actions.filter(a => a.k !== 'end');
    g.s.tf.botActs = (g.s.tf.botActs || 0) + 1;
    if (g.s.tf.botActs > 45) return this.bestAttack(g, pl, actions) || { k: 'end' };
    // Facile: azioni a caso, con una preferenza per giocare Pokémon ed Energie
    if (lv === 0) {
      const nonAtk = acts.filter(a => a.k !== 'attack' && a.k !== 'retreat' && this.score(g, pl, a) > 0);
      if (nonAtk.length && this.rand() < 0.85) {
        const pick = nonAtk[Math.floor(this.rand() * nonAtk.length)];
        return pick;
      }
      const atk = actions.filter(a => a.k === 'attack');
      if (atk.length) return this.rand() < 0.6 ? this.bestAttack(g, pl, actions) : atk[Math.floor(this.rand() * atk.length)];
      return { k: 'end' };
    }
    let best = null, bestS = lv === 1 ? 25 : 15;
    for (const a of acts) {
      if (a.k === 'attack') continue;
      let s = this.score(g, pl, a);
      if (lv === 1 && a.k === 'trainer' && GUST.has(g.card(a.uid)?.e) && s < 90) s -= 30;
      if (s > bestS) { best = a; bestS = s; }
    }
    if (best) return best;
    return this.bestAttack(g, pl, actions) || { k: 'end' };
  }

  bestAttack(g, pl, actions) {
    const atks = actions.filter(a => a.k === 'attack');
    if (!atks.length) return null;
    const me = g.P(pl).active, tgt = g.P(1 - pl).active;
    let best = null, bv = -Infinity;
    for (const a of atks) {
      const atk = g.attacksOf(me)[a.idx];
      const d = this.estimate(g, me, atk, tgt);
      let v = d;
      if (tgt && d >= g.remainingHp(tgt)) v += 1000 * g.prizeValue(tgt);
      if (atk.e === 'Frenzied Gouging' && g.remainingHp(me) <= 200) v -= 600;
      v -= (atk.c || []).length * 2;   // a parità di danno, l'attacco più economico
      const def = g.lib.attackDef(g, g.top(me), atk);
      if (d === 0 && def?.manual) v = -100;
      if (d === 0 && /draw|discard your hand/i.test(atk.y || '') && g.P(pl).hand.length >= 5) v = -50;
      if (v > bv) { bv = v; best = a; }
    }
    return bv < -10 ? null : best;
  }

  /** Stima del danno di un attacco contro il bersaglio (con Debolezza/Resistenza e modificatori) */
  estimate(g, me, atk, tgt) {
    if (!atk || !tgt) return 0;
    const pl = me.owner;
    let base = parseInt(atk.d, 10) || 0;
    const energyIn = (f) => g.slots(pl).reduce((s, x) => s + x.energy.filter(u => f(g.card(u))).length, 0);
    switch (atk.e) {
      case 'Bellowing Thunder': base = 70 * energyIn(isBasicEnergy); break;
      case 'Make It Rain': base = 50 * g.P(pl).hand.filter(u => isBasicEnergy(g.card(u))).length; break;
      case 'Hail Blade': base = 60 * energyIn(c => isBasicEnergy(c) && energyTypeOfName(c.e) === 'Water'); break;
      case 'Unified Beatdown': base = 30 * g.P(pl).bench.length; break;
      case 'Burning Darkness': base = 180 + 30 * (6 - g.P(1 - pl).prizes.length); break;
      case 'Frenzied Gouging': return 9999;
      case 'Genome Hacking': return Math.max(0, ...g.attacksOf(tgt).filter(a => a.e !== 'Genome Hacking').map(a => this.estimate(g, me, a, tgt)));
    }
    const y = (atk.y || '').toLowerCase();
    let m;
    if ((m = y.match(/(\d+) more damage for each (?:\w+ )?energy attached to this/))) base += +m[1] * g.energyCount(me);
    else if ((m = y.match(/(\d+) more damage for each energy attached to both/))) base += +m[1] * (g.energyCount(me) + g.energyCount(tgt));
    else if ((m = y.match(/does (\d+) damage for each of your benched/))) base = +m[1] * g.P(pl).bench.length;
    else if ((m = y.match(/flip (\w+) coins\. this attack does (\d+) damage for each heads/))) base = Math.round((({ two: 2, three: 3, four: 4 })[m[1]] || +m[1] || 2) * +m[2] / 2);
    else if (/flip a coin\. if tails, this attack does nothing/.test(y)) base = Math.round(base / 2);
    if (base <= 0) return 0;
    const ctx = { pl, opp: 1 - pl, attacker: me, atk, after: [], dealt: 0 };
    try { return g.computeDamage(ctx, tgt, base, g.isActive(tgt)); } catch (_) { return base; }
  }

  /** Miglior danno che lo slot può fare ORA (o con k Energie in più) */
  bestDamage(g, sl, tgt, extraUnits = []) {
    if (!sl || !tgt) return 0;
    let best = 0;
    for (const atk of g.attacksOf(sl)) {
      if (!Game.canPay([...g.provided(sl), ...extraUnits], g.attackCost(sl, atk))) continue;
      best = Math.max(best, this.estimate(g, sl, atk, tgt));
    }
    return best;
  }
  /** Quante Energie mancano per l'attacco migliore dello slot */
  missingFor(g, sl) {
    const atks = g.attacksOf(sl);
    if (!atks.length) return 99;
    const units = g.provided(sl);
    let min = 99;
    for (const atk of atks) {
      const cost = g.attackCost(sl, atk);
      const dmg = parseInt(atk.d, 10) || 30;
      if (dmg < 20 && atks.length > 1) continue;
      let k = 0;
      while (k < 6 && !Game.canPay([...units, ...Array(k).fill('ANY')], cost)) k++;
      min = Math.min(min, k);
    }
    return min;
  }
  /** Valore di un Pokémon come attaccante (per decidere dove mettere le Energie) */
  attackerValue(g, sl) {
    const c = g.top(sl);
    const maxDmg = Math.max(0, ...g.attacksOf(sl).map(a => parseInt(a.d, 10) || 0), ...(sl.cards.length ? [0] : []));
    let v = maxDmg + c.hp / 4;
    if (['Raging Bolt ex', 'Gholdengo ex', 'Chien-Pao ex'].includes(c.e)) v += 150;
    if (c.b?.length && maxDmg < 60) v -= 60;   // Pokémon di supporto
    if (isBasicPokemon(c) && g.P(sl.owner).hand.concat(g.P(sl.owner).deck).some(u => sameName(g.card(u)?.f, c.e))) v -= 40;  // si evolverà
    return v;
  }

  // ---------------------------------------------------------------- punteggio delle singole azioni
  score(g, pl, a) {
    const lv = this.level, p = g.P(pl), o = g.P(1 - pl);
    const me = p.active;
    switch (a.k) {
      case 'evolve': return 85;
      case 'bench': {
        const c = g.card(a.uid);
        if (!p.bench.length) return 80;
        const evolves = p.hand.concat(p.deck).some(u => sameName(g.card(u)?.f, c.e));
        if (p.bench.length >= 4 && !evolves) return lv === 0 ? 30 : 5;
        if (['Budew', 'Duskull'].includes(c.e) || evolves) return 72;
        return p.bench.length < 3 ? 60 : 30;
      }
      case 'energy': return this.scoreEnergy(g, pl, a);
      case 'tool': {
        const c = g.card(a.uid), sl = g.slot(a.sid);
        if (/Balloon|Float|Rescue/.test(c.e)) return sl === me && g.retreatCost(me) > 0 ? 45 : (g.isActive(sl) ? 20 : 10);
        if (/Band|Belt/.test(c.e)) return sl === me ? 50 : 15;
        if (/Charm|Cape/.test(c.e)) return isBasicPokemon(g.top(sl)) || /Cape/.test(c.e) ? (sl === me ? 55 : 35) : 0;
        if (/Sparkling/.test(c.e)) return g.isTera(sl) ? 50 : 0;
        return 20;
      }
      case 'ability': {
        const sl = g.slot(a.sid);
        const c = g.top(sl), ab = c.b[a.idx];
        if (ab.e === 'Cursed Blast') {
          const n = /Dusknoir/.test(c.e) ? 13 : 5;
          const ko = g.slots(1 - pl).some(t => g.remainingHp(t) <= n * 10 && (g.prizeValue(t) >= 2 || g.isActive(t)));
          return lv >= 2 && ko ? 70 : (ko && lv === 1 ? 40 : 0);
        }
        if (ab.e === 'Psychic Embrace') {
          const needy = g.slots(pl).some(s => g.hasType(s, 'Psychic') && this.missingFor(g, s) > 0 && g.remainingHp(s) > 40);
          return needy ? 70 : 0;
        }
        if (ab.e === 'Squawk and Seize' || ab.e === 'Burst Roar') return p.hand.length <= 3 ? 70 : 0;
        if (ab.e === 'Refinement') return p.hand.length ? 55 : 0;
        if (ab.e === 'Lunar Cycle') return p.hand.filter(u => isBasicEnergy(g.card(u))).length > 1 ? 60 : 30;
        if (ab.e === 'Subjugating Chains') return me && this.missingFor(g, me) > 0 ? 50 : 0;
        if (ab.e === 'Adrena-Brain') return 75;
        return 78;
      }
      case 'stadiumUse': return 62;
      case 'retreat': {
        if (!me) return 0;
        const to = g.slot(a.sid);
        const tgt = o.active;
        const nowD = this.bestDamage(g, me, tgt);
        const thenD = this.bestDamage(g, to, tgt);
        const koNow = tgt && nowD >= g.remainingHp(tgt);
        const koThen = tgt && thenD >= g.remainingHp(tgt);
        if (me.cond.asleep || me.cond.paralyzed) return 0;
        if (koThen && !koNow) return 66 - a.cost * 3;
        if (thenD > nowD + 40 && a.cost <= 1) return 40;
        if (nowD === 0 && thenD > 0) return 55 - a.cost * 4;
        if ((me.cond.poisoned || me.cond.burned || me.cond.confused) && a.cost === 0) return 35;
        return 0;
      }
      case 'trainer': return this.scoreTrainer(g, pl, a);
    }
    return 0;
  }

  scoreEnergy(g, pl, a) {
    const sl = g.slot(a.sid), c = g.card(a.uid), p = g.P(pl);
    const units = g.energyUnits(a.uid, sl);
    const atks = g.attacksOf(sl);
    if (!atks.length) return 0;
    // l'Energia serve a questo Pokémon?
    const useful = atks.some(atk => {
      const cost = g.attackCost(sl, atk);
      const have = g.provided(sl);
      if (Game.canPay(have, cost)) return false;
      return cost.some(t => t === 'Colorless' || units.includes(t) || units.includes('ANY'));
    });
    let s = useful ? 50 : 18;
    const miss = this.missingFor(g, sl);
    s += this.attackerValue(g, sl) / 10;
    if (g.isActive(sl) && useful && miss === 1) s += 25;           // ora può attaccare
    if (!g.isActive(sl) && useful) s += 8;
    const typeMatch = (g.top(sl).a || []).some(atk => (atk.c || []).some(t => units.includes(t)));
    if (!typeMatch && !units.includes('ANY')) s -= 12;
    if (g.isActive(sl) && g.remainingHp(sl) <= 60 && p.bench.length) s -= 15; // sta per andare KO
    if (/Jet Energy/.test(c.e) && !g.isActive(sl)) s += 5;
    return Math.max(1, s);
  }

  scoreTrainer(g, pl, a) {
    const c = g.card(a.uid), n = c.e, p = g.P(pl), o = g.P(1 - pl), lv = this.level;
    const me = p.active, tgt = o.active;
    if (isStadium(c)) return g.s.stadium && g.ownerOf(g.s.stadium.uid) === pl ? 0 : 35;
    if (GUST.has(n)) {
      if (!me) return 0;
      // conviene solo se si può mettere KO un Pokémon in Panchina (o il bersaglio vale di più)
      let best = 0;
      for (const b of o.bench) {
        const d = this.bestDamage(g, me, b);
        if (d >= g.remainingHp(b)) best = Math.max(best, 60 + 20 * g.prizeValue(b));
      }
      if (tgt && this.bestDamage(g, me, tgt) >= g.remainingHp(tgt) && best <= 60 + 20 * g.prizeValue(tgt)) return 0;
      if (!best && lv >= 2 && o.bench.some(b => this.bestDamage(g, me, b) > 0 && g.top(b).b?.length)) best = 30;
      return best;
    }
    if (DRAW_SUPPORTERS.has(n)) {
      if (n === 'Iono') { const mine = p.prizes.length, theirs = o.prizes.length; return p.hand.length <= mine + 1 || theirs >= 4 && o.hand.length > theirs + 2 ? 45 : (p.hand.length <= 4 ? 30 : 10); }
      if (HAND_DISCARDERS.has(n)) {
        // prima gioca le altre carte utili, poi scarta la mano
        const others = p.hand.filter(u => u !== a.uid);
        const playable = others.filter(u => { const x = g.card(u); return isItem(x) || isBasicPokemon(x) || isTool(x); }).length;
        return playable > 1 ? 12 : (others.length <= 4 ? 40 : 22);
      }
      return p.hand.length <= 4 ? 42 : 18;
    }
    if (n === 'Rare Candy') return 88;
    if (/Ball|Poffin|Aroma|Trolley|Gong/.test(n)) {
      if (/Nest|Poffin|Trolley/.test(n) && p.bench.length >= 4) return 5;
      return p.deck.length > 3 ? 64 : 0;
    }
    if (/Arven|Irida|Hilda|Dawn|Brock|Colress|Cyrano|Jacq|Pokégear|Codebreaking|Explorer/.test(n)) return p.hand.length <= 6 ? 47 : 28;
    if (n === "Professor Sada's Vitality") return 52;
    if (n === 'Crispin') return 46;
    if (/Vessel|Energy Search|Electric Generator/.test(n)) return 58;
    if (/Energy Retrieval/.test(n)) return p.hand.filter(u => isEnergy(g.card(u))).length <= 1 ? 50 : 10;
    if (/Super Rod|Night Stretcher|Pal Pad/.test(n)) return p.discard.some(u => isPokemon(g.card(u))) ? 40 : 15;
    if (/Potion/.test(n)) return me && me.dmg >= 30 ? 30 : 0;
    if (n === 'Switch' || n === 'Escape Rope') {
      if (!me || !p.bench.length) return 0;
      const nowD = this.bestDamage(g, me, tgt);
      const best = Math.max(0, ...p.bench.map(b => this.bestDamage(g, b, tgt)));
      if (me.cond.asleep || me.cond.paralyzed) return best > 0 ? 60 : 30;
      return best > nowD + 30 ? 55 : 0;
    }
    if (n === 'Energy Switch') return 0;
    if (n === "Black Belt's Training" || n === 'Kieran') return tgt && g.isEx(tgt) && me && this.bestDamage(g, me, tgt) > 0 ? 40 : 0;
    if (n === "Professor Turo's Scenario" || n === 'Penny') return me && g.remainingHp(me) <= 50 && p.bench.length ? 35 : 0;
    if (n === 'Unfair Stamp') return 55;
    if (n === 'Lost Vacuum' || n === 'Tool Scrapper') return (g.s.stadium && g.ownerOf(g.s.stadium.uid) !== pl) || o.bench.concat(o.active ? [o.active] : []).some(s => s.tools.length) ? 25 : 0;
    // carte non riconosciute: le gioca solo se l'effetto è automatico
    const t = g.lib.parsedTrainer(g, c);
    return t.auto ? 30 : (lv === 0 ? 10 : 0);
  }

  // ---------------------------------------------------------------- risposte alle richieste
  async choose(g, pl, req) {
    if (this.delay && !g.sim && req.t !== 'yesno') await sleep(Math.min(this.delay, 250));
    switch (req.t) {
      case 'yesno': return this.yesno(g, pl, req);
      case 'option': return this.option(g, pl, req);
      case 'dist': return this.distribute(g, pl, req);
      case 'slot': return this.pickSlots(g, pl, req);
      case 'cards': return this.pickCards(g, pl, req);
    }
    return null;
  }

  yesno(g, pl, req) {
    const p = g.P(pl);
    if (req.purpose === 'switchSelf') {
      const tgt = g.P(1 - pl).active;
      return p.bench.some(b => this.bestDamage(g, b, tgt) > this.bestDamage(g, p.active, tgt));
    }
    if (req.purpose === 'jet') return this.level >= 1 && p.active && this.missingFor(g, p.active) > 0;
    if (req.purpose === 'discardStadium') return true;
    return true;
  }
  option(g, pl, req) {
    if (req.purpose === 'mulliganDraw') return req.options.length - 1;
    if (req.purpose === 'copyAttack') {
      const me = g.P(pl).active, t = g.P(1 - pl).active;
      let bi = 0, bd = -1;
      req.atks.forEach((a, i) => { const d = this.estimate(g, me, a, t); if (d > bd) { bd = d; bi = i; } });
      return bi;
    }
    if (req.purpose === 'kieran') return g.P(pl).active && this.missingFor(g, g.P(pl).active) === 0 ? 1 : 0;
    return 0;
  }

  distribute(g, pl, req) {
    let left = req.total;
    const out = {};
    const slots = req.sids.map(s => g.slot(s)).filter(Boolean);
    const mine = slots.length && slots[0].owner === pl;
    // segnalini: prima i KO che valgono di più, poi sul Pokémon più "pericoloso"
    const order = [...slots].sort((a, b) => (g.remainingHp(a) - g.prizeValue(a) * 40) - (g.remainingHp(b) - g.prizeValue(b) * 40));
    if (!mine) for (const sl of order) {
      const need = Math.ceil(g.remainingHp(sl) / 10);
      if (need <= left && !(g.isTera(sl) && false)) { out[sl.sid] = need; left -= need; }
    }
    if (left > 0 && order.length) {
      const t = order.find(s => !out[s.sid]) || order[0];
      out[t.sid] = (out[t.sid] || 0) + left;
    }
    return out;
  }

  pickSlots(g, pl, req) {
    const slots = req.sids.map(s => g.slot(s)).filter(Boolean);
    const n = Math.max(req.min, Math.min(req.max, req.purpose === 'attachTarget' && req.max > 1 ? req.max : req.min || 1));
    const o = g.P(1 - pl), me = g.P(pl).active;
    let key;
    switch (req.purpose) {
      case 'gust': key = s => { const d = this.bestDamage(g, me, s); return (d >= g.remainingHp(s) ? 1000 * g.prizeValue(s) : 0) - g.remainingHp(s) + (g.top(s).b?.length ? 30 : 0); }; break;
      case 'damageTarget': key = s => s.owner === pl ? -1e6 + g.remainingHp(s) : (g.remainingHp(s) <= (req.counters || 0) * 10 ? 1000 * g.prizeValue(s) : 0) + g.prizeValue(s) * 50 - g.remainingHp(s) / 2 + (g.isActive(s) ? 20 : 0); break;
      case 'selfDamageTarget': key = s => g.remainingHp(s); break;
      case 'healTarget': key = s => s.dmg + (g.isActive(s) ? 30 : 0); break;
      case 'promote': case 'switchOwn': case 'setupActive': {
        const tgt = o.active;
        key = s => this.bestDamage(g, s, tgt) * 2 + (tgt && this.bestDamage(g, s, tgt) >= g.remainingHp(tgt) ? 500 : 0) - this.missingFor(g, s) * 30 + g.remainingHp(s) / 5 - (g.top(s).b?.length && this.attackerValue(g, s) < 100 ? 80 : 0);
        break;
      }
      case 'attachTarget': {
        const e = req.energy ? g.card(req.energy) : null;
        const units = e ? g.energyUnits(req.energy, null) : ['ANY'];
        key = s => this.attackerValue(g, s) / 5 + (this.missingFor(g, s) > 0 ? 30 : -30) + (g.isActive(s) ? 10 : 0)
          + ((g.top(s).a || []).some(a => (a.c || []).some(t => units.includes(t))) ? 15 : 0);
        break;
      }
      case 'evolveTarget': key = s => g.isActive(s) ? 5 : 1; break;
      case 'bounce': key = s => s.dmg - (g.isActive(s) ? 0 : 50); break;
      case 'energyFrom': key = s => -this.attackerValue(g, s); break;
      default: key = s => (s.owner === pl ? 0 : -g.remainingHp(s));
    }
    if (this.level === 0 && this.rand() < 0.35) return [slots[Math.floor(this.rand() * slots.length)].sid];
    return [...slots].sort((a, b) => key(b) - key(a)).slice(0, Math.max(1, n)).map(s => s.sid);
  }

  /** Quanto serve una carta al bot in questo momento (per cercarla o non scartarla) */
  need(g, pl, uid) {
    const c = g.card(uid), p = g.P(pl);
    if (!c) return 0;
    const inPlay = g.slots(pl);
    const handNames = p.hand.map(u => g.card(u)?.e);
    if (isPokemon(c)) {
      let v = 30 + (c.hp || 0) / 10;
      if (isEvolution(c) && inPlay.some(s => sameName(c.f, g.top(s).e))) v += 60;
      if (c.s === 'Stage2' && inPlay.some(s => LIBprevo(g, c.f, g.top(s).e)) && handNames.includes('Rare Candy')) v += 55;
      if (isBasicPokemon(c) && inPlay.length < 3) v += 30;
      if (isBasicPokemon(c) && p.hand.concat(p.deck).some(u => sameName(g.card(u)?.f, c.e)) && !inPlay.some(s => g.top(s).e === c.e)) v += 25;
      if (handNames.filter(x => x === c.e).length >= 1) v -= 25;
      if (isEvolution(c) && !inPlay.some(s => sameName(c.f, g.top(s).e)) && !inPlay.some(s => g.top(s).e === c.f)) v -= 20;
      return v;
    }
    if (isEnergy(c)) {
      const t = energyTypeOfName(c.e);
      const used = inPlay.some(s => (g.top(s).a || []).some(a => (a.c || []).includes(t)));
      const inHand = p.hand.filter(u => isEnergy(g.card(u))).length;
      return (used ? 45 : 20) - inHand * 8 + (g.s.tf.energy ? -10 : 10);
    }
    if (c.e === 'Rare Candy') return p.hand.some(u => g.card(u)?.s === 'Stage2') ? 70 : 35;
    if (isSupporter(c)) return (g.s.tf.supporter ? 25 : 45) - handNames.filter(x => x === c.e).length * 10;
    if (GUST.has(c.e)) return 40;
    if (isItem(c)) return 35 - handNames.filter(x => x === c.e).length * 8;
    if (isStadium(c)) return g.s.stadium ? 15 : 28;
    if (isTool(c)) return 25;
    return 20;
  }

  pickCards(g, pl, req) {
    const list = req.uids;
    const n = req.max;
    const pr = req.purpose || '';
    const by = (f, k) => [...list].sort((a, b) => f(b) - f(a)).slice(0, k);
    if (this.level === 0 && this.rand() < 0.3 && !['setupActive', 'retreatCost', 'discardCost'].includes(pr)) {
      return this.shuffle([...list]).slice(0, Math.max(req.min, Math.min(n, Math.ceil(n * this.rand()) || req.min)));
    }
    switch (pr) {
      case 'setupActive': {
        // un Pokémon che può iniziare: niente Pokémon di supporto se si può evitare
        return by(u => { const c = g.card(u); const cheap = Math.min(9, ...(c.a || []).map(a => (a.c || []).length)); return 40 - cheap * 8 - (c.rt || 0) * 4 + (c.hp || 0) / 20 - (c.b?.length ? 25 : 0) - (/ex$| V$/.test(c.e) ? 15 : 0); }, 1);
      }
      case 'setupBench': return by(u => this.need(g, pl, u), Math.min(n, 5));
      case 'discardCost': case 'discardHand': return by(u => -this.need(g, pl, u), req.min || n);
      case 'retreatCost': case 'discardOwnEnergy': {
        const sl = g.slot(req.sid);
        const want = req.units || req.min || 1;
        const sorted = [...list].sort((a, b) => this.energyKeep(g, sl, a) - this.energyKeep(g, sl, b));
        const out = []; let got = 0;
        for (const u of sorted) { if (got >= want) break; out.push(u); got += g.energyUnits(u, sl).length; }
        return out.slice(0, Math.max(req.min, out.length));
      }
      case 'discardOppEnergy': return by(u => g.energyUnits(u, g.slot(req.sid)).length * 10 + (isBasicEnergy(g.card(u)) ? 0 : 5), n);
      case 'bellowing': case 'makeItRain': {
        const tgt = g.P(1 - pl).active;
        const per = pr === 'makeItRain' ? 50 : (g.P(pl).active && g.top(g.P(pl).active).e === 'Chien-Pao ex' ? 60 : 70);
        const me = g.P(pl).active;
        let k = list.length;
        if (tgt) {
          for (let i = 1; i <= list.length; i++) {
            const d = g.computeDamage({ pl, opp: 1 - pl, attacker: me, after: [] }, tgt, per * i, true);
            if (d >= g.remainingHp(tgt)) { k = i; break; }
          }
        }
        // prima le Energie dei Pokémon in Panchina che non servono
        return [...list].sort((a, b) => this.energyKeepAny(g, a) - this.energyKeepAny(g, b)).slice(0, k);
      }
      case 'attachPick': return list.slice(0, n);
      case 'searchEnergy': case 'searchEnergyHand': {
        const counts = {};
        return by(u => { const t = energyTypeOfName(g.card(u).e); counts[t] = (counts[t] || 0) + 1; return this.need(g, pl, u) - counts[t] * 3; }, n);
      }
      case 'searchBench': return by(u => this.need(g, pl, u), n);
      case 'searchHand': case 'recover': case 'searchTop': case 'evolveCard': default: {
        const picked = [];
        for (let i = 0; i < n; i++) {
          const rest = list.filter(u => !picked.includes(u));
          if (!rest.length) break;
          const best = rest.sort((a, b) => this.need(g, pl, b) - this.need(g, pl, a))[0];
          if (this.need(g, pl, best) < 0 && picked.length >= req.min) break;
          picked.push(best);
          g.P(pl).hand.push(best);   // simula di averla già per la scelta successiva
        }
        for (const u of picked) { const h = g.P(pl).hand; h.splice(h.lastIndexOf(u), 1); }
        return picked.length >= req.min ? picked : list.slice(0, req.min);
      }
    }
  }
  energyKeep(g, sl, u) {
    const without = sl.energy.filter(x => x !== u).flatMap(x => g.energyUnits(x, sl));
    const ok = g.attacksOf(sl).filter(a => Game.canPay(without, g.attackCost(sl, a))).length;
    return ok * 10 + (isBasicEnergy(g.card(u)) ? 0 : 5);
  }
  energyKeepAny(g, u) {
    const sl = g.slotOfCard(u);
    if (!sl) return 0;
    return (g.isActive(sl) ? 30 : 0) + this.attackerValue(g, sl) / 20;
  }
  shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(this.rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

  // ---------------------------------------------------------------- Incubo: simulazione delle mosse
  async lookahead(g, pl, actions) {
    const cand = actions.filter(a => a.k !== 'end' && (a.k === 'attack' || this.score(g, pl, a) > 0));
    if (cand.length <= 1 && !cand.some(a => a.k === 'attack')) return null;
    const limited = cand.length > 18 ? [...cand].sort((a, b) => this.score(g, pl, b) - this.score(g, pl, a)).slice(0, 18).concat(cand.filter(a => a.k === 'attack')) : cand;
    let best = null, bv = -Infinity;
    const baseline = await this.simulate(g, pl, null);
    for (const a of limited) {
      let v = 0;
      const runs = a.k === 'attack' ? 2 : 1;
      for (let r = 0; r < runs; r++) v += await this.simulate(g, pl, a);
      v /= runs;
      if (v > bv) { bv = v; best = a; }
    }
    // fermarsi (senza attaccare) solo se nessuna mossa migliora la situazione
    if (bv < baseline - 1) return { k: 'end' };
    return best;
  }

  async simulate(g, pl, first) {
    const sim = new Game(g.db, g.lib, structuredClone(g.s));
    sim.sim = true;
    const greedy = new BotAgent(2);
    greedy.rand = () => 0.5;
    sim.agents = [greedy, greedy];
    sim.s.rng = (Math.random() * 2 ** 32) >>> 0;
    // nasconde le informazioni che il bot non conosce (mano/mazzo/premi avversari, ordine del proprio mazzo)
    hide(sim, 1 - pl, ['hand', 'deck', 'prizes']);
    hide(sim, pl, ['deck', 'prizes']);
    try {
      if (first) {
        if (first.k === 'attack') await sim.attack(pl, first.idx);
        else { await sim.doAction(pl, first); sim.checkKO(); }
      }
      if (!first || first.k !== 'attack') {
        for (let i = 0; i < 25 && sim.s.winner == null; i++) {
          const acts = sim.legalActions(pl);
          const a = greedy.greedy(sim, pl, acts);
          if (!a || a.k === 'end') break;
          if (a.k === 'attack') { await sim.attack(pl, a.idx); break; }
          await sim.doAction(pl, a); sim.checkKO();
        }
      }
      await sim.betweenTurns(pl);
    } catch (e) { if (!(e instanceof GameOver)) return -1e5; }
    return this.evaluate(sim, pl);
  }

  evaluate(g, pl) {
    const s = g.s;
    if (s.winner === pl) return 1e6;
    if (s.winner === 1 - pl) return -1e6;
    const p = g.P(pl), o = g.P(1 - pl);
    let v = (6 - p.prizes.length) * 1000 - (6 - o.prizes.length) * 1000;
    for (const sl of g.slots(pl)) {
      v += 40 + this.attackerValue(g, sl) / 4 + Math.min(4, g.energyCount(sl)) * 25 - sl.dmg / 4;
      if (g.isEvolved(sl)) v += 50;
    }
    for (const sl of g.slots(1 - pl)) {
      v -= 30 + g.energyCount(sl) * 15;
      v += (sl.dmg / g.maxHp(sl)) * 120 * g.prizeValue(sl);
    }
    // minaccia: l'avversario può mettere KO il nostro Attivo al prossimo turno?
    if (o.active && p.active) {
      const threat = this.bestDamage(g, o.active, p.active, ['ANY']);
      if (threat >= g.remainingHp(p.active)) v -= 400 * g.prizeValue(p.active);
    }
    v += Math.min(p.hand.length, 8) * 8 + Math.min(p.bench.length, 5) * 15;
    if (o.active && Object.entries(o.active.cond).some(([k, x]) => k !== 'paraTurn' && x)) v += 40;
    return v;
  }
}

function hide(g, pl, zones) {
  const p = g.P(pl);
  const all = zones.flatMap(z => p[z]);
  g.shuffle(all);
  let k = 0;
  for (const z of zones) { const n = p[z].length; p[z] = all.slice(k, k + n); k += n; }
}
function LIBprevo(g, stage1, basic) { const b = g.lib.prevo.get((stage1 || '').toLowerCase()); return b && sameName(b, basic); }
