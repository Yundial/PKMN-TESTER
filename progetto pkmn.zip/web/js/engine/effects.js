// Libreria degli effetti: carte scritte a mano (le più giocate e quelle dei mazzi avversari)
// più l'interprete automatico dei testi per tutte le altre. Le chiavi sono i nomi inglesi delle carte.
import { isBasicPokemon, isPokemon, isTrainer, isEnergy, isBasicEnergy, isSupporter, isItem, isStadium, isTool, isEvolution,
  energyTypeOfName, isPokemonEx, isPokemonV, hasRuleBox, sameName, prizeValueOf } from './core.js';
import { parseText, normText, H } from './textfx.js';

const ex = c => isPokemonEx(c);
const others = (g, pl, uid) => g.P(pl).hand.filter(u => u !== uid);
const benchFree = (g, pl) => g.benchSize(pl) - g.P(pl).bench.length;
const moreRemaining = (g, pl) => g.P(pl).prizes.length > g.P(1 - pl).prizes.length;
const typeIs = t => c => isBasicEnergy(c) && energyTypeOfName(c.e) === t;

// ------------------------------------------------------------------ Allenatori
const trainer = {
  // ---- Strumenti (Item)
  'Ultra Ball': {
    canPlay: (g, pl, uid) => others(g, pl, uid).length >= 2,
    async play(g, pl, uid) {
      await H.discardFromHand(g, pl, 2, { exclude: uid, title: 'Scarta 2 carte' });
      await H.search(g, pl, isPokemon, { title: 'Cerca un Pokémon', purpose: 'searchHand' });
    },
  },
  'Nest Ball': { canPlay: (g, pl) => benchFree(g, pl) > 0, play: (g, pl) => H.search(g, pl, isBasicPokemon, { to: 'bench', title: 'Cerca un Pokémon Base per la Panchina', purpose: 'searchBench' }) },
  'Buddy-Buddy Poffin': { canPlay: (g, pl) => benchFree(g, pl) > 0, play: (g, pl) => H.search(g, pl, c => isBasicPokemon(c) && c.hp <= 70, { max: 2, to: 'bench', title: 'Cerca fino a 2 Pokémon Base con 70 PS o meno', purpose: 'searchBench' }) },
  'Poké Ball': { async play(g, pl) { if (g.flip()) await H.search(g, pl, isPokemon, { title: 'Cerca un Pokémon', purpose: 'searchHand' }); } },
  'Quick Ball': {
    canPlay: (g, pl, uid) => others(g, pl, uid).length >= 1,
    async play(g, pl, uid) { await H.discardFromHand(g, pl, 1, { exclude: uid }); await H.search(g, pl, isBasicPokemon, { title: 'Cerca un Pokémon Base', purpose: 'searchHand' }); },
  },
  'Level Ball': { play: (g, pl) => H.search(g, pl, c => isPokemon(c) && c.hp <= 90, { title: 'Cerca un Pokémon con 90 PS o meno', purpose: 'searchHand' }) },
  'Great Ball': { play: (g, pl) => lookTop(g, pl, 7, isPokemon, 1, 'Guarda le prime 7 carte: prendi un Pokémon') },
  'Dusk Ball': {
    async play(g, pl) {
      const p = g.P(pl); const bottom = p.deck.slice(0, 7);
      const cand = bottom.filter(u => isPokemon(g.card(u)));
      const pick = await g.choose(pl, { t: 'cards', uids: cand, min: 0, max: 1, title: 'Ultime 7 carte del mazzo: prendi un Pokémon', purpose: 'searchHand', from: 'deck', always: true, fullDeck: bottom });
      for (const u of pick) g.moveTo(u, 'hand', pl);
      g.shuffleDeck(pl);
    },
  },
  'Hyper Aroma': { play: (g, pl) => H.search(g, pl, c => isPokemon(c) && c.s === 'Stage1', { max: 3, title: 'Cerca fino a 3 Pokémon di Fase 1', purpose: 'searchHand' }) },
  'Precious Trolley': { canPlay: (g, pl) => benchFree(g, pl) > 0, play: (g, pl) => H.search(g, pl, isBasicPokemon, { max: 8, to: 'bench', title: 'Cerca Pokémon Base per la Panchina', purpose: 'searchBench' }) },
  'Rare Candy': {
    canPlay: (g, pl) => !g.isOwnFirstTurn(pl) && rareCandyPairs(g, pl).length > 0,
    async play(g, pl) {
      const pairs = rareCandyPairs(g, pl);
      const slots = [...new Set(pairs.map(p => p.sl))];
      const [sl] = await g.chooseSlot(pl, slots, 'Caramella Rara: quale Pokémon Base fai evolvere?', 'evolveTarget');
      const cards = pairs.filter(p => p.sl === sl).map(p => p.uid);
      const [uid] = await g.choose(pl, { t: 'cards', uids: cards, min: 1, max: 1, title: 'Scegli il Pokémon di Fase 2', purpose: 'evolveCard', from: 'hand' });
      await g.evolve(pl, uid, sl);
    },
  },
  'Switch': { canPlay: (g, pl) => g.P(pl).bench.length > 0, play: (g, pl) => g.switchOwn(pl) },
  'Escape Rope': {
    canPlay: (g, pl) => g.P(pl).bench.length > 0 || g.P(1 - pl).bench.length > 0,
    async play(g, pl) { await g.opponentSwitches(pl); await g.switchOwn(pl); },
  },
  'Potion': { canPlay: (g, pl) => g.slots(pl).some(s => s.dmg > 0), async play(g, pl) { const [s] = await g.chooseSlot(pl, g.slots(pl).filter(x => x.dmg > 0), 'Quale Pokémon curi di 30?', 'healTarget'); if (s) g.heal(s, 30); } },
  'Super Potion': {
    canPlay: (g, pl) => g.slots(pl).some(s => s.dmg > 0 && s.energy.length),
    async play(g, pl) { const [s] = await g.chooseSlot(pl, g.slots(pl).filter(x => x.dmg > 0 && x.energy.length), 'Quale Pokémon curi di 60?', 'healTarget'); if (s) { await H.discardEnergyFrom(g, pl, s, 1); g.heal(s, 60); } },
  },
  'Energy Retrieval': { canPlay: (g, pl) => g.P(pl).discard.some(u => isBasicEnergy(g.card(u))), play: (g, pl) => H.fromDiscard(g, pl, isBasicEnergy, { max: 2, title: 'Prendi fino a 2 Energie base dagli scarti' }) },
  'Superior Energy Retrieval': {
    canPlay: (g, pl, uid) => others(g, pl, uid).length >= 2 && g.P(pl).discard.some(u => isBasicEnergy(g.card(u))),
    async play(g, pl, uid) { await H.discardFromHand(g, pl, 2, { exclude: uid }); await H.fromDiscard(g, pl, isBasicEnergy, { max: 4, title: 'Prendi fino a 4 Energie base dagli scarti' }); },
  },
  'Super Rod': { canPlay: (g, pl) => g.P(pl).discard.some(u => isPokemon(g.card(u)) || isBasicEnergy(g.card(u))), play: (g, pl) => H.fromDiscard(g, pl, c => isPokemon(c) || isBasicEnergy(c), { max: 3, to: 'deck', title: 'Rimescola nel mazzo fino a 3 Pokémon/Energie base' }) },
  'Night Stretcher': { canPlay: (g, pl) => g.P(pl).discard.some(u => isPokemon(g.card(u)) || isBasicEnergy(g.card(u))), play: (g, pl) => H.fromDiscard(g, pl, c => isPokemon(c) || isBasicEnergy(c), { max: 1, title: 'Prendi un Pokémon o una Energia base dagli scarti' }) },
  'Pal Pad': { canPlay: (g, pl) => g.P(pl).discard.some(u => isSupporter(g.card(u))), play: (g, pl) => H.fromDiscard(g, pl, isSupporter, { max: 2, to: 'deck', title: 'Rimescola fino a 2 Aiuti nel mazzo' }) },
  'Earthen Vessel': {
    canPlay: (g, pl, uid) => others(g, pl, uid).length >= 1,
    async play(g, pl, uid) { await H.discardFromHand(g, pl, 1, { exclude: uid }); await H.search(g, pl, isBasicEnergy, { max: 2, title: 'Cerca fino a 2 Energie base', purpose: 'searchEnergyHand' }); },
  },
  'Energy Search': { play: (g, pl) => H.search(g, pl, isBasicEnergy, { title: 'Cerca una Energia base', purpose: 'searchEnergyHand' }) },
  'Fighting Gong': { play: (g, pl) => H.search(g, pl, c => typeIs('Fighting')(c) || (isBasicPokemon(c) && c.t?.includes('Fighting')), { title: 'Cerca una Energia Lotta base o un Pokémon Base Lotta', purpose: 'searchHand' }) },
  'Pokégear 3.0': { play: (g, pl) => lookTop(g, pl, 7, isSupporter, 1, 'Guarda le prime 7 carte: prendi un Aiuto') },
  'Electric Generator': {
    async play(g, pl) {
      const p = g.P(pl); const top = p.deck.slice(-5);
      const cand = top.filter(u => typeIs('Lightning')(g.card(u)));
      const targets = p.bench.filter(s => g.hasType(s, 'Lightning'));
      const pick = targets.length ? await g.choose(pl, { t: 'cards', uids: cand, min: 0, max: 2, title: 'Prime 5 carte: scegli fino a 2 Energie Lampo base', purpose: 'attachPick', from: 'deck', always: true, fullDeck: top }) : [];
      await H.attachEach(g, pl, pick, targets);
      g.shuffleDeck(pl);
    },
  },
  'Energy Switch': {
    canPlay: (g, pl) => g.slots(pl).length > 1 && g.slots(pl).some(s => s.energy.some(u => isBasicEnergy(g.card(u)))),
    async play(g, pl) {
      const from = g.slots(pl).filter(s => s.energy.some(u => isBasicEnergy(g.card(u))));
      const [a] = await g.chooseSlot(pl, from, 'Da quale Pokémon sposti una Energia base?', 'energyFrom');
      const [u] = await g.choose(pl, { t: 'cards', uids: a.energy.filter(x => isBasicEnergy(g.card(x))), title: 'Quale Energia?', purpose: 'energyMove', sid: a.sid });
      const [b] = await g.chooseSlot(pl, g.slots(pl).filter(s => s !== a), 'A quale Pokémon la sposti?', 'attachTarget', { energy: u });
      if (u && b) { g.removeFromZones(u); b.energy.push(u); g.log(`${g.nameOf(u)} spostata su ${g.slotName(b)}`); }
    },
  },
  'Counter Catcher': { canPlay: (g, pl) => moreRemaining(g, pl) && g.P(1 - pl).bench.length > 0, play: (g, pl) => g.gust(pl) },
  'Prime Catcher': { canPlay: (g, pl) => g.P(1 - pl).bench.length > 0, async play(g, pl) { await g.gust(pl); if (g.P(pl).bench.length && await g.yesno(pl, 'Vuoi anche scambiare il tuo Pokémon Attivo?', 'switchSelf')) await g.switchOwn(pl); } },
  'Pokémon Catcher': { canPlay: (g, pl) => g.P(1 - pl).bench.length > 0, async play(g, pl) { if (g.flip()) await g.gust(pl); } },
  'Unfair Stamp': {
    canPlay: g => g.s.tf.koByOpp,
    async play(g, pl) { await H.shuffleHandDraw(g, pl, 5); await H.shuffleHandDraw(g, 1 - pl, 2); },
  },
  'Lost Vacuum': {
    canPlay: (g, pl, uid) => others(g, pl, uid).length >= 1 && (!!g.s.stadium || g.allSlots().some(s => s.tools.length)),
    async play(g, pl, uid) {
      await H.discardFromHand(g, pl, 1, { exclude: uid, title: 'Metti 1 carta nella zona perduta' });
      const tools = g.allSlots().flatMap(s => s.tools);
      const opts = [...tools, ...(g.s.stadium ? [g.s.stadium.uid] : [])];
      const [u] = await g.choose(pl, { t: 'cards', uids: opts, title: 'Quale Oggetto o Stadio mandi nella zona perduta?', purpose: 'removeOpp' });
      if (u) { const o = g.ownerOf(u); g.removeFromZones(u); g.P(o).lost.push(u); g.log(`${g.nameOf(u)} va nella zona perduta`); }
    },
  },
  'Tool Scrapper': {
    canPlay: g => g.allSlots().some(s => s.tools.length),
    async play(g, pl) {
      const tools = g.allSlots().flatMap(s => s.tools);
      const pick = await g.choose(pl, { t: 'cards', uids: tools, min: 1, max: 2, title: 'Scegli fino a 2 Oggetti Pokémon da scartare', purpose: 'removeOpp' });
      for (const u of pick) g.discardCard(u);
    },
  },
  // ---- Aiuti
  "Professor's Research": { async play(g, pl) { const p = g.P(pl); for (const u of [...p.hand]) g.discardCard(u); g.draw(pl, 7); } },
  'Iono': { async play(g, pl) { for (const x of [pl, 1 - pl]) await H.shuffleHandDraw(g, x, g.P(x).prizes.length, true); } },
  'Judge': { async play(g, pl) { for (const x of [pl, 1 - pl]) await H.shuffleHandDraw(g, x, 4); } },
  "Lillie's Determination": { async play(g, pl) { await H.shuffleHandDraw(g, pl, g.P(pl).prizes.length === 6 ? 8 : 6); } },
  'Lacey': { async play(g, pl) { await H.shuffleHandDraw(g, pl, g.P(1 - pl).prizes.length <= 3 ? 8 : 4); } },
  'Carmine': { firstTurnOK: true, async play(g, pl) { const p = g.P(pl); for (const u of [...p.hand]) g.discardCard(u); g.draw(pl, 5); } },
  "Boss's Orders": { canPlay: (g, pl) => g.P(1 - pl).bench.length > 0, play: (g, pl) => g.gust(pl) },
  'Arven': {
    async play(g, pl) {
      await H.search(g, pl, isItem, { title: 'Cerca uno Strumento', purpose: 'searchHand', shuffle: false });
      await H.search(g, pl, isTool, { title: 'Cerca un Oggetto Pokémon', purpose: 'searchHand' });
    },
  },
  'Irida': {
    async play(g, pl) {
      await H.search(g, pl, c => isPokemon(c) && c.t?.includes('Water'), { title: 'Cerca un Pokémon Acqua', purpose: 'searchHand', shuffle: false });
      await H.search(g, pl, isItem, { title: 'Cerca uno Strumento', purpose: 'searchHand' });
    },
  },
  'Hilda': {
    async play(g, pl) {
      await H.search(g, pl, isEvolution, { title: 'Cerca un Pokémon Evoluzione', purpose: 'searchHand', shuffle: false });
      await H.search(g, pl, isEnergy, { title: 'Cerca una carta Energia', purpose: 'searchEnergyHand' });
    },
  },
  'Dawn': {
    async play(g, pl) {
      await H.search(g, pl, isBasicPokemon, { title: 'Cerca un Pokémon Base', purpose: 'searchHand', shuffle: false });
      await H.search(g, pl, c => isPokemon(c) && c.s === 'Stage1', { title: 'Cerca un Pokémon di Fase 1', purpose: 'searchHand', shuffle: false });
      await H.search(g, pl, c => isPokemon(c) && c.s === 'Stage2', { title: 'Cerca un Pokémon di Fase 2', purpose: 'searchHand' });
    },
  },
  "Brock's Scouting": {
    async play(g, pl) {
      const k = await g.choose(pl, { t: 'option', title: 'Cosa cerchi?', options: ['Fino a 2 Pokémon Base', '1 Pokémon Evoluzione'], purpose: 'brock' });
      if (k === 1) await H.search(g, pl, isEvolution, { title: 'Cerca un Pokémon Evoluzione', purpose: 'searchHand' });
      else await H.search(g, pl, isBasicPokemon, { max: 2, title: 'Cerca fino a 2 Pokémon Base', purpose: 'searchHand' });
    },
  },
  "Colress's Tenacity": {
    async play(g, pl) {
      await H.search(g, pl, isStadium, { title: 'Cerca uno Stadio', purpose: 'searchHand', shuffle: false });
      await H.search(g, pl, isEnergy, { title: 'Cerca una carta Energia', purpose: 'searchEnergyHand' });
    },
  },
  'Crispin': {
    async play(g, pl) {
      const got = await H.search(g, pl, isBasicEnergy, { max: 2, title: 'Cerca fino a 2 Energie base di tipo diverso', purpose: 'searchEnergyHand', shuffle: false });
      const uniq = []; for (const u of got) if (!uniq.some(x => g.card(x).e === g.card(u).e)) uniq.push(u);
      for (const u of got) if (!uniq.includes(u)) g.moveTo(u, 'deck', pl);
      if (uniq.length === 2) {
        const [att] = await g.choose(pl, { t: 'cards', uids: uniq, title: 'Quale Energia assegni a un tuo Pokémon? (l\'altra va in mano)', purpose: 'attachPick' });
        await H.attachEach(g, pl, [att], g.slots(pl));
      }
      g.shuffleDeck(pl);
    },
  },
  "Professor Sada's Vitality": {
    canPlay: (g, pl) => g.slots(pl).some(s => g.isAncient(s)) && g.P(pl).discard.some(u => isBasicEnergy(g.card(u))),
    async play(g, pl) {
      const anc = g.slots(pl).filter(s => g.isAncient(s));
      const picks = await g.chooseSlot(pl, anc, 'Scegli fino a 2 Pokémon Antichi', 'attachTarget', { min: 1, max: 2 });
      let done = 0;
      for (const sl of picks) {
        const cand = g.P(pl).discard.filter(u => isBasicEnergy(g.card(u)));
        if (!cand.length) break;
        const [u] = await g.choose(pl, { t: 'cards', uids: cand, title: `Energia base dagli scarti per ${g.slotName(sl)}`, purpose: 'attachPick', from: 'discard', sid: sl.sid });
        if (u) { await g.attachEnergy(u, sl); done++; }
      }
      if (done) g.draw(pl, 3);
    },
  },
  'Jacq': {
    canPlay: (g, pl) => g.P(1 - pl).prizes.length < 6,
    play: (g, pl) => H.search(g, pl, isEvolution, { max: 6 - g.P(1 - pl).prizes.length, title: 'Cerca Pokémon Evoluzione', purpose: 'searchHand' }),
  },
  'Cyrano': { play: (g, pl) => H.search(g, pl, ex, { max: 3, title: 'Cerca fino a 3 Pokémon-ex', purpose: 'searchHand' }) },
  "Ciphermaniac's Codebreaking": { play: (g, pl) => H.search(g, pl, () => true, { max: 2, min: 2, to: 'top', title: 'Scegli 2 carte da mettere in cima al mazzo', purpose: 'searchTop' }) },
  "Explorer's Guidance": {
    async play(g, pl) {
      const p = g.P(pl); const top = p.deck.slice(-6);
      const pick = await g.choose(pl, { t: 'cards', uids: top, min: Math.min(2, top.length), max: 2, title: 'Prime 6 carte: prendine 2, le altre vanno negli scarti', purpose: 'searchHand', from: 'deck', always: true, fullDeck: top });
      for (const u of top) g.moveTo(u, pick.includes(u) ? 'hand' : 'discard', pl);
    },
  },
  "Black Belt's Training": { async play(g, pl) { g.addMark({ kind: 'attackPlus', pl, until: g.s.turn, data: { n: 40, vs: 'ex' } }); } },
  'Kieran': {
    async play(g, pl) {
      const k = await g.choose(pl, { t: 'option', title: 'Scegli un effetto', options: ['Scambia il tuo Pokémon Attivo', '+30 danni ai Pokémon-ex e V attivi questo turno'], purpose: 'kieran' });
      if (k === 0) await g.switchOwn(pl);
      else g.addMark({ kind: 'attackPlus', pl, until: g.s.turn, data: { n: 30, vs: 'exv' } });
    },
  },
  "Professor Turo's Scenario": {
    async play(g, pl) {
      const [sl] = await g.chooseSlot(pl, g.slots(pl), 'Quale Pokémon riprendi in mano? (le carte assegnate vanno negli scarti)', 'bounce');
      if (!sl) return;
      const p = g.P(pl);
      for (const u of [...sl.energy, ...sl.tools, ...sl.cards.slice(0, -1)]) g.moveTo(u, 'discard', pl);
      const top = g.topUid(sl);
      if (p.active === sl) p.active = null; else p.bench.splice(p.bench.indexOf(sl), 1);
      p.hand.push(top);
      g.log(`${g.nameOf(top)} torna in mano`);
      await g.resolvePromotions();
    },
  },
  'Penny': {
    async play(g, pl) {
      const ok = g.slots(pl).filter(s => !g.isEvolved(s));
      const [sl] = await g.chooseSlot(pl, ok, 'Quale Pokémon Base riprendi in mano (con tutte le carte assegnate)?', 'bounce');
      if (!sl) return;
      const p = g.P(pl);
      for (const u of [...sl.energy, ...sl.tools, ...sl.cards]) p.hand.push(u);
      if (p.active === sl) p.active = null; else p.bench.splice(p.bench.indexOf(sl), 1);
      await g.resolvePromotions();
    },
  },
  "Morty's Conviction": {
    canPlay: (g, pl, uid) => others(g, pl, uid).length >= 1,
    async play(g, pl, uid) { await H.discardFromHand(g, pl, 1, { exclude: uid }); g.draw(pl, g.P(1 - pl).bench.length); },
  },
};
trainer['Professor Sada’s Vitality'] = trainer["Professor Sada's Vitality"];

function rareCandyPairs(g, pl) {
  const out = [];
  for (const u of g.P(pl).hand) {
    const c = g.card(u);
    if (!isPokemon(c) || c.s !== 'Stage2' || !c.f) continue;
    const basicName = LIB.prevo.get(c.f.toLowerCase());
    for (const sl of g.slots(pl)) {
      if (sl.cards.length !== 1 || !isBasicPokemon(g.top(sl))) continue;
      if (sl.playedTurn === g.s.turn || sl.evolvedTurn === g.s.turn) continue;
      if (basicName && sameName(basicName, g.top(sl).e)) out.push({ sl, uid: u });
    }
  }
  return out;
}
async function lookTop(g, pl, n, f, max, title) {
  const p = g.P(pl); const top = p.deck.slice(-n);
  const cand = top.filter(u => f(g.card(u)));
  const pick = await g.choose(pl, { t: 'cards', uids: cand, min: 0, max, title, purpose: 'searchHand', from: 'deck', always: true, fullDeck: top });
  for (const u of pick) g.moveTo(u, 'hand', pl);
  if (pick.length) g.log(`${p.name} prende ${pick.map(u => g.nameOf(u)).join(', ')}`);
  g.shuffleDeck(pl);
}

// ------------------------------------------------------------------ Oggetti Pokémon (Tool)
const tool = {
  'Bravery Charm': { hp: (g, sl, v) => isBasicPokemon(g.top(sl)) ? v + 50 : v },
  "Hero's Cape": { hp: (g, sl, v) => v + 100 },
  'Vitality Band': { attackBonus: (g, sl, v, x) => g.isActive(x.target) && x.target.owner !== sl.owner ? v + 10 : v },
  'Defiance Band': { attackBonus: (g, sl, v, x) => g.isActive(x.target) && x.target.owner !== sl.owner && moreRemaining(g, sl.owner) ? v + 30 : v },
  'Maximum Belt': { attackBonus: (g, sl, v, x) => g.isActive(x.target) && x.target.owner !== sl.owner && g.isEx(x.target) ? v + 50 : v },
  'Choice Belt': { attackBonus: (g, sl, v, x) => g.isActive(x.target) && x.target.owner !== sl.owner && g.isV(x.target) ? v + 30 : v },
  'Air Balloon': { retreat: (g, sl, v) => v - 2 },
  'Float Stone': { retreat: () => 0 },
  'Rescue Board': { retreat: (g, sl, v) => (g.remainingHp(sl) <= 30 ? 0 : v - 1) },
  'Sparkling Crystal': {
    attackCost(g, sl, cost) {
      if (!g.isTera(sl) || !cost.length) return cost;
      const units = g.provided(sl);
      for (let i = cost.length - 1; i >= 0; i--) { const c2 = [...cost]; c2.splice(i, 1); if (g.constructor.canPay(units, c2)) return c2; }
      return cost.slice(1);
    },
  },
  'Survival Brace': {
    damageTaken(g, sl, d, x) {
      if (sl.dmg === 0 && d >= g.maxHp(sl) && x?.ctx) {
        const t = sl.tools.find(u => g.card(u)?.e === 'Survival Brace');
        if (t) { x.ctx.after.push(async () => { if (g.slots(sl.owner).includes(sl)) g.discardCard(t); }); g.log(`${g.slotName(sl)} resiste grazie a Bretelle Sopravvivenza`); }
        return g.maxHp(sl) - 10;
      }
      return d;
    },
  },
};

// ------------------------------------------------------------------ Stadi
const stadium = {
  'Artazon': {
    canUse: (g, pl) => benchFree(g, pl) > 0,
    use: (g, pl) => H.search(g, pl, c => isBasicPokemon(c) && !hasRuleBox(c), { to: 'bench', title: 'Cerca un Pokémon Base senza Regola', purpose: 'searchBench' }),
  },
  'Mesagoza': { canUse: (g, pl) => true, async use(g, pl) { if (g.flip()) await H.search(g, pl, isPokemon, { title: 'Cerca un Pokémon', purpose: 'searchHand' }); } },
  'Town Store': { use: (g, pl) => H.search(g, pl, isTool, { title: 'Cerca un Oggetto Pokémon', purpose: 'searchHand' }) },
  'Area Zero Underdepths': { benchSize: (g, sl, v, pl) => g.slots(pl).some(s => g.isTera(s)) ? 8 : v },
  'Collapsed Stadium': { benchSize: (g, sl, v) => Math.min(v, 4) },
  'Jamming Tower': { blockTools: () => true },
  'Lively Stadium': { hp: (g, sl, v) => isBasicPokemon(g.top(sl)) ? v + 30 : v },
  'Gravity Mountain': { hp: (g, sl, v) => g.top(sl)?.s === 'Stage2' ? v - 30 : v },
  'Full Metal Lab': { damageTaken: (g, sl, d, x) => g.hasType(sl, 'Metal') && x?.ctx ? d - 30 : d },
  'Beach Court': { retreat: (g, sl, v) => isBasicPokemon(g.top(sl)) ? v - 1 : v },
  'Path to the Peak': { blockAbility: (g, sl) => !!sl && g.ruleBox(sl) },
  "Team Rocket's Watchtower": { blockAbility: (g, sl) => !!sl && g.hasType(sl, 'Colorless') },
};

// ------------------------------------------------------------------ Energie speciali
const energy = {
  'Double Turbo Energy': { provides: () => ['Colorless', 'Colorless'] },
  'Jet Energy': {
    provides: () => ['Colorless'],
    async onAttach(g, sl) { if (!g.isActive(sl) && await g.yesno(sl.owner, `Energia Jet: vuoi mandare ${g.slotName(sl)} in posizione attiva?`, 'jet')) g.switchActive(sl.owner, sl); },
  },
  'Gift Energy': { provides: () => ['Colorless'] },
  'Mist Energy': { provides: () => ['Colorless'] },
  'Therapeutic Energy': { provides: () => ['Colorless'] },
  'Luminous Energy': { provides: (g, sl, uid) => sl && sl.energy.some(u => u !== uid && isEnergy(g.card(u)) && !isBasicEnergy(g.card(u))) ? ['Colorless'] : ['ANY'] },
  'Legacy Energy': { provides: () => ['ANY'] },
  'Reversal Energy': { provides: (g, sl) => sl && moreRemaining(g, sl.owner) && g.isEvolved(sl) && !g.ruleBox(sl) ? ['ANY', 'ANY', 'ANY'] : ['Colorless'] },
  'Neo Upper Energy': { provides: (g, sl) => sl && g.top(sl)?.s === 'Stage2' ? ['ANY', 'ANY'] : ['Colorless'] },
  'Enriching Energy': { provides: () => ['Colorless'], onAttach: async g => g.draw(g.s.cur, 4) },
  'Spiky Energy': { provides: () => ['Colorless'] },
  'Boomerang Energy': { provides: () => ['Colorless'] },
  'Prism Energy': { provides: (g, sl) => sl && isBasicPokemon(g.top(sl)) ? ['ANY'] : ['Colorless'] },
};

// ------------------------------------------------------------------ abilità
const anyBench = (g, pl) => g.P(pl).bench.length > 0;
const abilities = {
  'Pidgeot ex': { 'Quick Search': { canUse: (g, pl) => g.P(pl).deck.length > 0 && !g.slots(pl).some(s => s.used['Quick Search'] === g.s.turn), use: (g, pl) => H.search(g, pl, () => true, { title: 'Cerca una carta qualsiasi', purpose: 'searchHand' }) } },
  'Charizard ex': {
    'Infernal Reign': { onEvolve: true, async use(g, pl) {
      await H.search(g, pl, typeIs('Fire'), { max: 3, to: 'none', title: 'Cerca fino a 3 Energie Fuoco base da assegnare', purpose: 'searchEnergy', attachTo: uids => H.attachEach(g, pl, uids, g.slots(pl)) });
    } },
  },
  'Gardevoir ex': {
    'Psychic Embrace': {
      once: false,
      canUse: (g, pl) => g.P(pl).discard.some(u => typeIs('Psychic')(g.card(u))) && g.slots(pl).some(s => g.hasType(s, 'Psychic') && g.remainingHp(s) > 20),
      async use(g, pl) {
        const [u] = await g.choose(pl, { t: 'cards', uids: g.P(pl).discard.filter(x => typeIs('Psychic')(g.card(x))), title: 'Energia Psico dagli scarti', purpose: 'attachPick', from: 'discard' });
        const [sl] = await g.chooseSlot(pl, g.slots(pl).filter(s => g.hasType(s, 'Psychic') && g.remainingHp(s) > 20), 'A quale Pokémon Psico la assegni? (+2 segnalini danno)', 'attachTarget', { energy: u });
        if (u && sl) { await g.attachEnergy(u, sl); sl.dmg += 20; g.log(`2 segnalini danno su ${g.slotName(sl)}`); }
      },
    },
  },
  'Kirlia': { 'Refinement': { canUse: (g, pl) => g.P(pl).hand.length > 0, async use(g, pl) { await H.discardFromHand(g, pl, 1); g.draw(pl, 2); } } },
  'Drakloak': {
    'Recon Directive': {
      canUse: (g, pl) => g.P(pl).deck.length > 0,
      async use(g, pl) {
        const p = g.P(pl); const top = p.deck.slice(-2);
        const [u] = await g.choose(pl, { t: 'cards', uids: top, min: 1, max: 1, title: 'Prima 2 carte: una va in mano, l\'altra in fondo al mazzo', purpose: 'searchHand', from: 'deck', always: true });
        g.moveTo(u, 'hand', pl);
        for (const x of top) if (x !== u) { g.removeFromZones(x); p.deck.unshift(x); }
      },
    },
  },
  'Dusknoir': { 'Cursed Blast': { cursed: 13, use: cursedBlast(13) } },
  'Dusclops': { 'Cursed Blast': { cursed: 5, use: cursedBlast(5) } },
  'Fezandipiti ex': { 'Flip the Script': { canUse: (g, pl) => g.s.tf.koByOpp && !g.slots(pl).some(s => s.used['Flip the Script'] === g.s.turn), use: (g, pl) => { g.draw(pl, 3); } } },
  'Munkidori': {
    'Adrena-Brain': {
      canUse: (g, pl, sl) => g.energyCards(sl, 'Darkness').length > 0 && g.slots(pl).some(s => s.dmg > 0),
      async use(g, pl) {
        const [from] = await g.chooseSlot(pl, g.slots(pl).filter(s => s.dmg > 0), 'Da quale tuo Pokémon sposti i segnalini?', 'healTarget');
        const [to] = await g.chooseSlot(pl, g.slots(1 - pl), 'Su quale Pokémon avversario li metti?', 'damageTarget');
        const n = Math.min(3, from.dmg / 10);
        from.dmg -= n * 10; to.dmg += n * 10;
        g.log(`${n} segnalini spostati da ${g.slotName(from)} a ${g.slotName(to)}`);
      },
    },
  },
  'Teal Mask Ogerpon ex': {
    'Teal Dance': {
      canUse: (g, pl) => g.P(pl).hand.some(u => typeIs('Grass')(g.card(u))),
      async use(g, pl, sl) {
        const [u] = await g.choose(pl, { t: 'cards', uids: g.P(pl).hand.filter(x => typeIs('Grass')(g.card(x))), title: 'Energia Erba base dalla mano', purpose: 'attachPick', from: 'hand' });
        if (u) { await g.attachEnergy(u, sl); g.draw(pl, 1); }
      },
    },
  },
  'Noctowl': {
    'Jewel Seeker': { onEvolve: true, canUse: (g, pl) => g.slots(pl).some(s => g.isTera(s)), use: (g, pl) => H.search(g, pl, isTrainer, { max: 2, title: 'Cerca fino a 2 carte Allenatore', purpose: 'searchHand' }) },
  },
  'Lunatone': {
    'Lunar Cycle': {
      canUse: (g, pl) => g.slots(pl).some(s => g.top(s).e === 'Solrock') && g.P(pl).hand.some(u => typeIs('Fighting')(g.card(u))),
      async use(g, pl) { await H.discardFromHand(g, pl, 1, { f: typeIs('Fighting'), title: 'Scarta una Energia Lotta base' }); g.draw(pl, 3); },
    },
  },
  'Hariyama': { 'Heave-Ho Catcher': { onEvolve: true, canUse: (g, pl) => g.P(1 - pl).bench.length > 0, use: (g, pl) => g.gust(pl) } },
  'Archaludon ex': {
    'Assemble Alloy': { onEvolve: true, use: (g, pl) => H.fromDiscardAttach(g, pl, typeIs('Metal'), 2, g.slots(pl).filter(s => g.hasType(s, 'Metal'))) },
  },
  'Squawkabilly ex': { 'Squawk and Seize': { canUse: (g, pl) => g.isOwnFirstTurn(pl), async use(g, pl) { const p = g.P(pl); for (const u of [...p.hand]) g.discardCard(u); g.draw(pl, 6); } } },
  'Radiant Greninja': { 'Concealed Cards': { canUse: (g, pl) => g.P(pl).hand.some(u => isEnergy(g.card(u))), async use(g, pl) { await H.discardFromHand(g, pl, 1, { f: isEnergy, title: 'Scarta una carta Energia' }); g.draw(pl, 2); } } },
  'Miraidon ex': { 'Tandem Unit': { canUse: (g, pl) => benchFree(g, pl) > 0 && !g.slots(pl).some(s => s.used['Tandem Unit'] === g.s.turn), use: (g, pl) => H.search(g, pl, c => isBasicPokemon(c) && c.t?.includes('Lightning'), { max: 2, to: 'bench', title: 'Cerca fino a 2 Pokémon Base Lampo', purpose: 'searchBench' }) } },
  'Mew ex': { 'Restart': { canUse: (g, pl) => g.P(pl).hand.length < 3, use: (g, pl) => H.drawUntil(g, pl, 3) } },
  'Bibarel': { 'Industrious Incisors': { canUse: (g, pl) => g.P(pl).hand.length < 5, use: (g, pl) => H.drawUntil(g, pl, 5) } },
  'Gholdengo ex': { 'Coin Bonus': { canUse: (g, pl) => !g.slots(pl).some(s => s.used['Coin Bonus'] === g.s.turn), use: (g, pl, sl) => { g.draw(pl, g.isActive(sl) ? 2 : 1); } } },
  'Gimmighoul': {},
  'Pecharunt ex': {
    'Subjugating Chains': {
      canUse: (g, pl) => g.P(pl).bench.some(s => g.hasType(s, 'Darkness') && g.top(s).e !== 'Pecharunt ex') && !g.slots(pl).some(s => s.used['Subjugating Chains'] === g.s.turn),
      async use(g, pl) {
        const [sl] = await g.chooseSlot(pl, g.P(pl).bench.filter(s => g.hasType(s, 'Darkness') && g.top(s).e !== 'Pecharunt ex'), 'Quale Pokémon Oscurità mandi in posizione attiva?', 'switchOwn');
        if (sl) { g.switchActive(pl, sl); g.setCondition(sl, 'poisoned'); }
      },
    },
  },
  'Baxcalibur': {
    'Super Cold': {
      once: false,
      canUse: (g, pl) => g.P(pl).hand.some(u => typeIs('Water')(g.card(u))) && g.slots(pl).some(s => g.hasType(s, 'Water')),
      async use(g, pl) {
        const uids = await g.choose(pl, { t: 'cards', uids: g.P(pl).hand.filter(u => typeIs('Water')(g.card(u))), min: 1, max: 9, title: 'Energie Acqua base da assegnare', purpose: 'attachPick', from: 'hand' });
        await H.attachEach(g, pl, uids, g.slots(pl).filter(s => g.hasType(s, 'Water')));
      },
    },
  },
  'Chien-Pao ex': { 'Shivery Chill': { activeOnly: true, canUse: (g, pl) => !g.slots(pl).some(s => s.used['Shivery Chill'] === g.s.turn), use: (g, pl) => H.search(g, pl, typeIs('Water'), { max: 2, title: 'Cerca fino a 2 Energie Acqua base', purpose: 'searchEnergyHand' }) } },
  'Lumineon V': { 'Luminous Sign': { onBench: true, use: (g, pl) => H.search(g, pl, isSupporter, { title: 'Cerca un Aiuto', purpose: 'searchHand' }) } },
};
function cursedBlast(n) {
  return async (g, pl, sl) => {
    const [t] = await g.chooseSlot(pl, g.slots(1 - pl), `Su quale Pokémon metti ${n} segnalini danno?`, 'damageTarget', { counters: n });
    const ctx = { pl, opp: 1 - pl, attacker: sl, after: [], dealt: 0 };
    if (t) await g.placeCounters(ctx, t, n);
    sl.dmg = g.maxHp(sl);
    g.log(`${g.slotName(sl)} si mette KO da solo`);
    g.checkKO();
    await g.resolvePromotions();
  };
}
H.fromDiscardAttach = async (g, pl, f, max, slots) => {
  const cand = g.P(pl).discard.filter(u => f(g.card(u)));
  if (!cand.length || !slots.length) return;
  const pick = await g.choose(pl, { t: 'cards', uids: cand, min: 0, max: Math.min(max, cand.length), title: 'Energie dagli scarti da assegnare', purpose: 'attachPick', from: 'discard', always: true });
  await H.attachEach(g, pl, pick, slots);
};

// ------------------------------------------------------------------ abilità passive (modificatori)
const passive = {
  "Lillie's Clefairy ex": { weakness: (g, own, sl, v) => sl && sl.owner !== own.owner && g.hasType(sl, 'Dragon') ? [...v, { t: 'Psychic', v: '×2' }] : v },
  'Manaphy': { preventDamage: (g, own, sl, v, x) => v || (!!sl && sl.owner === own.owner && !g.isActive(sl) && x?.ctx && x.ctx.pl !== own.owner) },
  'Flutter Mane': { blockAbility: (g, own, sl) => g.isActive(own) && !!sl && g.isActive(sl) && sl.owner !== own.owner },
  'Klefki': { blockAbility: (g, own, sl) => g.isActive(own) && !!sl && isBasicPokemon(g.top(sl)) && sl !== own },
};

// ------------------------------------------------------------------ attacchi scritti a mano
const attacks = {
  'Dragapult ex': {
    'Phantom Dive': { async after(g, c) { await H.distribute(g, c.pl, c, g.P(c.opp).bench, 6, { title: 'Phantom Dive: distribuisci 6 segnalini sulla Panchina avversaria' }); } },
  },
  'Raging Bolt ex': {
    'Burst Roar': { async after(g, c) { const p = g.P(c.pl); for (const u of [...p.hand]) g.discardCard(u); g.draw(c.pl, 6); } },
    'Bellowing Thunder': {
      async before(g, c) {
        const mine = g.slots(c.pl).flatMap(s => s.energy.filter(u => isBasicEnergy(g.card(u))));
        const pick = await g.choose(c.pl, { t: 'cards', uids: mine, min: 0, max: mine.length, title: 'Scarta Energie base dai tuoi Pokémon: 70 danni per ognuna', purpose: 'bellowing', always: true });
        for (const u of pick) g.discardCard(u);
        c.damage = 70 * pick.length;
      },
    },
  },
  'Terapagos ex': {
    'Unified Beatdown': { canUse: (g, pl) => !(g.s.turn === 2 && pl !== g.s.first), before: async (g, c) => { c.damage = 30 * g.P(c.pl).bench.length; } },
    'Crown Opal': { async after(g, c) { g.addMark({ kind: 'preventDamage', sid: c.attacker.sid, until: g.s.turn + 1, data: { from: 'basicNonColorless' } }); } },
  },
  'Mega Lucario ex': {
    'Aura Jab': { async after(g, c) { await H.fromDiscardAttach(g, c.pl, typeIs('Fighting'), 3, g.P(c.pl).bench); } },
    'Mega Brave': { async after(g, c) { g.addMark({ kind: 'noAttack', sid: c.attacker.sid, until: g.s.turn + 2, persist: true, data: { name: 'Mega Brave' } }); } },
  },
  'Archaludon ex': { 'Metal Defender': { async after(g, c) { g.addMark({ kind: 'noWeakness', sid: c.attacker.sid, until: g.s.turn + 1 }); } } },
  'Charizard ex': { 'Burning Darkness': { before: async (g, c) => { c.damage += 30 * (6 - g.P(c.opp).prizes.length); } } },
  'Gardevoir ex': { 'Miracle Force': { after: async (g, c) => g.clearConditions(c.attacker) } },
  'Iron Hands ex': { 'Amp You Very Much': { after: async (g, c) => { const d = g.P(c.opp).active; if (d && d.dmg >= g.maxHp(d)) g.addMark({ kind: 'extraPrize', sid: d.sid, until: g.s.turn }); } } },
  'Miraidon ex': { 'Photon Blaster': { after: async (g, c) => g.addMark({ kind: 'noAttack', sid: c.attacker.sid, until: g.s.turn + 2, persist: true }) } },
  'Roaring Moon ex': {
    'Frenzied Gouging': { noBaseDamage: true, async after(g, c) { const d = g.P(c.opp).active; if (d) { d.dmg = Math.max(d.dmg, g.maxHp(d)); g.log(`${g.slotName(d)} viene messo KO`); } await g.applyDamage(c, c.attacker, 200); } },
    'Calamity Storm': { async before(g, c) { if (g.s.stadium && await g.yesno(c.pl, 'Vuoi scartare lo Stadio in gioco per fare 120 danni in più?', 'discardStadium')) { g.discardCard(g.s.stadium.uid); c.damage += 120; } } },
  },
  'Gholdengo ex': {
    'Make It Rain': {
      async before(g, c) {
        const cand = g.P(c.pl).hand.filter(u => isBasicEnergy(g.card(u)));
        const pick = await g.choose(c.pl, { t: 'cards', uids: cand, min: 0, max: cand.length, title: 'Scarta Energie base dalla mano: 50 danni per ognuna', purpose: 'makeItRain', always: true });
        for (const u of pick) g.discardCard(u);
        c.damage = 50 * pick.length;
      },
    },
  },
  'Gimmighoul': { 'Minor Errand-Running': { noBaseDamage: true, after: (g, c) => H.search(g, c.pl, isBasicEnergy, { max: 2, title: 'Cerca fino a 2 Energie base', purpose: 'searchEnergyHand' }) } },
  'Chien-Pao ex': {
    'Hail Blade': {
      async before(g, c) {
        const mine = g.slots(c.pl).flatMap(s => s.energy.filter(u => typeIs('Water')(g.card(u))));
        const pick = await g.choose(c.pl, { t: 'cards', uids: mine, min: 0, max: mine.length, title: 'Scarta Energie Acqua dai tuoi Pokémon: 60 danni per ognuna', purpose: 'bellowing', always: true });
        for (const u of pick) g.discardCard(u);
        c.damage = 60 * pick.length;
      },
    },
  },
  'Budew': { 'Itchy Pollen': { after: async (g, c) => g.addMark({ kind: 'itemLock', pl: c.opp, until: g.s.turn + 1 }) } },
  'Duskull': {
    'Come and Get You': {
      noBaseDamage: true,
      canUse: (g, pl) => benchFree(g, pl) > 0,
      async after(g, c) {
        const p = g.P(c.pl);
        const cand = p.discard.filter(u => g.card(u)?.e === 'Duskull');
        const pick = await g.choose(c.pl, { t: 'cards', uids: cand, min: 0, max: Math.min(3, benchFree(g, c.pl), cand.length), title: 'Metti in Panchina fino a 3 Duskull dagli scarti', purpose: 'searchBench', from: 'discard', always: true });
        for (const u of pick) { g.removeFromZones(u); p.bench.push(g.newSlot(u, c.pl)); }
      },
    },
  },
  'Mew ex': {
    'Genome Hacking': {
      async before(g, c) {
        const opp = g.P(c.opp).active;
        const atks = opp ? g.attacksOf(opp) : [];
        if (!atks.length) { c.skip = true; return; }
        const k = await g.choose(c.pl, { t: 'option', title: "Quale attacco dell'avversario copi?", options: atks.map(a => `${a.n}${a.d ? ' (' + a.d + ')' : ''}`), purpose: 'copyAttack', atks });
        const atk = atks[k] || atks[0];
        c.atk = atk; c.damage = parseInt(atk.d, 10) || 0;
        c.copied = g.lib.attackDef(g, g.top(opp), atk) || {};
        g.log(`Copia l'attacco ${atk.n}`);
        if (c.copied.before) await c.copied.before(g, c);
      },
      async after(g, c) { if (c.copied?.after) await c.copied.after(g, c); },
    },
  },
  'Fezandipiti ex': { 'Cruel Arrow': { noBaseDamage: true, async after(g, c) { const [t] = await g.chooseSlot(c.pl, g.slots(c.opp), 'Scegli il Pokémon che subisce 100 danni', 'damageTarget'); if (t) { if (g.isActive(t)) await g.applyDamage(c, t, g.computeDamage(c, t, 100, true)); else await g.benchDamage(c, t, 100); } } } },
};

// ------------------------------------------------------------------ segnalini temporanei
const marks = {
  reduceDamage: { damageTaken: (g, m, sl, d, x) => sl && m.sid === sl.sid && x?.ctx ? d - m.data.n : d },
  defenderWeaker: { attackBonus: (g, m, sl, d) => sl && m.sid === sl.sid ? d - m.data.n : d },
  noWeakness: { weakness: (g, m, sl, v) => sl && m.sid === sl.sid ? [] : v },
  attackPlus: {
    attackBonus(g, m, sl, d, x) {
      if (!sl || sl.owner !== m.pl || !g.isActive(x.target) || x.target.owner === m.pl) return d;
      if (m.data.vs === 'ex' && !g.isEx(x.target)) return d;
      if (m.data.vs === 'exv' && !g.isEx(x.target) && !g.isV(x.target)) return d;
      return d + m.data.n;
    },
  },
  preventDamage: {
    preventDamage(g, m, sl, v, x) {
      if (v || !sl || m.sid !== sl.sid || !x?.ctx?.attacker) return v;
      const a = x.ctx.attacker, f = m.data?.from;
      if (!f) return true;
      if (f === 'basic') return !g.isEvolved(a);
      if (f === 'evolution') return g.isEvolved(a);
      if (f === 'ex') return g.isEx(a);
      if (f === 'basicNonColorless') return !g.isEvolved(a) && !g.hasType(a, 'Colorless');
      if (f === 'ability') return !!g.top(a).b?.length;
      return v;
    },
  },
  extraPrize: { prizeValue: (g, m, sl, v) => sl && m.sid === sl.sid ? v + 1 : v },
};

// ------------------------------------------------------------------ libreria esportata
const parsedCache = new Map();
function parsed(text) {
  let p = parsedCache.get(text);
  if (!p) { p = parseText(text); parsedCache.set(text, p); }
  return p;
}
const manualText = p => p.unknown.length ? p.unknown.join('. ') : null;

export const LIB = {
  trainer, tool, stadium, energy, passive, marks, attacks, abilities,
  prevo: new Map(),           // nome (minuscolo) Pokémon di Fase 1 -> nome del Base da cui si evolve
  /** Prepara l'indice delle evoluzioni (per Caramella Rara) */
  setCards(list) {
    for (const c of list) if (c.c === 'P' && c.s === 'Stage1' && c.f && !this.prevo.has(c.e.toLowerCase())) this.prevo.set(c.e.toLowerCase(), c.f);
  },

  attackDef(g, card, atk) {
    const hand = attacks[card.e]?.[atk.e];
    if (hand) return hand;
    if (!atk.y) return null;
    const p = parsed(atk.y);
    return {
      before: p.before.length ? async (g2, c) => { for (const f of p.before) await f(g2, c); } : null,
      after: p.after.length ? async (g2, c) => { for (const f of p.after) await f(g2, c); } : null,
      manual: manualText(p),
    };
  },

  abilityDef(g, card, ab) {
    const hand = abilities[card.e]?.[ab.e];
    if (hand) return hand;
    if (passive[card.e]) return { passive: true };
    const t = normText(ab.y);
    const m = t.match(/^once during your turn,? (?:if this pokemon is in the active spot, )?you may (.+)$/) || t.match(/^as often as you like during your turn,? you may (.+)$/);
    if (!m) return { passive: true, manual: ab.y };
    const p = parsed(m[1]);
    if (!p.before.length && !p.after.length) return { passive: true, manual: ab.y };
    return {
      once: !/^as often/.test(t), activeOnly: /active spot/.test(t.slice(0, 60)),
      async use(g2, pl, sl) {
        const c = { pl, opp: 1 - pl, source: sl, attacker: sl, after: [], dealt: 0, damage: 0 };
        for (const f of [...p.before, ...p.after]) await f(g2, c);
        if (p.unknown.length && !g2.sim) g2.manualNotes.push({ pl, text: manualText(p), it: ab.x || ab.y, card: card.n, what: ab.n });
      },
    };
  },

  parsedTrainer(g, card) {
    const p = parsed(card.y || '');
    return {
      canPlay: (g2, pl, uid) => others(g2, pl, uid).length >= p.costDiscard,
      async play(g2, pl, uid) {
        if (p.costDiscard) await H.discardFromHand(g2, pl, p.costDiscard, { exclude: uid });
        const c = { pl, opp: 1 - pl, source: null, attacker: g2.P(pl).active, after: [], dealt: 0, damage: 0 };
        for (const f of [...p.before, ...p.after]) await f(g2, c);
        if (p.unknown.length && !g2.sim) g2.manualNotes.push({ pl, text: manualText(p), it: card.x || card.y, card: card.n, what: '' });
      },
      auto: !p.unknown.length,
    };
  },

  /** l'effetto della carta è automatico? (per segnalarlo nell'interfaccia) */
  isAutomatic(card) {
    if (!card) return true;
    if (card.c === 'T') {
      if (trainer[card.e] || tool[card.e] || stadium[card.e]) return true;
      if (isTool(card) || isStadium(card)) return false;
      return !parsed(card.y || '').unknown.length;
    }
    if (card.c === 'E') return isBasicEnergy(card) || !!energy[card.e];
    for (const a of card.a || []) if (!attacks[card.e]?.[a.e] && a.y && parsed(a.y).unknown.length) return false;
    for (const b of card.b || []) { const d = this.abilityDef(null, card, b); if (d?.manual && !passive[card.e]) return false; }
    return true;
  },

  // ---- eventi
  async onEvolve(g, pl, sl, uid) {
    const c = g.card(uid);
    for (const ab of c.b || []) {
      const def = abilities[c.e]?.[ab.e];
      if (!def?.onEvolve || g.abilityBlocked(sl)) continue;
      if (def.canUse && !def.canUse(g, pl, sl)) continue;
      if (!(await g.yesno(pl, `Vuoi usare l'abilità ${ab.n}?`, 'evolveAbility', ab.x || ab.y))) continue;
      g.log(`${g.P(pl).name} usa l'abilità ${ab.n}`);
      await def.use(g, pl, sl, ab);
    }
  },
  async onPlayToBench(g, pl, sl) {
    const c = g.top(sl);
    for (const ab of c.b || []) {
      const def = abilities[c.e]?.[ab.e];
      if (!def?.onBench || (def.vstar && g.s.vstarUsed[pl])) continue;
      if (!(await g.yesno(pl, `Vuoi usare l'abilità ${ab.n}?`, 'benchAbility', ab.x || ab.y))) continue;
      await def.use(g, pl, sl, ab);
    }
  },
  onKO(g, sl) {
    // Energia Dono: chi la possiede pesca fino ad avere 7 carte
    if (sl.energy.some(u => g.card(u)?.e === 'Gift Energy')) {
      const p = g.P(sl.owner); const k = 7 - p.hand.length; if (k > 0) g.draw(sl.owner, k);
    }
  },
  async afterTrainer() {},
  cannotEvolve: () => false,
};
LIB.prizeValueOf = prizeValueOf;
