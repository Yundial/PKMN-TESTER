// Database delle carte (dati TCGdex preparati da tools/build_data.py), ricerca, filtri e testi in italiano.
import { LIB } from './engine/effects.js';
import { TYPES, TYPE_IT, isPokemon, isTrainer, isEnergy, isBasicPokemon, isBasicEnergy, isSupporter, isItem, isStadium, isTool,
  isAceSpec, isRadiant, isPokemonEx, isPokemonV, isTeraCard, prizeValueOf, energyTypeOfName } from './engine/core.js';

export { TYPES, TYPE_IT };
export const DB = { cards: new Map(), list: [], sets: new Map(), setByCode: new Map(), bots: [], version: '', ready: false };

export function normalize(s) { return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’']/g, "'"); }

async function fetchJson(url, onBytes) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url}: ${res.status}`);
  if (!onBytes || !res.body) return res.json();
  const total = +res.headers.get('content-length') || 0;
  const reader = res.body.getReader();
  const chunks = []; let got = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value); got += value.length;
    onBytes(got, total);
  }
  const all = new Uint8Array(got); let o = 0;
  for (const c of chunks) { all.set(c, o); o += c.length; }
  return JSON.parse(new TextDecoder().decode(all));
}

export async function loadData(progress = () => {}) {
  let v = '';
  try { v = (await fetchJson('data/version.json')).v || ''; } catch (_) {}
  DB.version = v;
  const q = v ? '?v=' + encodeURIComponent(v) : '';
  progress('Carico le carte…', 0.05);
  const [list, sets, bots] = await Promise.all([
    fetchJson('data/cards.json' + q, (got, tot) => progress(`Carico le carte… ${(got / 1048576).toFixed(1)} MB`, tot ? 0.05 + 0.85 * got / tot : 0.5)),
    fetchJson('data/sets.json' + q),
    fetchJson('data/bots.json' + q).catch(() => []),
  ]);
  progress('Preparo la ricerca…', 0.95);
  DB.list = list;
  for (const c of list) {
    c._n = normalize(c.n); c._e = normalize(c.e);
    DB.cards.set(c.i, c);
  }
  for (const s of sets) { DB.sets.set(s.i, s); if (s.code) DB.setByCode.set(s.code.toUpperCase(), s); }
  DB.setOrder = new Map([...sets].sort((a, b) => (a.d || '').localeCompare(b.d || '')).map((s, k) => [s.i, k]));
  DB.bots = bots;
  LIB.setCards(list);
  DB.ready = true;
}

export const card = id => DB.cards.get(id) || null;
export const cardName = id => card(id)?.n || String(id || '?');
export const setOf = c => DB.sets.get(c?.st) || null;
export function printCode(c) {
  const s = setOf(c);
  return `${s?.code || (c?.st || '').toUpperCase()} ${c?.no || ''}`.trim();
}
export function imageUrl(id, big = false, english = false) {
  const c = card(id);
  const base = english ? (c?.ie || c?.im) : c?.im;
  if (!base) return '';
  return `${base}/${big ? 'high' : 'low'}.webp`;
}

// ------------------------------------------------------------------ descrizioni
const STAGE_IT = { Basic: 'Base', Stage1: 'Fase 1', Stage2: 'Fase 2', VMAX: 'VMAX', VSTAR: 'V ASTRO', BREAK: 'TURBO', MEGA: 'Mega', 'LEVEL-UP': 'LIV.X', VUNION: 'V-UNION', Restored: 'Fossile' };
const TT_IT = { Item: 'Strumento', Supporter: 'Aiuto', Stadium: 'Stadio', Tool: 'Oggetto Pokémon', 'Technical Machine': 'Macchina Tecnica' };
export const stageName = s => STAGE_IT[s] || s || '';
export function typeLine(c) {
  if (!c) return '';
  if (isPokemon(c)) {
    const tags = [];
    if (isPokemonEx(c)) tags.push(prizeValueOf(c) === 3 ? 'Mega ex' : 'Pokémon-ex');
    else if (isPokemonV(c)) tags.push(c.e.split(' ').pop());
    if (isTeraCard(c)) tags.push('Teracristal');
    if (isRadiant(c)) tags.push('Radioso');
    return `Pokémon ${stageName(isBasicPokemon(c) ? 'Basic' : c.s)} · ${(c.t || []).map(t => TYPE_IT[t] || t).join('/')}${tags.length ? ' · ' + tags.join(', ') : ''}`;
  }
  if (isTrainer(c)) return `Allenatore · ${TT_IT[c.tt] || c.tt}${isAceSpec(c) ? ' · ASSO TATTICO' : ''}`;
  if (isEnergy(c)) return isBasicEnergy(c) ? `Energia base ${TYPE_IT[energyTypeOfName(c.e)] || ''}` : 'Energia speciale';
  return '';
}
export function statLine(c) {
  if (!isPokemon(c)) return '';
  const w = (c.w || []).map(x => `${TYPE_IT[x.t] || x.t} ${x.v}`).join(', ');
  const r = (c.r || []).map(x => `${TYPE_IT[x.t] || x.t} ${x.v}`).join(', ');
  return `${c.hp} PS${w ? ' · Debolezza ' + w : ''}${r ? ' · Resistenza ' + r : ''} · Ritirata ${c.rt ?? 0}`;
}
export function legalLabel(c) {
  const s = [];
  if (c.l & 1) s.push('Standard'); if (c.l & 2) s.push('Expanded');
  return (s.length ? s.join(' + ') : 'non legale nei formati attuali') + (c.rm ? ` · regolamento ${c.rm}` : '');
}

// ------------------------------------------------------------------ ricerca
const byNewest = (a, b) => ((b.l & 1) - (a.l & 1)) || ((DB.setOrder.get(b.st) || 0) - (DB.setOrder.get(a.st) || 0)) || a.no.localeCompare(b.no, undefined, { numeric: true });

export function search(query, limit = 300) {
  const q = normalize(query).trim();
  if (q.length < 2) return [];
  const starts = [], inside = [];
  for (const c of DB.list) {
    const hitIt = c._n.includes(q), hitEn = c._e.includes(q);
    if (!hitIt && !hitEn) continue;
    (c._n.startsWith(q) || c._e.startsWith(q) ? starts : inside).push(c);
  }
  starts.sort(byNewest); inside.sort(byNewest);
  return [...starts, ...inside].slice(0, limit);
}

/** Codice di stampa: "TWM 130", "TWM130", "sv06-130" o solo l'id */
export function searchCode(query) {
  const q = (query || '').trim();
  if (!q) return [];
  if (DB.cards.has(q)) return [DB.cards.get(q)];
  if (DB.cards.has(q.toLowerCase())) return [DB.cards.get(q.toLowerCase())];
  const m = q.toUpperCase().replace(/[-_]/g, ' ').match(/^([A-Z][A-Z0-9.]*?)\s*(\d+[A-Z]?)?$/);
  if (!m) return [];
  const set = DB.setByCode.get(m[1]) || [...DB.sets.values()].find(s => s.i.toUpperCase() === m[1]);
  if (!set) return [];
  const list = DB.list.filter(c => c.st === set.i);
  if (!m[2]) return list.slice(0, 400);
  const num = m[2].replace(/^0+/, '');
  return list.filter(c => c.no.replace(/^0+/, '').toUpperCase() === num);
}

export const emptyFilter = () => ({ kind: 0, types: [], stages: [], rules: [], tts: [], energy: 0, hpMin: null, hpMax: null, retreat: [], weak: [], ability: false, format: 0, marks: [], set: '' });
export const filterCount = f => f.types.length + f.stages.length + f.rules.length + f.tts.length + (f.energy ? 1 : 0) + (f.hpMin != null) + (f.hpMax != null) + f.retreat.length + f.weak.length + (f.ability ? 1 : 0) + (f.format ? 1 : 0) + f.marks.length + (f.set ? 1 : 0) + (f.kind ? 1 : 0);
export const filterActive = f => filterCount(f) > 0;

function ruleOf(c) {
  if (isPokemonEx(c)) return prizeValueOf(c) === 3 ? 'mega' : 'ex';
  if (isPokemonV(c)) return 'v';
  if (isRadiant(c)) return 'radiant';
  return 'none';
}
export function matchFilter(c, f) {
  if (f.format === 1 && !(c.l & 1)) return false;
  if (f.format === 2 && !(c.l & 2)) return false;
  if (f.marks.length && !f.marks.includes(c.rm)) return false;
  if (f.set && c.st !== f.set) return false;
  if (f.kind === 1) {
    if (!isPokemon(c)) return false;
    if (f.types.length && !c.t.some(t => f.types.includes(t))) return false;
    if (f.stages.length && !f.stages.includes(isBasicPokemon(c) ? 'Basic' : (['Stage1', 'Stage2'].includes(c.s) ? c.s : 'Other'))) return false;
    if (f.rules.length) {
      const r = ruleOf(c);
      const ok = f.rules.some(x => x === r || (x === 'tera' && isTeraCard(c)));
      if (!ok) return false;
    }
    if (f.hpMin != null && c.hp < f.hpMin) return false;
    if (f.hpMax != null && c.hp > f.hpMax) return false;
    if (f.retreat.length && !f.retreat.includes(Math.min(4, c.rt || 0))) return false;
    if (f.weak.length && !(c.w || []).some(w => f.weak.includes(w.t))) return false;
    if (f.ability && !(c.b || []).length) return false;
  } else if (f.kind === 2) {
    if (!isTrainer(c)) return false;
    if (f.tts.length && !f.tts.some(t => t === 'ace' ? isAceSpec(c) : t === 'Item' ? isItem(c) : t === 'Supporter' ? isSupporter(c) : t === 'Stadium' ? isStadium(c) : isTool(c))) return false;
  } else if (f.kind === 3) {
    if (!isEnergy(c)) return false;
    if (f.energy === 1 && !isBasicEnergy(c)) return false;
    if (f.energy === 2 && isBasicEnergy(c)) return false;
    if (f.types.length && !(isBasicEnergy(c) && f.types.includes(energyTypeOfName(c.e)))) return false;
  }
  return true;
}
export function searchFiltered(f, query = '', limit = 300) {
  const q = normalize(query).trim();
  const out = [];
  for (const c of DB.list) {
    if (q && !c._n.includes(q) && !c._e.includes(q)) continue;
    if (matchFilter(c, f)) out.push(c);
  }
  out.sort(byNewest);
  return out.slice(0, limit);
}
export function regulationMarks() { return [...new Set(DB.list.map(c => c.rm).filter(Boolean))].sort(); }
export function recentSets(n = 80) { return [...DB.sets.values()].sort((a, b) => (b.d || '').localeCompare(a.d || '')).slice(0, n); }
