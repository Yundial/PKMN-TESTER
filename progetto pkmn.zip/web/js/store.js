// Archivio dei mazzi (memoria del dispositivo), mazzi avversari modificati, backup e liste in formato Pokémon TCG Live.
import { DB, card, cardName, printCode, normalize } from './data.js';
import { isPokemon, isTrainer, isEnergy, isBasicPokemon, isBasicEnergy, isAceSpec, isRadiant, energyTypeOfName } from './engine/core.js';

const K_DECKS = 'pkt.decks', K_BOT = 'pkt.botmods', K_OPTS = 'pkt.opts';
function read(key, def) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : def; } catch (_) { return def; } }
function write(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); return true; } catch (_) { return false; } }
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));

export const Store = {
  decks: read(K_DECKS, []),
  botMods: read(K_BOT, {}),
  opts: Object.assign({ speed: 1, confirmEnd: true }, read(K_OPTS, {})),
  save() { return write(K_DECKS, this.decks); },
  saveOpts() { write(K_OPTS, this.opts); },
  get(id) { return this.decks.find(d => d.id === id) || null; },
  upsert(d) {
    d.updated = Date.now();
    const i = this.decks.findIndex(x => x.id === d.id);
    if (i >= 0) this.decks[i] = d; else this.decks.unshift(d);
    this.save();
  },
  create(name = 'Nuovo mazzo') { const d = { id: uid(), name, cards: [], updated: Date.now() }; this.upsert(d); return d; },
  remove(id) { this.decks = this.decks.filter(d => d.id !== id); this.save(); },
  duplicate(id) {
    const d = this.get(id); if (!d) return null;
    const c = { ...d, id: uid(), name: d.name + ' (copia)', cards: [...d.cards] };
    this.upsert(c); return c;
  },
  // ---- mazzi dell'avversario
  botBase(id) { return DB.bots.find(b => b.id === id) || null; },
  botDeck(id) {
    const b = this.botBase(id); if (!b) return null;
    const m = this.botMods[id];
    return m ? { ...b, cards: m.cards } : b;
  },
  isBotModified(id) { return !!this.botMods[id]; },
  saveBot(id, cards) {
    const b = this.botBase(id); if (!b) return;
    const same = [...b.cards].sort().join() === [...cards].sort().join();
    if (same) delete this.botMods[id]; else this.botMods[id] = { cards };
    write(K_BOT, this.botMods);
  },
  resetBot(id) { delete this.botMods[id]; write(K_BOT, this.botMods); },
  // ---- backup
  backupJson() {
    return JSON.stringify({ app: 'pkmtester', version: 1, created: new Date().toISOString(), decks: this.decks, botOverrides: this.botMods }, null, 1);
  },
  restore(text) {
    let o;
    try { o = JSON.parse(text); } catch (_) { throw new Error('Il file non è un backup valido.'); }
    if (!o || o.app !== 'pkmtester' || !Array.isArray(o.decks)) throw new Error('Il file non è un backup di PKM Tester.');
    let n = 0, b = 0;
    for (const d of o.decks) {
      if (!d || !d.id || !Array.isArray(d.cards)) continue;
      const clean = { id: String(d.id), name: String(d.name || 'Mazzo'), cards: d.cards.map(String), updated: d.updated || Date.now() };
      const i = this.decks.findIndex(x => x.id === clean.id);
      if (i >= 0) this.decks[i] = clean; else this.decks.push(clean);
      n++;
    }
    this.save();
    if (o.botOverrides && typeof o.botOverrides === 'object') {
      for (const [k, v] of Object.entries(o.botOverrides)) if (v && Array.isArray(v.cards)) { this.botMods[k] = { cards: v.cards.map(String) }; b++; }
      write(K_BOT, this.botMods);
    }
    return { decks: n, bots: b };
  },
};

// ------------------------------------------------------------------ liste di testo (Pokémon TCG Live / Limitless)
const SYM = { G: 'Grass', R: 'Fire', W: 'Water', L: 'Lightning', P: 'Psychic', F: 'Fighting', D: 'Darkness', M: 'Metal', Y: 'Fairy' };
const IT_TYPES = { erba: 'Grass', fuoco: 'Fire', acqua: 'Water', lampo: 'Lightning', psico: 'Psychic', lotta: 'Fighting', oscurita: 'Darkness', metallo: 'Metal', folletto: 'Fairy' };

function bestByName(name) {
  const q = normalize(name).trim();
  const hits = DB.list.filter(c => c._e === q || c._n === q);
  if (!hits.length) return null;
  hits.sort((a, b) => ((b.l & 1) - (a.l & 1)) || ((DB.setOrder.get(b.st) || 0) - (DB.setOrder.get(a.st) || 0)));
  return hits[0];
}
function basicEnergy(type) {
  const hits = DB.list.filter(c => isBasicEnergy(c) && energyTypeOfName(c.e) === type);
  hits.sort((a, b) => ((b.l & 1) - (a.l & 1)) || ((DB.setOrder.get(b.st) || 0) - (DB.setOrder.get(a.st) || 0)));
  return hits[0] || null;
}

/** Interpreta una riga "4 Dreepy TWM 128" (anche "4x", nomi italiani, energie {R}) */
export function resolveLine(line) {
  let l = line.trim().replace(/^\*\s*/, '');
  const m = l.match(/^(\d+)\s*x?\s+(.+)$/i);
  if (!m) return null;
  const qty = +m[1];
  let rest = m[2].trim().replace(/\s+PH$/, '');
  const cm = rest.match(/^(.+?)\s+([A-Z][A-Za-z0-9-]{1,7})\s+([A-Z]{0,4}\d+[a-z]?)$/);
  let name = rest, code = null, num = null;
  if (cm) { name = cm[1]; code = cm[2].toUpperCase(); num = cm[3]; }
  name = name.replace(/\{([GRWLPFDMY])\}/g, (_, x) => SYM[x]).replace(/^Basic\s+/i, '');
  if (code) {
    const set = DB.setByCode.get(code) || DB.sets.get(code.toLowerCase());
    if (set) {
      const n0 = num.replace(/^[A-Z]+/, '').replace(/^0+/, '');
      const c = DB.list.find(x => x.st === set.i && x.no.replace(/^[A-Za-z]+/, '').replace(/^0+/, '') === n0);
      if (c && (normalize(c.e) === normalize(name) || normalize(c.n) === normalize(name) || isEnergy(c))) return { qty, card: c };
    }
  }
  // energie base scritte in vari modi
  const en = normalize(name).match(/^(?:energia\s+)?(\w+)\s+(?:energy|energia)$|^energia\s+(\w+)$/);
  if (en) {
    const w = en[1] || en[2];
    const t = SYM[w?.toUpperCase()] || IT_TYPES[w] || Object.values(SYM).find(x => x.toLowerCase() === w);
    if (t) { const c = basicEnergy(t); if (c) return { qty, card: c }; }
  }
  const c = bestByName(name);
  return c ? { qty, card: c } : { qty, card: null, name };
}

export function parseList(name, text) {
  const cards = [], missing = [];
  for (const raw of text.split(/\r?\n/)) {
    const l = raw.trim();
    if (!l || /^(pok[eé]mon|trainer|allenatore|energy|energia|total cards|carte totali)\b.*:/i.test(l) || l.startsWith('#') || l.startsWith('//')) continue;
    const r = resolveLine(l);
    if (!r) continue;
    if (!r.card) { missing.push(l); continue; }
    for (let i = 0; i < r.qty; i++) cards.push(r.card.i);
  }
  return { deck: cards.length ? { id: uid(), name, cards, updated: Date.now() } : null, missing };
}

export function toList(d) {
  const groups = { P: new Map(), T: new Map(), E: new Map() };
  for (const id of d.cards) { const c = card(id); const k = c?.c || 'T'; groups[k].set(id, (groups[k].get(id) || 0) + 1); }
  const line = (id, n) => { const c = card(id); return `${n} ${c ? c.e : id} ${c ? printCode(c) : ''}`.trim(); };
  const sec = (title, m) => { const tot = [...m.values()].reduce((a, b) => a + b, 0); return tot ? `${title}: ${tot}\n${[...m].map(([id, n]) => line(id, n)).join('\n')}\n` : ''; };
  return [sec('Pokémon', groups.P), sec('Trainer', groups.T), sec('Energy', groups.E), `Total Cards: ${d.cards.length}`].filter(Boolean).join('\n');
}

/** Problemi del mazzo per le regole base (60 carte, 4 copie per nome, un Asso Tattico, un Radioso, almeno un Pokémon Base) */
export function deckProblems(d, { format = 0 } = {}) {
  const out = [];
  const cs = d.cards.map(card);
  if (d.cards.length !== 60) out.push(`Il mazzo ha ${d.cards.length} carte: ne servono esattamente 60.`);
  if (!cs.some(c => isBasicPokemon(c))) out.push('Serve almeno un Pokémon Base.');
  const byName = new Map();
  for (const c of cs) if (c && !isBasicEnergy(c)) byName.set(c.e, (byName.get(c.e) || 0) + 1);
  for (const [n, k] of byName) if (k > 4) out.push(`«${cs.find(c => c?.e === n)?.n || n}» compare ${k} volte (massimo 4).`);
  const ace = cs.filter(c => isAceSpec(c)).length;
  if (ace > 1) out.push(`Ci sono ${ace} carte Asso Tattico: al massimo 1.`);
  const rad = cs.filter(c => isRadiant(c)).length;
  if (rad > 1) out.push(`Ci sono ${rad} Pokémon Radiosi: al massimo 1.`);
  if (cs.some(c => !c)) out.push('Alcune carte non sono più nel database.');
  if (format === 1) { const bad = cs.filter(c => c && !(c.l & 1) && !isBasicEnergy(c)); if (bad.length) out.push(`${bad.length} carte non legali in Standard.`); }
  return out;
}
export const copiesByName = (d, c) => d.cards.filter(id => card(id)?.e === c.e).length;
export { cardName };
