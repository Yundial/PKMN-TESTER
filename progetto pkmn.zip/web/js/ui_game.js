// Nuova partita, tavolo di gioco, richieste di scelta del motore e strumenti manuali.
import { DB, card, cardName, typeLine, TYPE_IT } from './data.js';
import { Store, deckProblems } from './store.js';
import { Game, GameOver, COND_IT, isBasicPokemon, isEnergy, isPokemon } from './engine/core.js';
import { LIB } from './engine/effects.js';
import { BotAgent } from './engine/bot.js';
import { h, clear, go, back, home, modal, closeAllModals, confirmBox, cardImg, cardDetail, cardText, topBar, onLongPress, toast, eIcon, costIcons } from './ui_core.js';
import { coverOf, BotEditorScreen, DecksScreen } from './ui_decks.js';

export const DIFFS = ['Facile', 'Medio', 'Difficile', 'Incubo'];
const DIFF_DESC = [
  'Gioca per divertirsi: mosse spesso a caso, attacca appena può. Mazzi semplici di Pokémon classici.',
  'Gioca per vincere, ma con calma: usa poco le carte che spostano i tuoi Pokémon. Ideale per provare i mazzi.',
  'Competitivo: cerca i KO, prepara gli attaccanti in Panchina e sfrutta Capo e simili. Mazzi forti recenti.',
  'Vuole batterti a tutti i costi: prova ogni mossa in simulazione prima di sceglierla. Stessi mazzi di Difficile.',
];
export const deckLevel = d => Math.min(d, 2);
export const NG = { step: 0, deckId: null, difficulty: 1, botDeck: null };

// ------------------------------------------------------------------ nuova partita
export function NewGameScreen(homeScreen) {
  let redraw = () => {};
  return {
    onBack() { if (NG.step > 0) { NG.step--; redraw(); return false; } return true; },
    render() {
      const box = h('div.screen');
      redraw = () => {
        clear(box);
        const titles = ['1 · Il tuo mazzo', '2 · Difficoltà', '3 · Avversario', '4 · Chi inizia'];
        box.appendChild(topBar(titles[NG.step], () => { if (NG.step > 0) { NG.step--; redraw(); } else back(); }));
        const list = h('div.list');
        box.appendChild(list);
        if (NG.step === 0) {
          if (!Store.decks.length) list.append(h('p.muted', "Non hai ancora mazzi. Creane uno o importalo dall'archivio."), h('button.outline', { onclick: () => go(DecksScreen()) }, 'Vai ai mazzi'));
          for (const d of Store.decks) {
            const probs = deckProblems(d);
            const ok = d.cards.some(id => isBasicPokemon(card(id)));
            list.appendChild(choice(NG.deckId === d.id, d.name, `${d.cards.length} carte` + (probs.length ? `\n⚠ ${probs[0]}` : ''), coverOf(d.cards),
              ok ? () => { NG.deckId = d.id; NG.step = 1; redraw(); } : null));
          }
        } else if (NG.step === 1) {
          DIFFS.forEach((n, i) => list.appendChild(choice(NG.difficulty === i, n, DIFF_DESC[i], null, () => { NG.difficulty = i; NG.botDeck = null; NG.step = 2; redraw(); })));
        } else if (NG.step === 2) {
          list.appendChild(choice(NG.botDeck == null, 'Casuale', `Un mazzo a sorpresa del livello ${DIFFS[NG.difficulty]}`, null, () => { NG.botDeck = null; NG.step = 3; redraw(); }));
          list.appendChild(h('p.muted.small', 'Tocca un mazzo per sceglierlo, oppure «Vedi / modifica» per guardarlo e cambiarlo prima della partita.'));
          for (const orig of DB.bots.filter(b => b.level === deckLevel(NG.difficulty))) {
            const b = Store.botDeck(orig.id);
            const mod = Store.isBotModified(orig.id);
            list.appendChild(choice(NG.botDeck === b.id, b.name + (mod ? ' ✎' : ''), `${b.desc}\n${b.cards.length} carte${mod ? ' · modificato da te' : ''}`,
              b.cover || coverOf(b.cards), () => { NG.botDeck = b.id; NG.step = 3; redraw(); },
              h('button.text.small', { onclick: e => { e.stopPropagation(); go(BotEditorScreen(b.id)); } }, 'Vedi /', h('br'), 'modifica')));
          }
        } else {
          const mine = Store.get(NG.deckId);
          list.append(
            h('p', `Il tuo mazzo: ${mine?.name || '-'}`),
            h('p', `Difficoltà: ${DIFFS[NG.difficulty]}`),
            h('p', `Avversario: ${Store.botDeck(NG.botDeck || '')?.name || 'casuale'}`),
            h('h3', 'Chi inizia?'),
            ...['Testa o croce', 'Inizio io', "Inizia l'avversario"].map((l, i) => h('button.primary.block', { onclick: () => {
              if (!mine) return;
              go(DuelScreen({ deckId: mine.id, difficulty: NG.difficulty, botDeckId: NG.botDeck, first: [-1, 0, 1][i] }, homeScreen));
            } }, l)));
        }
      };
      redraw();
      return { el: box };
    },
  };
}
function choice(selected, title, sub, cover, onclick, trailing = null) {
  return h('div.row-card' + (selected ? '.selected' : '') + (onclick ? '' : '.disabled'), { onclick: onclick || null },
    cover ? cardImg(cover, { cls: 'thumb' }) : null,
    h('div.grow', h('div.title', title), h('div.muted.small.pre', sub)),
    trailing);
}

// ------------------------------------------------------------------ giocatore umano
class HumanAgent {
  constructor(ui) { this.ui = ui; }
  act(g, pl, actions) { return new Promise(res => this.ui.awaitAction(actions, res)); }
  choose(g, pl, req) { return new Promise(res => this.ui.askChoice(req, res)); }
  reveal(g, pl, { title, uids }) { return new Promise(res => this.ui.reveal(title, uids, res)); }
  manual(g, pl, notes) { return new Promise(res => this.ui.manualNotes(notes, res)); }
}

// ------------------------------------------------------------------ partita
export function DuelScreen(config, homeScreen) {
  let game = null, closed = false;
  return {
    onBack() {
      if (game && game.s.winner == null) {
        confirmBox('Abbandonare la partita?', 'La partita verrà considerata persa.', 'Abbandona', () => { closed = true; game = null; back(); });
        return false;
      }
      return true;
    },
    cleanup() { closed = true; },
    render() {
      const root = h('div.screen.duel');
      const mine = Store.get(config.deckId);
      const pool = DB.bots.filter(b => b.level === deckLevel(config.difficulty));
      const pick = pool.length ? pool : DB.bots;
      const bot = Store.botDeck(config.botDeckId || '') || (pick.length ? Store.botDeck(pick[Math.floor(Math.random() * pick.length)].id) : null);
      if (!mine || !bot) { root.appendChild(h('div.prep', h('p.warn', 'Mazzo non trovato.'), h('button.primary', { onclick: back }, 'Indietro'))); return { el: root }; }
      const db = id => card(id);
      game = Game.create(db, LIB, [mine.cards, bot.cards], ['Tu', bot.name], { first: config.first });
      const ui = new BoardUI(root, game, { botName: bot.name, onExit: () => { closed = true; back(); }, onRematch: () => { closed = true; back(); setTimeout(() => go(DuelScreen(config, homeScreen)), 50); } });
      const speed = [120, 450, 900][Store.opts.speed ?? 1];
      game.agents = [new HumanAgent(ui), new BotAgent(config.difficulty, { delay: speed })];
      game.listeners.push(() => { if (!closed) ui.schedule(); });
      ui.draw();
      game.run().then(() => { if (!closed) ui.finished(); }).catch(e => {
        if (closed) return;
        console.error(e);
        modal({ title: 'Errore del motore', body: h('div', h('p', 'Qualcosa è andato storto durante la partita.'), h('pre.tiny', String(e.stack || e).slice(0, 900))), buttons: [{ label: 'Esci', onclick: c => { c(); back(); } }] });
      });
      return { el: root, cleanup: () => { closed = true; } };
    },
  };
}

// ------------------------------------------------------------------ tavolo
class BoardUI {
  constructor(root, game, opts) {
    this.root = root; this.g = game; this.opts = opts;
    this.actions = null; this.resolveAction = null;
    this.pendingChoice = null;
    this.raf = 0;
  }
  schedule() { if (!this.raf) this.raf = requestAnimationFrame(() => { this.raf = 0; this.draw(); }); }

  awaitAction(actions, res) {
    this.actions = actions;
    this.resolveAction = a => { this.actions = null; this.resolveAction = null; res(a); this.draw(); };
    this.draw();
    if (this.g.s.turn > 0 && !this.announced) { this.announced = this.g.s.turn; }
  }
  act(a) { if (this.resolveAction) this.resolveAction(a); }

  // ---------------------------------------------------------------- disegno
  draw() {
    const g = this.g, s = g.s;
    const root = clear(this.root);
    if (s.phase === 'setup' && !this.pendingChoice) { root.appendChild(h('div.prep', h('div.spinner'), h('p', 'Preparo la partita…'))); return; }
    const me = g.P(0), op = g.P(1);
    const myTurn = !!this.actions;
    root.append(
      this.pbar(op, 1, s.cur === 1),
      this.benchRow(1),
      this.activeRow(1),
      this.activeRow(0),
      this.benchRow(0),
      this.pbar(me, 0, s.cur === 0),
      this.statusLine(),
      this.actionBar(myTurn),
      this.handRow(myTurn));
  }

  pbar(p, pl, active) {
    const g = this.g;
    return h('div.pbar.' + (pl ? 'opp' : 'me') + (active ? '.active' : ''),
      h('b', pl ? this.opts.botName : 'Tu'),
      h('span.grow'),
      h('span.chipinfo', { title: 'Carte Premio' }, '🎴 ', h('b', p.prizes.length)),
      h('button.chipinfo', { onclick: () => toast(`Mazzo: ${p.deck.length} carte`) }, '📚 ', p.deck.length),
      h('button.chipinfo', { onclick: () => this.pile(`Scarti — ${pl ? this.opts.botName : 'tuoi'}`, p.discard) }, '🗑 ', p.discard.length),
      p.lost.length ? h('button.chipinfo', { onclick: () => this.pile('Zona perduta', p.lost) }, '🌀 ', p.lost.length) : null,
      pl ? h('span.chipinfo', '✋ ', p.hand.length) : null);
  }

  slotView(sl, { big = false, hl = false, onclick = null } = {}) {
    const g = this.g;
    if (!sl) return h('div.slot.empty' + (big ? '.big' : ''));
    const c = g.top(sl);
    const hp = g.maxHp(sl);
    const left = Math.max(0, hp - sl.dmg);
    const conds = Object.entries(sl.cond).filter(([k, v]) => v && k !== 'paraTurn').map(([k]) => COND_IT[k].slice(0, 4) + '.');
    const el = h('div.slot' + (big ? '.big' : '') + (hl ? '.hl' : ''), { onclick },
      h('div.slot-card', cardImg(g.cid(g.topUid(sl)))),
      h('div.hpbar', h('div.hpfill', { style: { width: `${Math.round(100 * left / hp)}%`, background: left / hp > 0.5 ? 'var(--ok)' : left / hp > 0.25 ? 'var(--gold)' : 'var(--warn)' } })),
      h('div.hptext', `${left}/${hp}`),
      sl.dmg ? h('div.dmg', sl.dmg) : null,
      sl.energy.length ? h('div.energies', sl.energy.flatMap(u => g.energyUnits(u, sl)).slice(0, 8).map(t => eIcon(t === 'ANY' ? 'Rainbow' : t))) : null,
      sl.tools.length ? h('div.toolmark', '🔧') : null,
      conds.length ? h('div.conds', conds.join(' ')) : null);
    onLongPress(el, () => this.slotDetail(sl));
    return el;
  }

  benchRow(pl) {
    const g = this.g, p = g.P(pl);
    const size = Math.max(5, g.benchSize(pl));
    const row = h('div.bench' + (size > 5 ? '.wide' : ''));
    for (let i = 0; i < size; i++) {
      const sl = p.bench[i];
      row.appendChild(this.slotView(sl, { hl: sl && this.slotHasActions(sl), onclick: sl ? () => this.tapSlot(sl) : null }));
    }
    return row;
  }
  activeRow(pl) {
    const g = this.g, p = g.P(pl);
    const st = g.s.stadium;
    const side = pl === 1
      ? h('div.side', st ? h('div.stadium', { onclick: () => cardDetail(g.cid(st.uid)) }, cardImg(g.cid(st.uid)), h('div.tiny.center', 'Stadio')) : h('div.tiny.muted.center', 'Nessuno stadio'))
      : h('div.side', this.manualBtn());
    const prizes = h('div.prizes', p.prizes.map(() => h('div.prize')));
    return h('div.arow' + (pl ? '.opp' : '.me'), prizes, this.slotView(p.active, { big: true, hl: p.active && this.slotHasActions(p.active), onclick: p.active ? () => this.tapSlot(p.active) : null }), side);
  }
  manualBtn() {
    return h('button.manual', { onclick: () => this.manualTools(), disabled: !this.actions }, '⚙', h('span.tiny', 'Manuale'));
  }
  statusLine() {
    const g = this.g;
    const lines = g.s.log.slice(-3);
    const who = this.pendingChoice ? 'Scegli…' : this.actions ? 'Il tuo turno' : g.s.winner != null ? 'Partita finita' : `Turno di ${this.opts.botName}…`;
    return h('div.status', { onclick: () => this.logDialog() },
      h('div.row', h('b.small', `T${g.s.turn} · ${who}`), !this.actions && g.s.winner == null && !this.pendingChoice ? h('div.busy.grow', h('div.bar')) : h('span.grow'), h('span.tiny.muted', 'registro ›')),
      lines.map(l => h('div.tiny.ellipsis', l)));
  }
  actionBar(myTurn) {
    const acts = this.actions || [];
    const atk = acts.filter(a => a.k === 'attack');
    const ret = acts.filter(a => a.k === 'retreat');
    return h('div.actionbar',
      h('button.primary', { disabled: !myTurn, onclick: () => this.attackDialog() }, atk.length ? `Attacca (${atk.length})` : 'Attacchi'),
      h('button.outline', { disabled: !ret.length, onclick: () => this.retreatDialog() }, 'Ritirata'),
      h('button.outline', { disabled: !myTurn, onclick: () => this.endTurn() }, 'Fine turno'),
      h('button.outline.menu-btn', { onclick: () => this.menu() }, '☰'));
  }
  handRow(myTurn) {
    const g = this.g, p = g.P(0);
    const row = h('div.hand');
    for (const u of p.hand) {
      const playable = myTurn && (this.actions || []).some(a => a.uid === u);
      const el = h('div.hand-card' + (playable ? '.hl' : ''), { onclick: () => this.tapHand(u) }, cardImg(g.cid(u)));
      onLongPress(el, () => cardDetail(g.cid(u)));
      row.appendChild(el);
    }
    if (!p.hand.length) row.appendChild(h('div.muted.small.pad', 'Mano vuota'));
    return row;
  }

  // ---------------------------------------------------------------- tocchi
  slotHasActions(sl) { return !!this.actions && this.actions.some(a => (a.k === 'ability' && a.sid === sl.sid)); }
  where(sl) {
    const g = this.g;
    if (!sl) return '';
    const p = g.P(sl.owner);
    return p.active === sl ? 'Attivo' : `Panchina ${p.bench.indexOf(sl) + 1}`;
  }
  tapHand(u) {
    const g = this.g;
    const id = g.cid(u);
    const acts = (this.actions || []).filter(a => a.uid === u);
    const btns = [];
    for (const a of acts) {
      const sl = a.sid ? g.slot(a.sid) : null;
      const label = a.k === 'bench' ? 'Metti in Panchina' : a.k === 'evolve' ? `Fai evolvere ${g.slotName(sl)} (${this.where(sl)})`
        : a.k === 'energy' ? `Assegna a ${g.slotName(sl)} (${this.where(sl)})` : a.k === 'tool' ? `Assegna a ${g.slotName(sl)} (${this.where(sl)})` : 'Gioca';
      btns.push({ label, kind: 'text', onclick: cl => { cl(); this.act(a); } });
    }
    const c = card(id);
    const body = h('div.detail', h('div.detail-img', cardImg(id, { big: true })), cardText(c),
      !acts.length && this.actions ? h('p.muted.small', this.whyNot(c)) : null,
      btns.length ? h('div.col.choices', btns.map(b => h('button.outline.block', { onclick: () => b.onclick(close) }, b.label))) : null);
    const close = modal({ title: c?.n || 'Carta', body, wide: true, buttons: [{ label: 'Chiudi', onclick: cl => cl() }] });
  }
  whyNot(c) {
    const g = this.g, s = g.s;
    if (!c) return '';
    if (isEnergy(c) && s.tf.energy) return 'Hai già assegnato una Energia in questo turno.';
    if (c.c === 'T' && /Supporter/.test(c.tt) && s.tf.supporter) return 'Hai già giocato un Aiuto in questo turno.';
    if (c.c === 'T' && /Supporter/.test(c.tt) && s.turn === 1) return 'Chi inizia non può giocare Aiuti nel primo turno.';
    if (isPokemon(c) && !isBasicPokemon(c)) return g.isOwnFirstTurn(0) ? 'Non puoi far evolvere nel tuo primo turno.' : `Serve ${c.f} in gioco da almeno un turno.`;
    if (g.itemLockFor(0) && c.c === 'T') return 'Non puoi giocare carte Strumento in questo turno.';
    return 'Ora non puoi giocare questa carta.';
  }
  tapSlot(sl) {
    const g = this.g;
    const acts = (this.actions || []).filter(a => a.k === 'ability' && a.sid === sl.sid);
    const extra = acts.map(a => ({ label: `Usa: ${a.name}`, kind: 'text.gold', onclick: cl => { cl(); this.act(a); } }));
    if (sl.owner === 0 && g.isActive(sl) && this.actions?.some(a => a.k === 'attack')) extra.push({ label: 'Attacca…', kind: 'text.gold', onclick: cl => { cl(); this.attackDialog(); } });
    this.slotDetail(sl, extra);
  }
  slotDetail(sl, extra = []) {
    const g = this.g;
    const c = g.top(sl);
    const info = h('div.small',
      h('div', `PS ${Math.max(0, g.maxHp(sl) - sl.dmg)}/${g.maxHp(sl)}${sl.dmg ? ` · ${sl.dmg / 10} segnalini danno` : ''}`),
      sl.energy.length ? h('div', 'Energie: ', sl.energy.map(u => h('span.tag', { onclick: () => cardDetail(g.cid(u)) }, g.nameOf(u)))) : h('div.muted', 'Nessuna Energia'),
      sl.tools.length ? h('div', 'Oggetti: ', sl.tools.map(u => h('span.tag', { onclick: () => cardDetail(g.cid(u)) }, g.nameOf(u)))) : null,
      sl.cards.length > 1 ? h('div.muted', 'Evoluto da: ', sl.cards.slice(0, -1).map(u => g.nameOf(u)).join(' → ')) : null,
      Object.entries(sl.cond).some(([k, v]) => v && k !== 'paraTurn') ? h('div.warn', Object.entries(sl.cond).filter(([k, v]) => v && k !== 'paraTurn').map(([k]) => COND_IT[k]).join(', ')) : null,
      h('div.muted', `Ritirata: ${g.retreatCost(sl)} · Premi se va KO: ${g.prizeValue(sl)}`));
    const body = h('div.detail', h('div.detail-img', cardImg(g.cid(g.topUid(sl)), { big: true })), info, cardText(c));
    modal({ title: `${c.n} (${sl.owner ? 'avversario' : 'tuo'}, ${this.where(sl)})`, body, wide: true, buttons: [...extra, { label: 'Chiudi', onclick: cl => cl() }] });
  }
  attackDialog() {
    const g = this.g, a = g.P(0).active;
    if (!a) return;
    const legal = (this.actions || []).filter(x => x.k === 'attack');
    const atks = g.attacksOf(a);
    const first = g.s.turn === 1 && g.s.first === 0;
    const rows = atks.map((atk, idx) => {
      const ok = legal.find(x => x.idx === idx);
      return h('div.attack-row' + (ok ? '' : '.off'), { onclick: ok ? () => { close(); this.act(ok); } : null },
        h('div.row', costIcons(g.attackCost(a, atk)), h('b.grow', atk.n), atk.d ? h('b', atk.d) : null),
        (atk.x || atk.y) ? h('div.tiny', atk.x || atk.y) : null,
        !ok ? h('div.tiny.warn', first ? 'Chi inizia non può attaccare nel primo turno.' : a.cond.asleep || a.cond.paralyzed ? 'Il Pokémon non può attaccare.' : 'Energie insufficienti o attacco non disponibile.') : null);
    });
    const close = modal({ title: `Attacchi di ${g.slotName(a)}`, body: h('div.col', rows.length ? rows : h('p.muted', 'Nessun attacco.'), h('p.tiny.muted', "Attaccare termina il turno.")), buttons: [{ label: 'Chiudi', onclick: c => c() }] });
  }
  retreatDialog() {
    const g = this.g;
    const ret = (this.actions || []).filter(a => a.k === 'retreat');
    if (!ret.length) return;
    const cost = ret[0].cost;
    const close = modal({ title: `Ritirata (costo ${cost})`, body: h('div.col', h('p.small', 'Scegli il Pokémon in Panchina che diventa Attivo. Poi sceglierai le Energie da scartare.'),
      h('div.pgrid', ret.map(a => { const sl = g.slot(a.sid); return h('div.pcell', { onclick: () => { close(); this.act(a); } }, h('div.pimg', cardImg(g.cid(g.topUid(sl)))), h('div.tiny.center', g.slotName(sl))); }))),
    buttons: [{ label: 'Annulla', onclick: c => c() }] });
  }
  endTurn() {
    const canAttack = (this.actions || []).some(a => a.k === 'attack');
    if (canAttack && Store.opts.confirmEnd) confirmBox('Finire il turno senza attaccare?', 'Il tuo Pokémon Attivo potrebbe ancora attaccare.', 'Fine turno', () => this.act({ k: 'end' }), false);
    else this.act({ k: 'end' });
  }
  pile(title, uids) {
    const g = this.g;
    modal({ title: `${title} (${uids.length})`, wide: true, body: uids.length ? h('div.pgrid', [...uids].reverse().map(u => h('div.pcell', { onclick: () => cardDetail(g.cid(u)) }, h('div.pimg', cardImg(g.cid(u)))))) : h('p.muted', 'Vuoto.'),
      buttons: [{ label: 'Chiudi', onclick: c => c() }] });
  }
  logDialog() {
    modal({ title: 'Registro', wide: true, body: h('div.logbox', [...this.g.s.log].reverse().map(l => h('div.small' + (l.startsWith('—') ? '.gold' : ''), l))), buttons: [{ label: 'Chiudi', onclick: c => c() }] });
  }
  menu() {
    let close = () => {};
    const sp = ['Veloce', 'Normale', 'Lenta'];
    close = modal({ title: 'Partita', body: h('div.menu',
      h('button.menu-item', { onclick: () => { close(); this.logDialog(); } }, 'Registro della partita'),
      h('button.menu-item', { onclick: () => { close(); this.pile('I tuoi scarti', this.g.P(0).discard); } }, 'I tuoi scarti'),
      h('button.menu-item', { onclick: () => { close(); this.pile('Scarti avversario', this.g.P(1).discard); } }, "Scarti dell'avversario"),
      h('button.menu-item', { onclick: () => { Store.opts.speed = ((Store.opts.speed ?? 1) + 1) % 3; Store.saveOpts(); toast(`Velocità dell'avversario: ${sp[Store.opts.speed]} (dalla prossima partita)`); } }, `Velocità avversario: ${sp[Store.opts.speed ?? 1]}`),
      h('button.menu-item', { onclick: () => { close(); this.manualTools(); }, disabled: !this.actions }, 'Strumenti manuali'),
      h('button.menu-item.danger', { onclick: () => { close(); confirmBox('Abbandonare la partita?', 'La partita verrà considerata persa.', 'Abbandona', () => this.opts.onExit()); } }, 'Abbandona')),
    buttons: [{ label: 'Chiudi', onclick: c => c() }] });
  }
  finished() {
    const g = this.g;
    this.actions = null;
    this.draw();
    const w = g.s.winner;
    modal({ title: w === 0 ? '🏆 Hai vinto!' : w === 1 ? 'Hai perso' : 'Pareggio', body: h('p', g.s.reason), dismissable: false,
      buttons: [{ label: 'Registro', onclick: () => this.logDialog() }, { label: 'Menu', onclick: c => { c(); this.opts.onExit(); } }, { label: 'Rivincita', kind: 'text.gold', onclick: c => { c(); this.opts.onRematch(); } }] });
  }

  // ---------------------------------------------------------------- richieste del motore
  reveal(title, uids, res) {
    const g = this.g;
    modal({ title, wide: true, body: h('div.pgrid', uids.map(u => h('div.pcell', h('div.pimg', cardImg(g.cid(u)))))), buttons: [{ label: 'OK', onclick: c => c() }], onClose: res });
  }

  askChoice(req, res) {
    const g = this.g;
    this.pendingChoice = req;
    const done = v => { this.pendingChoice = null; closeIt(); res(v); this.draw(); };
    let closeIt = () => {};
    const minimize = (show) => {
      closeIt();
      const btn = h('button.primary.floating', { onclick: () => { btn.remove(); show(); } }, '↩ Torna alla scelta');
      document.body.appendChild(btn);
    };
    const open = () => {
      if (req.t === 'yesno') {
        closeIt = modal({ title: req.title, body: req.text ? h('p.small', req.text) : null, dismissable: false,
          buttons: [{ label: 'No', onclick: () => done(false) }, { label: 'Sì', kind: 'text.gold', onclick: () => done(true) }] });
      } else if (req.t === 'option') {
        closeIt = modal({ title: req.title, dismissable: false, body: h('div.col', req.options.map((o, i) => h('button.outline.block', { onclick: () => done(i) }, o))) });
      } else if (req.t === 'dist') {
        this.distDialog(req, done, c => { closeIt = c; }, () => minimize(open));
      } else {
        this.pickDialog(req, done, c => { closeIt = c; }, () => minimize(open));
      }
    };
    this.draw();
    open();
  }

  pickDialog(req, done, setClose, onMin) {
    const g = this.g;
    const isSlot = req.t === 'slot';
    const items = isSlot ? req.sids : (req.from === 'deck' || req.from === 'discard') ? [...req.uids].sort((a, b) => g.nameOf(a).localeCompare(g.nameOf(b))) : req.uids;
    const sel = [];
    const unitsOf = u => req.units ? g.energyUnits(u, g.slot(req.sid)).length : 1;
    const count = () => req.units ? sel.reduce((t, u) => t + unitsOf(u), 0) : sel.length;
    const okBtn = h('button.primary');
    const info = h('div.small.muted');
    const grid = h('div.pgrid');
    const refresh = () => {
      const n = count();
      okBtn.disabled = req.units ? n < req.units : sel.length < req.min;
      okBtn.textContent = `Conferma${sel.length ? ` (${sel.length})` : ''}`;
      info.textContent = req.max === 1 ? 'Scegline 1.' : req.min === req.max ? `Scegline ${req.min}.` : req.min ? `Da ${req.min} a ${req.max}.` : `Fino a ${req.max} (anche nessuna).`;
      for (const cell of grid.children) cell.classList.toggle('on', sel.includes(cell.dataset.k));
    };
    for (const k of items) {
      let img, label;
      if (isSlot) { const sl = g.slot(k); img = cardImg(g.cid(g.topUid(sl))); label = `${g.slotName(sl)} · ${this.where(sl)} · ${Math.max(0, g.maxHp(sl) - sl.dmg)} PS`; }
      else { img = cardImg(g.cid(k)); label = g.nameOf(k); }
      const cell = h('div.pcell', { 'data-k': k, onclick: () => {
        const i = sel.indexOf(k);
        if (i >= 0) sel.splice(i, 1);
        else { if (req.max === 1) sel.length = 0; if (sel.length < req.max) sel.push(k); }
        refresh();
        if (req.max === 1 && req.min === 1 && sel.length === 1 && !req.units) setTimeout(() => done([...sel]), 120);
      } }, h('div.pimg', img, h('span.badge', '✓')), h('div.tiny.center.clamp2', label));
      onLongPress(cell, () => isSlot ? this.slotDetail(g.slot(k)) : cardDetail(g.cid(k)));
      grid.appendChild(cell);
    }
    okBtn.onclick = () => done([...sel]);
    const extra = req.fullDeck && req.fullDeck.length > items.length ? h('p.tiny.muted', `Sono mostrate solo le carte valide (${items.length} su ${req.fullDeck.length}).`) : null;
    refresh();
    setClose(modal({ title: req.title, wide: true, dismissable: false,
      body: h('div.col', info, items.length ? grid : h('p.muted', 'Nessuna carta valida.'), extra),
      buttons: [{ label: 'Guarda il campo', onclick: () => onMin() }, ...(req.min === 0 && !req.units ? [{ label: 'Nessuna', onclick: () => done([]) }] : [])] }));
    // il pulsante Conferma va in fondo alla finestra
    const box = document.querySelector('.overlay:last-child .modal-buttons');
    if (box && !(req.max === 1 && req.min === 1 && !req.units)) box.appendChild(okBtn);
    else if (box && items.length === 0) box.appendChild(okBtn);
  }

  distDialog(req, done, setClose, onMin) {
    const g = this.g;
    const val = Object.fromEntries(req.sids.map(s => [s, 0]));
    const left = h('b');
    const ok = h('button.primary', 'Conferma');
    const rows = h('div.col');
    const refresh = () => {
      const used = Object.values(val).reduce((a, b) => a + b, 0);
      left.textContent = `Segnalini da piazzare: ${req.total - used}`;
      ok.disabled = used !== req.total;
      clear(rows);
      for (const sid of req.sids) {
        const sl = g.slot(sid);
        rows.appendChild(h('div.dist-row', h('div.thumb', cardImg(g.cid(g.topUid(sl)))),
          h('div.grow', h('div.small', g.slotName(sl)), h('div.tiny.muted', `${Math.max(0, g.maxHp(sl) - sl.dmg)} PS rimasti`)),
          h('button.icon.small', { onclick: () => { if (val[sid] > 0) { val[sid]--; refresh(); } } }, '−'),
          h('b.qty', val[sid]),
          h('button.icon.small.add', { onclick: () => { if (Object.values(val).reduce((a, b) => a + b, 0) < req.total) { val[sid]++; refresh(); } } }, '+')));
      }
    };
    ok.onclick = () => done({ ...val });
    refresh();
    setClose(modal({ title: req.title, wide: true, dismissable: false, body: h('div.col', left, rows), buttons: [{ label: 'Guarda il campo', onclick: () => onMin() }] }));
    document.querySelector('.overlay:last-child .modal-buttons')?.appendChild(ok);
  }

  manualNotes(notes, res) {
    const body = h('div.col',
      h('p.small', "Questi effetti non sono automatici: applicali con gli strumenti manuali, poi tocca «Fatto»."),
      notes.map(n => h('div.note', h('b.small', `${n.card}${n.what ? ' — ' + n.what : ''}`), h('p.small', n.it || n.text))));
    const close = modal({ title: 'Effetto da completare', wide: true, dismissable: false, body,
      buttons: [{ label: 'Strumenti manuali', onclick: () => this.manualTools(true) }, { label: 'Fatto', kind: 'text.gold', onclick: () => { close(); res(); } }] });
  }

  // ---------------------------------------------------------------- strumenti manuali
  manualTools(force = false) {
    if (!this.actions && !force) { toast('Disponibili durante il tuo turno'); return; }
    const g = this.g;
    const after = async (msg) => {
      g.log('[manuale] ' + msg);
      try { g.checkKO(); await g.resolvePromotions(); } catch (e) { if (!(e instanceof GameOver)) throw e; this.act({ k: 'end' }); }
      // le azioni possibili cambiano: aggiorna l'elenco
      if (this.actions && g.s.winner == null) this.actions.splice(0, this.actions.length, ...g.legalActions(0));
      g.changed();
    };
    const pickSlot = (title, slots, fn) => {
      const close = modal({ title, wide: true, body: h('div.pgrid', slots.map(sl => h('div.pcell', { onclick: () => { close(); fn(sl); } }, h('div.pimg', cardImg(g.cid(g.topUid(sl)))), h('div.tiny.center', `${g.slotName(sl)} (${sl.owner ? 'avv.' : 'tuo'})`)))), buttons: [{ label: 'Annulla', onclick: c => c() }] });
    };
    const pickCards = (title, uids, dests) => {
      const sel = new Set();
      const grid = h('div.pgrid', uids.map(u => { const cell = h('div.pcell', { onclick: () => { sel.has(u) ? sel.delete(u) : sel.add(u); cell.classList.toggle('on'); } }, h('div.pimg', cardImg(g.cid(u)), h('span.badge', '✓'))); onLongPress(cell, () => cardDetail(g.cid(u))); return cell; }));
      modal({ title, wide: true, body: uids.length ? grid : h('p.muted', 'Vuoto.'),
        buttons: [{ label: 'Annulla', onclick: c => c() }, ...dests.map(([label, fn]) => ({ label, kind: 'text.gold', onclick: c => { if (!sel.size) return; c(); fn([...sel]); } }))] });
    };
    const P = g.P(0);
    const items = [
      ['Metti o togli segnalini danno', () => pickSlot('Su quale Pokémon?', g.allSlots(), sl => this.counterDialog(sl, after))],
      ['Condizioni speciali', () => pickSlot('Quale Pokémon Attivo?', [g.P(0).active, g.P(1).active].filter(Boolean), sl => this.condDialog(sl, after))],
      ['Prendi carte dal mazzo', () => pickCards('Il tuo mazzo', [...P.deck].reverse(), [
        ['In mano', us => { us.forEach(u => g.moveTo(u, 'hand', 0)); g.shuffleDeck(0); after(`prese dal mazzo: ${us.map(u => g.nameOf(u)).join(', ')}`); }],
        ['In panchina', us => { for (const u of us) if (isBasicPokemon(g.card(u)) && P.bench.length < g.benchSize(0)) { g.removeFromZones(u); P.bench.push(g.newSlot(u, 0)); } g.shuffleDeck(0); after('Pokémon messi in panchina dal mazzo'); }],
        ['Negli scarti', us => { us.forEach(u => g.moveTo(u, 'discard', 0)); g.shuffleDeck(0); after('carte scartate dal mazzo'); }]])],
      ['Recupera dagli scarti', () => pickCards('I tuoi scarti', [...P.discard].reverse(), [
        ['In mano', us => { us.forEach(u => g.moveTo(u, 'hand', 0)); after(`recuperate: ${us.map(u => g.nameOf(u)).join(', ')}`); }],
        ['Nel mazzo', us => { g.shuffleInto(0, us); after('carte rimescolate nel mazzo'); }]])],
      ['Scarta carte dalla mano', () => pickCards('La tua mano', [...P.hand], [['Scarta', us => { us.forEach(u => g.discardCard(u)); after(`scartate: ${us.map(u => g.nameOf(u)).join(', ')}`); }], ['Nel mazzo', us => { g.shuffleInto(0, us); after('carte dalla mano rimescolate nel mazzo'); }]])],
      ['Assegna Energie dagli scarti', () => pickCards('Energie nei tuoi scarti', P.discard.filter(u => isEnergy(g.card(u))), [['Assegna', us => pickSlot('A quale Pokémon?', g.slots(0), sl => { us.forEach(u => { g.removeFromZones(u); sl.energy.push(u); }); after(`${us.length} Energie assegnate a ${g.slotName(sl)}`); })]])],
      ['Sposta o scarta Energie', () => pickSlot('Da quale Pokémon?', g.allSlots().filter(s => s.energy.length), from => pickCards('Energie', [...from.energy], [
        ['Scarta', us => { us.forEach(u => g.discardCard(u)); after(`Energie scartate da ${g.slotName(from)}`); }],
        ['Sposta', us => pickSlot('Su quale Pokémon?', g.slots(from.owner).filter(s => s !== from), to => { us.forEach(u => { g.removeFromZones(u); to.energy.push(u); }); after(`Energie spostate su ${g.slotName(to)}`); })]]))],
      ['Pesca 1 carta', () => { g.draw(0, 1); after('pescata 1 carta'); }],
      ['Mescola il tuo mazzo', () => { g.shuffleDeck(0); after('mazzo mescolato'); }],
      ['Scambia il tuo Pokémon Attivo', () => pickSlot('Nuovo Pokémon Attivo', P.bench, sl => { g.switchActive(0, sl); after('Pokémon Attivo scambiato'); })],
      ["Scambia l'Attivo dell'avversario", () => pickSlot('Quale Pokémon avversario diventa Attivo?', g.P(1).bench, sl => { g.switchActive(1, sl); after("Attivo dell'avversario scambiato"); })],
      ["Scarta carte a caso dalla mano avversaria", () => { const o = g.P(1); if (!o.hand.length) return; const u = o.hand[Math.floor(Math.random() * o.hand.length)]; g.discardCard(u); after(`scartata dalla mano avversaria: ${g.nameOf(u)}`); }],
    ];
    let close = () => {};
    close = modal({ title: 'Strumenti manuali', body: h('div.col', h('p.tiny.muted', 'Per gli effetti che il motore non applica da solo. Ogni azione viene scritta nel registro.'),
      h('div.menu', items.map(([l, fn]) => h('button.menu-item', { onclick: () => { close(); fn(); } }, l)))), buttons: [{ label: 'Chiudi', onclick: c => c() }] });
  }
  counterDialog(sl, after) {
    const g = this.g;
    let d = 0;
    const lab = h('b.qty');
    const upd = () => { lab.textContent = (d > 0 ? '+' : '') + d * 10; };
    upd();
    modal({ title: `Segnalini su ${g.slotName(sl)}`, body: h('div.row.center-row', h('button.icon', { onclick: () => { d--; upd(); } }, '−'), lab, h('button.icon.add', { onclick: () => { d++; upd(); } }, '+')),
      buttons: [{ label: 'Annulla', onclick: c => c() }, { label: 'Applica', kind: 'text.gold', onclick: c => { c(); sl.dmg = Math.max(0, sl.dmg + d * 10); after(`${d > 0 ? '+' : ''}${d * 10} danni su ${g.slotName(sl)}`); } }] });
  }
  condDialog(sl, after) {
    const g = this.g;
    const opts = ['asleep', 'confused', 'paralyzed', 'poisoned', 'burned'];
    modal({ title: `Condizioni di ${g.slotName(sl)}`, body: h('div.col',
      opts.map(k => h('button.outline.block' + (sl.cond[k] ? '.on' : ''), { onclick: e => { if (sl.cond[k]) { sl.cond[k] = k === 'poisoned' ? 0 : false; } else g.setCondition(sl, k); e.target.classList.toggle('on', !!sl.cond[k]); after(`${COND_IT[k]}: ${sl.cond[k] ? 'sì' : 'no'} su ${g.slotName(sl)}`); } }, COND_IT[k])),
      h('button.outline.block', { onclick: () => { g.clearConditions(sl); after(`condizioni rimosse da ${g.slotName(sl)}`); } }, 'Rimuovi tutte')),
    buttons: [{ label: 'Chiudi', onclick: c => c() }] });
  }
}
