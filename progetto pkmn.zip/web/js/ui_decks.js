// Archivio mazzi, editor (ricerca + filtri), mazzi dell'avversario, backup.
import { DB, card, cardName, search, searchCode, searchFiltered, emptyFilter, filterCount, filterActive, typeLine, statLine, printCode,
  TYPES, TYPE_IT, regulationMarks, recentSets } from './data.js';
import { Store, parseList, toList, deckProblems, copiesByName } from './store.js';
import { isPokemon, isBasicEnergy, isBasicPokemon, isAceSpec, isRadiant } from './engine/core.js';
import { h, clear, go, back, modal, toast, confirmBox, cardImg, cardDetail, topBar, download, rerender, eIcon } from './ui_core.js';

export const coverOf = ids => ids.find(id => card(id)?.c === 'P' && !isBasicPokemon(card(id))) || ids.find(id => card(id)?.c === 'P') || ids[0] || '';
const summary = d => { const n = k => d.cards.filter(id => card(id)?.c === k).length; return `${d.cards.length} carte · ${n('P')} Pokémon · ${n('T')} Allenatori · ${n('E')} Energie`; };

// ------------------------------------------------------------------ archivio
export function DecksScreen() {
  return {
    render() {
      const list = h('div.list');
      const fill = () => {
        clear(list);
        if (!Store.decks.length) list.appendChild(h('p.muted.pad', 'Nessun mazzo in archivio. Creane uno con il tasto in basso oppure importa una lista (formato Pokémon TCG Live).'));
        for (const d of Store.decks) {
          const probs = deckProblems(d);
          list.appendChild(h('div.row-card', { onclick: () => go(EditorScreen(d.id)) },
            cardImg(coverOf(d.cards), { cls: 'thumb' }),
            h('div.grow', h('div.title', d.name), h('div.muted.small', summary(d)), probs.length ? h('div.warn.small.ellipsis', '⚠ ' + probs[0]) : null),
            h('button.icon', { onclick: e => { e.stopPropagation(); deckMenu(d, fill); }, 'aria-label': 'Opzioni' }, '⋮')));
        }
      };
      fill();
      const el = h('div.screen',
        topBar('I miei mazzi', back, h('button.text', { onclick: () => importDialog(fill) }, 'Importa lista')),
        list,
        h('button.fab', { onclick: () => { const d = Store.create(); go(EditorScreen(d.id)); } }, '+ Nuovo mazzo'));
      return { el };
    },
  };
}

function deckMenu(d, refresh) {
  let close = () => {};
  close = modal({ title: d.name, body: h('div.menu',
    h('button.menu-item', { onclick: () => { close(); go(EditorScreen(d.id)); } }, 'Modifica'),
    h('button.menu-item', { onclick: () => { close(); Store.duplicate(d.id); toast(`Creata una copia di «${d.name}»`); refresh(); } }, 'Duplica'),
    h('button.menu-item', { onclick: () => { close(); renameDialog(d, refresh); } }, 'Rinomina'),
    h('button.menu-item', { onclick: async () => { close(); try { await navigator.clipboard.writeText(toList(d)); toast('Lista copiata negli appunti'); } catch (_) { download(d.name + '.txt', toList(d), 'text/plain'); } } }, 'Copia lista (Pokémon TCG Live)'),
    h('button.menu-item', { onclick: () => { close(); download(d.name.replace(/[^\w\- ]+/g, '_') + '.txt', toList(d), 'text/plain'); } }, 'Esporta file .txt'),
    h('button.menu-item.danger', { onclick: () => { close(); confirmBox(`Eliminare «${d.name}»?`, "Il mazzo verrà cancellato dall'archivio.", 'Elimina', () => { Store.remove(d.id); refresh(); }); } }, 'Elimina')),
    buttons: [{ label: 'Chiudi', onclick: c => c() }] });
}

function renameDialog(d, refresh) {
  const inp = h('input.field', { value: d.name, maxlength: 60 });
  modal({ title: 'Rinomina mazzo', body: inp, buttons: [
    { label: 'Annulla', onclick: c => c() },
    { label: 'Salva', onclick: c => { d.name = inp.value.trim() || d.name; Store.upsert(d); c(); refresh(); } },
  ] });
  setTimeout(() => inp.focus(), 50);
}

function importDialog(refresh) {
  const name = h('input.field', { value: 'Mazzo importato' });
  const text = h('textarea.field', { rows: 9, placeholder: 'Incolla la lista, una carta per riga:\n4 Dreepy TWM 128\n3 Ultra Ball\n8 Energia Fuoco' });
  const file = h('input', { type: 'file', accept: '.txt,text/plain', onchange: async () => {
    const f = file.files[0]; if (!f) return;
    text.value = await f.text(); name.value = f.name.replace(/\.txt$/i, '');
  } });
  const err = h('div.warn.small');
  modal({ title: 'Importa lista', body: h('div.col',
    h('p.muted.small', 'Va bene il formato di Pokémon TCG Live / Limitless («4 Nome SIGLA NUMERO»). Senza sigla viene scelta la stampa più recente; i nomi possono essere in inglese o in italiano.'),
    h('label.small', 'Nome del mazzo'), name, h('label.small', 'Scegli un file…'), file, h('label.small', '…oppure incolla il testo'), text, err),
  buttons: [
    { label: 'Annulla', onclick: c => c() },
    { label: 'Importa', onclick: c => {
      const { deck, missing } = parseList(name.value.trim() || 'Mazzo importato', text.value);
      if (!deck) { err.textContent = 'Nessuna carta riconosciuta nel testo.'; return; }
      Store.upsert(deck); c(); refresh();
      if (missing.length) modal({ title: `Importato con ${missing.length} righe non riconosciute`, body: h('div', h('p.small', 'Queste righe non corrispondono a nessuna carta:'), h('pre.small', missing.join('\n'))), buttons: [{ label: 'OK', onclick: cl => cl() }] });
      else toast(`Importato «${deck.name}» (${deck.cards.length} carte)`);
    } },
  ] });
}

// ------------------------------------------------------------------ editor
const groupOf = c => !c ? 3 : c.c === 'P' ? 0 : c.c === 'T' ? 1 : 2;
const sortIds = ids => [...new Set(ids)].sort((a, b) => {
  const ca = card(a), cb = card(b);
  return groupOf(ca) - groupOf(cb) || (ca?.c === 'T' ? (ca.tt || '').localeCompare(cb.tt || '') : 0) || cardName(a).localeCompare(cardName(b));
});

export function EditorScreen(deckId) {
  return {
    render() {
      const d = Store.get(deckId);
      if (!d) { setTimeout(back, 0); return { el: h('div') }; }
      return deckEditor({ deck: d, title: 'Modifica mazzo', nameEditable: true, onSave: x => Store.upsert(x) });
    },
  };
}

export function BotEditorScreen(botId) {
  return {
    render() {
      const b = Store.botDeck(botId);
      if (!b) { setTimeout(back, 0); return { el: h('div') }; }
      const deck = { id: 'bot:' + botId, name: b.name, cards: [...b.cards] };
      const header = () => h('p.muted.small.pad-x', (Store.isBotModified(botId) ? '✎ Versione modificata da te. ' : 'Versione originale. ') +
        'Le modifiche si salvano subito e valgono per tutti i prossimi duelli contro questo mazzo.');
      return deckEditor({
        deck, title: 'Avversario: ' + b.name, nameEditable: false, startTab: 1, header,
        onSave: x => Store.saveBot(botId, x.cards),
        actions: () => Store.isBotModified(botId) ? h('button.text', { onclick: () => confirmBox('Ripristinare il mazzo originale?', `Le tue modifiche a «${b.name}» andranno perse.`, 'Ripristina', () => { Store.resetBot(botId); rerender(); }) }, 'Ripristina') : null,
      });
    },
  };
}

function deckEditor({ deck, title, nameEditable, onSave, header = null, actions = null, startTab = 0 }) {
  let tab = startTab;
  const state = { mode: 'name', query: '', filter: emptyFilter(), showFilters: false, results: [] };
  const msg = h('div.gold.small.pad-x');
  const status = h('div.small.pad-x');
  const tabs = h('div.tabs');
  const content = h('div.tab-content');
  const headerBox = h('div');
  const actionBox = h('div.actions');

  function save() { onSave(deck); refreshHead(); }
  function add(c) {
    if (!isBasicEnergy(c) && copiesByName(deck, c) >= 4) { msg.textContent = `Hai già 4 carte «${c.n}».`; return; }
    if (deck.cards.length >= 60) { msg.textContent = 'Il mazzo ha già 60 carte.'; return; }
    if (isAceSpec(c) && deck.cards.some(id => isAceSpec(card(id)))) msg.textContent = 'Attenzione: puoi avere un solo Asso Tattico.';
    else if (isRadiant(c) && deck.cards.some(id => isRadiant(card(id)))) msg.textContent = 'Attenzione: puoi avere un solo Pokémon Radioso.';
    else msg.textContent = `Aggiunta: ${c.n}`;
    deck.cards.push(c.i); save();
  }
  function removeOne(id) { const i = deck.cards.lastIndexOf(id); if (i >= 0) deck.cards.splice(i, 1); msg.textContent = `Tolta: ${cardName(id)}`; save(); }
  function detail(id) {
    const c = card(id);
    const btns = [];
    if (deck.cards.includes(id)) btns.push({ label: 'Togli 1', onclick: cl => { removeOne(id); cl(); redraw(); } });
    if (c) btns.push({ label: `Aggiungi 1 (${deck.cards.filter(x => x === id).length})`, onclick: cl => { add(c); cl(); redraw(); } });
    cardDetail(id, btns);
  }
  function refreshHead() {
    const probs = deckProblems(deck);
    status.textContent = probs.length ? '⚠ ' + probs.join(' ') : '✓ Mazzo valido (60 carte)';
    status.className = 'small pad-x ' + (probs.length ? 'warn' : 'ok');
    clear(tabs);
    [['Cerca carte', 0], [`Mazzo (${deck.cards.length})`, 1]].forEach(([l, i]) =>
      tabs.appendChild(h('button.tab' + (tab === i ? '.on' : ''), { onclick: () => { tab = i; refreshHead(); drawTab(); } }, l)));
    clear(headerBox); if (header) headerBox.appendChild(header());
    clear(actionBox); const a = actions?.(); if (a) actionBox.appendChild(a);
  }
  const redraw = () => { if (tab) drawTab(); else drawResults(); };

  // ---- ricerca
  const resultsBox = h('div.results');
  const note = h('div.muted.small.pad');
  const filtersBox = h('div.filters');
  const filterToggle = h('button.text');
  const resetBtn = h('button.text.danger', 'Azzera');
  const showBtn = h('button.primary.block');
  let timer = null;
  function runSearch() {
    clearTimeout(timer);
    timer = setTimeout(() => {
      note.textContent = '';
      if (state.mode === 'code') { state.results = searchCode(state.query); if (state.query.trim() && !state.results.length) note.textContent = 'Nessuna carta con questo codice. Esempi: «TWM 130», «PAL 185», «sv06-130».'; drawResults(); return; }
      const useFilters = filterActive(state.filter);
      if (!useFilters && state.query.trim().length < 2) { state.results = []; drawResults(); return; }
      state.results = useFilters ? searchFiltered(state.filter, state.query) : search(state.query);
      if (!state.results.length) note.textContent = 'Nessun risultato.';
      drawResults();
    }, 200);
  }
  function drawResults() {
    clear(resultsBox);
    showBtn.textContent = `Mostra ${state.results.length}${state.results.length >= 300 ? '+' : ''} risultati`;
    for (const c of state.results) {
      const n = deck.cards.filter(x => x === c.i).length;
      resultsBox.appendChild(h('div.result', { onclick: () => detail(c.i) },
        cardImg(c.i, { cls: 'thumb' }),
        h('div.grow',
          h('div.ellipsis', c.n, c.n !== c.e ? h('span.muted.small', ' · ' + c.e) : null),
          h('div.muted.tiny.ellipsis', typeLine(c)),
          h('div.muted.tiny', `${printCode(c)}${c.rm ? ' · ' + c.rm : ''}${c.l & 1 ? ' · Standard' : ''}`)),
        n ? h('span.gold', '×' + n) : null,
        h('button.icon.add', { onclick: e => { e.stopPropagation(); add(c); drawResults(); }, 'aria-label': 'Aggiungi' }, '+')));
    }
  }
  function drawFilters() {
    filterToggle.textContent = (state.showFilters ? '▲ ' : '▼ ') + 'Filtri' + (filterCount(state.filter) ? ` (${filterCount(state.filter)})` : '');
    resetBtn.style.display = filterActive(state.filter) ? '' : 'none';
    clear(filtersBox);
    filtersBox.style.display = state.showFilters ? '' : 'none';
    showBtn.style.display = state.showFilters ? '' : 'none';
    if (state.showFilters) filtersBox.appendChild(filterPanel(state.filter, f => { state.filter = f; drawFilters(); runSearch(); }));
  }
  filterToggle.onclick = () => { state.showFilters = !state.showFilters; drawFilters(); };
  resetBtn.onclick = () => { state.filter = emptyFilter(); drawFilters(); runSearch(); };
  showBtn.onclick = () => { state.showFilters = false; drawFilters(); };
  const qInput = h('input.field', { type: 'search', enterkeyhint: 'search', autocomplete: 'off',
    oninput: e => { state.query = e.target.value; runSearch(); },
    onkeydown: e => { if (e.key === 'Enter') { e.target.blur(); state.showFilters = false; drawFilters(); } } });
  const modeRow = h('div.chips');
  const filterRow = h('div.row.between', filterToggle, resetBtn);
  function drawModes() {
    clear(modeRow);
    [['name', 'Nome'], ['code', 'Codice di stampa']].forEach(([m, l]) =>
      modeRow.appendChild(h('button.chip' + (state.mode === m ? '.on' : ''), { onclick: () => { state.mode = m; state.results = []; drawModes(); drawResults(); runSearch(); } }, l)));
    qInput.placeholder = state.mode === 'name' ? 'Nome in italiano o inglese (anche solo una parte)' : 'Sigla e numero in basso sulla carta (es. TWM 130)';
    filterRow.style.display = state.mode === 'name' ? '' : 'none';
    if (state.mode !== 'name') state.showFilters = false;
    drawFilters();
  }
  const searchPanel = h('div.search', modeRow, h('div.row', qInput), filterRow, filtersBox, showBtn, note, resultsBox);

  function drawTab() {
    clear(content);
    if (tab === 0) { content.appendChild(searchPanel); return; }
    if (!deck.cards.length) { content.appendChild(h('p.muted.pad', 'Vuoto. Aggiungi carte dalla scheda «Cerca carte».')); return; }
    const ids = sortIds(deck.cards);
    const titles = ['Pokémon', 'Allenatori', 'Energie', 'Altro'];
    let lastG = -1;
    const box = h('div.deck-list');
    for (const id of ids) {
      const c = card(id), g = groupOf(c);
      if (g !== lastG) { lastG = g; box.appendChild(h('div.gold.small.group-title', `${titles[g]} (${deck.cards.filter(x => groupOf(card(x)) === g).length})`)); }
      const n = deck.cards.filter(x => x === id).length;
      box.appendChild(h('div.deck-row',
        h('div.thumb', { onclick: () => detail(id) }, cardImg(id)),
        h('div.grow', { onclick: () => detail(id) }, h('div.ellipsis', cardName(id)), h('div.muted.tiny', c ? `${printCode(c)} · ${typeLine(c)}` : id)),
        h('button.icon.small', { onclick: () => { removeOne(id); drawTab(); } }, '−'),
        h('b.qty', n),
        h('button.icon.small.add', { onclick: () => { if (c) add(c); drawTab(); } }, '+')));
    }
    content.appendChild(box);
  }

  const nameInput = nameEditable ? h('input.field.pad-m', { value: deck.name, maxlength: 60, oninput: e => { deck.name = e.target.value; save(); } }) : null;
  drawModes(); refreshHead(); drawTab();
  const el = h('div.screen', topBar(title, back, actionBox), nameInput, headerBox, status, tabs, msg, content);
  return { el };
}

function filterPanel(f, onChange) {
  const toggle = (arr, v) => arr.includes(v) ? arr.filter(x => x !== v) : [...arr, v];
  const group = (title, opts, isOn, onTog) => h('div.fgroup', h('div.gold.small', title),
    h('div.chips.scroll', opts.map(([v, l]) => h('button.chip' + (isOn(v) ? '.on' : ''), { onclick: () => onTog(v) }, l))));
  const out = [];
  out.push(group('Tipo di carta', [[1, 'Pokémon'], [2, 'Allenatori'], [3, 'Energie']], k => k === f.kind, k => onChange({ ...emptyFilter(), format: f.format, marks: f.marks, set: f.set, kind: f.kind === k ? 0 : k })));
  const typeChips = TYPES.map(t => [t, h('span', eIcon(t), ' ', TYPE_IT[t])]);
  if (f.kind === 1) {
    out.push(group('Tipo', typeChips, v => f.types.includes(v), v => onChange({ ...f, types: toggle(f.types, v) })));
    out.push(group('Fase', [['Basic', 'Base'], ['Stage1', 'Fase 1'], ['Stage2', 'Fase 2'], ['Other', 'Altro (V, VMAX…)']], v => f.stages.includes(v), v => onChange({ ...f, stages: toggle(f.stages, v) })));
    out.push(group('Regola', [['ex', 'Pokémon-ex'], ['mega', 'Mega ex'], ['tera', 'Teracristal'], ['v', 'V / VMAX / V ASTRO'], ['radiant', 'Radiosi'], ['none', 'Senza regola']], v => f.rules.includes(v), v => onChange({ ...f, rules: toggle(f.rules, v) })));
    out.push(group('Altro', [[1, 'Con abilità']], () => f.ability, () => onChange({ ...f, ability: !f.ability })));
    out.push(group('Debolezza', typeChips.filter(([t]) => t !== 'Colorless'), v => f.weak.includes(v), v => onChange({ ...f, weak: toggle(f.weak, v) })));
    out.push(group('Costo di ritirata', [[0, '0'], [1, '1'], [2, '2'], [3, '3'], [4, '4+']], v => f.retreat.includes(v), v => onChange({ ...f, retreat: toggle(f.retreat, v) })));
    const num = (label, key) => h('label.numbox', h('span.tiny', label), h('input.field', { inputmode: 'numeric', value: f[key] ?? '',
      onchange: e => { const v = e.target.value.replace(/\D/g, '').slice(0, 3); onChange({ ...f, [key]: v === '' ? null : Number(v) }); } }));
    out.push(h('div.row4', num('PS min', 'hpMin'), num('PS max', 'hpMax')));
  }
  if (f.kind === 2) out.push(group('Categoria', [['Item', 'Strumento'], ['Supporter', 'Aiuto'], ['Stadium', 'Stadio'], ['Tool', 'Oggetto Pokémon'], ['ace', 'Asso Tattico']], v => f.tts.includes(v), v => onChange({ ...f, tts: toggle(f.tts, v) })));
  if (f.kind === 3) {
    out.push(group('Energia', [[1, 'Base'], [2, 'Speciale']], v => f.energy === v, v => onChange({ ...f, energy: f.energy === v ? 0 : v })));
    out.push(group('Tipo', typeChips.filter(([t]) => !['Colorless', 'Dragon'].includes(t)), v => f.types.includes(v), v => onChange({ ...f, types: toggle(f.types, v) })));
  }
  if (!f.kind) out.push(h('p.muted.small', 'Scegli Pokémon, Allenatori o Energie per i filtri specifici.'));
  out.push(group('Formato', [[1, 'Standard'], [2, 'Expanded']], v => f.format === v, v => onChange({ ...f, format: f.format === v ? 0 : v })));
  const marks = regulationMarks();
  if (marks.length) out.push(group('Simbolo di regolamento', marks.map(m => [m, m]), v => f.marks.includes(v), v => onChange({ ...f, marks: toggle(f.marks, v) })));
  const sel = h('select.field', { onchange: e => onChange({ ...f, set: e.target.value }) },
    h('option', { value: '' }, 'Tutte le espansioni'),
    recentSets(120).map(s => h('option', { value: s.i, selected: f.set === s.i }, `${s.n}${s.code ? ' (' + s.code + ')' : ''}`)));
  out.push(h('div.fgroup', h('div.gold.small', 'Espansione'), sel));
  return h('div', out);
}

// ------------------------------------------------------------------ backup
export function BackupScreen() {
  return {
    render() {
      const fileIn = h('input', { type: 'file', accept: '.json,application/json', style: { display: 'none' }, onchange: async () => {
        const f = fileIn.files[0]; if (!f) return;
        try { const r = Store.restore(await f.text()); toast(`Ripristinati ${r.decks} mazzi` + (r.bots ? ` e ${r.bots} mazzi avversari modificati` : '')); rerender(); }
        catch (e) { modal({ title: 'Ripristino non riuscito', body: h('p', e.message), buttons: [{ label: 'OK', onclick: c => c() }] }); }
        fileIn.value = '';
      } });
      const date = new Date().toISOString().slice(0, 10);
      const el = h('div.screen', topBar('Backup e dati', back),
        h('div.pad.col',
          h('p', `Hai ${Store.decks.length} mazzi e ${Object.keys(Store.botMods).length} mazzi avversari modificati.`),
          h('p.muted.small', "Il backup salva tutto in un file .json che puoi tenere in File/iCloud/Drive o aprire nell'altra versione dell'app (Android ↔ iPhone)."),
          h('button.primary.block', { onclick: () => download(`pkmtester-backup-${date}.json`, Store.backupJson()) }, 'Salva backup'),
          h('button.outline.block', { onclick: () => fileIn.click() }, 'Ripristina da file'),
          fileIn,
          h('p.muted.small', 'Il ripristino aggiunge i mazzi del file: quelli già presenti vengono aggiornati, gli altri restano.'),
          h('hr'),
          h('p.muted.small', `Dati delle carte: ${DB.list.length} carte` + (DB.version ? ` (versione ${DB.version})` : '') + '. Testi e immagini da TCGdex; si aggiornano a ogni nuova pubblicazione.')));
      return { el };
    },
  };
}
