// Service worker: tiene in memoria app e dati delle carte per usarla anche senza rete.
// Le immagini delle carte (TCGdex) restano nella cache del browser man mano che si vedono.
const APP = 'pkt-app-v1';
const DATA = 'pkt-data-v1';
const IMG = 'pkt-img-v1';
const CORE = ['./', 'index.html', 'style.css', 'manifest.webmanifest', 'icon-192.png', 'icon-180.png',
  'js/main.js', 'js/data.js', 'js/store.js', 'js/ui_core.js', 'js/ui_decks.js', 'js/ui_game.js',
  'js/engine/core.js', 'js/engine/effects.js', 'js/engine/textfx.js', 'js/engine/bot.js'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(APP).then(c => c.addAll(CORE)).catch(() => {}).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== APP && k !== DATA && k !== IMG).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

async function cacheFirst(cacheName, req, limit = 0) {
  const c = await caches.open(cacheName);
  const hit = await c.match(req);
  if (hit) return hit;
  try {
    const r = await fetch(req);
    if (r.ok || r.type === 'opaque') {
      c.put(req, r.clone());
      if (limit) c.keys().then(k => { if (k.length > limit) for (const x of k.slice(0, k.length - limit)) c.delete(x); });
    }
    return r;
  } catch (err) {
    const old = await c.match(req, { ignoreSearch: true });
    if (old) return old;
    throw err;
  }
}

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  // immagini delle carte
  if (url.hostname === 'assets.tcgdex.net') { e.respondWith(cacheFirst(IMG, e.request, 3000)); return; }
  if (url.origin !== location.origin) return;
  const p = url.pathname;
  if (p.includes('/data/')) {
    if (p.endsWith('version.json')) {
      e.respondWith(fetch(e.request).catch(() => caches.match(e.request, { ignoreSearch: true })).then(r => r || new Response('{}')));
      return;
    }
    e.respondWith(cacheFirst(DATA, e.request));
    return;
  }
  // app: prima la rete (per ricevere gli aggiornamenti), poi la copia salvata
  e.respondWith(fetch(e.request).then(r => {
    if (r.ok) { const cl = r.clone(); caches.open(APP).then(c => c.put(e.request, cl)); }
    return r;
  }).catch(() => caches.match(e.request, { ignoreSearch: true }).then(r => r || caches.match('index.html'))));
});
