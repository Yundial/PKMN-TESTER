#!/usr/bin/env bash
# Unisce interfaccia web e dati delle carte in un'unica cartella (sito per GitHub Pages o assets dell'APK).
# uso: assemble_site.sh <cartella dati (cards.json, sets.json, bots.json)> <uscita> [versione]
set -euo pipefail
DATA=$1; OUT=$2; VER=${3:-$(date +%Y%m%d%H%M)}
rm -rf "$OUT"; mkdir -p "$OUT/data"
cp -r web/index.html web/style.css web/manifest.webmanifest web/sw.js web/icon-*.png web/js "$OUT"/
cp "$DATA"/cards.json "$DATA"/sets.json "$DATA"/bots.json "$OUT"/data/
echo "{\"v\":\"$VER\"}" > "$OUT"/data/version.json
# i nomi delle cache del service worker cambiano a ogni versione, così l'aggiornamento arriva subito
sed -i "s/pkt-app-v1/pkt-app-$VER/; s/pkt-data-v1/pkt-data-$VER/" "$OUT"/sw.js
touch "$OUT"/.nojekyll
echo "sito pronto in $OUT"
