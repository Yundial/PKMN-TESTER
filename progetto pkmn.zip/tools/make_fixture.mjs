// Crea un piccolo database di carte "finto" (formato compatto di build_data.py) per provare il motore senza rete.
// I valori sono approssimati: in produzione i dati veri arrivano da TCGdex.
// uso: node tools/make_fixture.mjs tools/fixture_cards.json
import fs from 'node:fs';

const cards = [];
let n = 1;
const W = t => [{ t, v: '×2' }];
const sets = [{ i: 'fx', e: 'Fixture', n: 'Prova', code: 'FIX', d: '2024-01-01', sr: 'sv', tot: 999 }];
const code = { OBF: 'sv03', SVI: 'sv01', PAR: 'sv04', SFA: 'sv06.5', MEW: 'sv03.5', TEF: 'sv05', TWM: 'sv06', PAL: 'sv02', JTG: 'sv09', SCR: 'sv07' };
for (const [k, v] of Object.entries(code)) sets.push({ i: v, e: k, n: k, code: k, d: '2024-0' + (sets.length % 9 + 1) + '-01', sr: 'sv', tot: 200 });

function P(e, hp, t, s, f, atks, o = {}) {
  const [st, no] = o.at ? [code[o.at[0]], String(o.at[1])] : ['fx', String(n++)];
  cards.push({ i: `${st}-${no}`, e, n: o.it || e, c: 'P', st, no, im: '', l: 3, hp, t: [t], s, ...(f ? { f } : {}),
    a: atks.map(([an, c, d, y]) => ({ e: an, n: an, c, d: String(d ?? ''), y: y || '', x: y || '' })),
    ...(o.b ? { b: o.b.map(([bn, y]) => ({ e: bn, n: bn, k: 'Ability', y, x: y })) } : {}),
    w: o.w || W({ Grass: 'Fire', Fire: 'Water', Water: 'Lightning', Lightning: 'Fighting', Psychic: 'Darkness', Fighting: 'Psychic', Darkness: 'Grass', Metal: 'Fire', Dragon: 'Fairy', Colorless: 'Fighting' }[t]),
    ...(o.r ? { r: o.r } : {}), rt: o.rt ?? 1 });
}
function T(e, tt, y, it) { cards.push({ i: `fx-${n++}`, e, n: it || e, c: 'T', st: 'fx', no: String(n), im: '', l: 3, tt, y, x: y }); }
const C = 'Colorless', G = 'Grass', R = 'Fire', Wa = 'Water', L = 'Lightning', Ps = 'Psychic', F = 'Fighting', D = 'Darkness', M = 'Metal';

// ---- Facile
P('Pikachu', 60, L, 'Basic', null, [['Gnaw', [C], 10], ['Thunder Jolt', [L, C], 40, 'This Pokémon also does 10 damage to itself.']], { it: 'Pikachu' });
P('Raichu', 120, L, 'Stage1', 'Pikachu', [['Thunder Shock', [L], 30, "Flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed."], ['Thunderbolt', [L, L, C], 140, 'Discard all Energy from this Pokémon.']]);
P('Magnemite', 60, L, 'Basic', null, [['Tackle', [L], 20]]);
P('Magneton', 90, L, 'Stage1', 'Magnemite', [['Magnetic Blast', [L, C], 60]]);
P('Voltorb', 60, L, 'Basic', null, [['Rollout', [C], 10]]);
P('Electrode', 90, L, 'Stage1', 'Voltorb', [['Thunder Spark', [L, C], 90, 'This attack also does 20 damage to each of your Benched Pokémon. (Don\'t apply Weakness and Resistance for Benched Pokémon.)']]);
P('Charmander', 70, R, 'Basic', null, [['Ember', [R], 30, 'Discard an Energy from this Pokémon.']]);
P('Charmeleon', 90, R, 'Stage1', 'Charmander', [['Combustion', [R, R], 60]]);
P('Charizard', 170, R, 'Stage2', 'Charmeleon', [['Flare Blitz', [R, R, R], 200, 'Discard all Fire Energy from this Pokémon.']]);
P('Growlithe', 80, R, 'Basic', null, [['Bite', [R], 20]]);
P('Arcanine', 140, R, 'Stage1', 'Growlithe', [['Heat Tackle', [R, R, C], 160, 'This Pokémon also does 30 damage to itself.']]);
P('Ponyta', 60, R, 'Basic', null, [['Flare', [R], 20]]);
P('Rapidash', 110, R, 'Stage1', 'Ponyta', [['Fire Mane', [R, C], 70, "Your opponent's Active Pokémon is now Burned."]]);
P('Squirtle', 60, Wa, 'Basic', null, [['Water Gun', [Wa], 20]]);
P('Wartortle', 90, Wa, 'Stage1', 'Squirtle', [['Wave Splash', [Wa, C], 50]]);
P('Blastoise', 170, Wa, 'Stage2', 'Wartortle', [['Hydro Pump', [Wa, Wa, C], 80, 'This attack does 30 more damage for each Water Energy attached to this Pokémon.']]);
P('Psyduck', 70, Wa, 'Basic', null, [['Headache', [C], 10, "Your opponent's Active Pokémon is now Confused."]]);
P('Golduck', 120, Wa, 'Stage1', 'Psyduck', [['Hydro Splash', [Wa, C, C], 100]]);
P('Lapras', 120, Wa, 'Basic', null, [['Surf', [Wa, C, C], 90]], { rt: 2 });
P('Staryu', 60, Wa, 'Basic', null, [['Smack', [Wa], 20]]);
P('Starmie', 100, Wa, 'Stage1', 'Staryu', [['Swift', [Wa, C], 60, "This attack's damage isn't affected by Weakness or Resistance, or by any effects on your opponent's Active Pokémon."]]);
P('Bulbasaur', 70, G, 'Basic', null, [['Vine Whip', [G], 20]]);
P('Ivysaur', 100, G, 'Stage1', 'Bulbasaur', [['Razor Leaf', [G, C], 60]]);
P('Venusaur', 180, G, 'Stage2', 'Ivysaur', [['Solar Beam', [G, G, C], 150, 'Heal 30 damage from this Pokémon.']], { rt: 3 });
P('Oddish', 60, G, 'Basic', null, [['Poison Powder', [G], 10, "Your opponent's Active Pokémon is now Poisoned."]]);
P('Gloom', 90, G, 'Stage1', 'Oddish', [['Drool', [G, C], 40, "Your opponent's Active Pokémon is now Asleep."]]);
P('Vileplume', 150, G, 'Stage2', 'Gloom', [['Pollen Bomb', [G, C, C], 120, "Your opponent's Active Pokémon is now Poisoned and Asleep."]]);
P('Tangela', 80, G, 'Basic', null, [['Bind', [G, C], 30, "Flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed."]]);
P('Machop', 70, F, 'Basic', null, [['Punch', [F], 20]]);
P('Machoke', 100, F, 'Stage1', 'Machop', [['Cross Chop', [F, C], 50, 'Flip a coin. If heads, this attack does 50 more damage.']]);
P('Machamp', 180, F, 'Stage2', 'Machoke', [['Dynamic Punch', [F, F, C], 180]], { rt: 3 });
P('Riolu', 70, F, 'Basic', null, [['Jab', [F], 20]]);
P('Lucario', 130, F, 'Stage1', 'Riolu', [['Aura Sphere', [F, C], 90, "This attack also does 20 damage to 1 of your opponent's Benched Pokémon. (Don't apply Weakness and Resistance for Benched Pokémon.)"]]);
P('Onix', 120, F, 'Basic', null, [['Rock Throw', [F, F, C], 90]], { rt: 3 });
P('Hitmonlee', 100, F, 'Basic', null, [['Stretch Kick', [F], 30, "This attack does 30 damage to 1 of your opponent's Benched Pokémon."], ['High Jump Kick', [F, F], 80]]);
P('Gastly', 50, Ps, 'Basic', null, [['Lick', [Ps], 10, "Flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed."]], { rt: 0 });
P('Haunter', 80, Ps, 'Stage1', 'Gastly', [['Hypnosis', [Ps], 0, "Your opponent's Active Pokémon is now Asleep."], ['Dark Mind', [Ps, C], 50]], { rt: 0 });
P('Gengar', 140, Ps, 'Stage2', 'Haunter', [['Shadow Ball', [Ps, Ps], 120, 'Put 2 damage counters on 1 of your opponent\'s Benched Pokémon.']], { rt: 1 });
P('Abra', 50, Ps, 'Basic', null, [['Teleport', [Ps], 10, 'Switch this Pokémon with 1 of your Benched Pokémon.']]);
P('Kadabra', 80, Ps, 'Stage1', 'Abra', [['Psybeam', [Ps], 30, "Your opponent's Active Pokémon is now Confused."]]);
P('Alakazam', 140, Ps, 'Stage2', 'Kadabra', [['Psychic', [Ps, C], 60, "This attack does 30 more damage for each Energy attached to your opponent's Active Pokémon."]]);
P('Drifloon', 70, Ps, 'Basic', null, [['Balloon Blast', [Ps, Ps], 30, 'This attack does 30 damage for each damage counter on this Pokémon.']]);
P('Drifblim', 120, Ps, 'Stage1', 'Drifloon', [['Gust', [Ps, C], 70]]);
// ---- Medio / Difficile
P('Charizard ex', 330, D, 'Stage2', 'Charmeleon', [['Burning Darkness', [R, R], 180, "This attack does 30 more damage for each Prize card your opponent has taken."]], { at: ['OBF', 125], b: [['Infernal Reign', 'When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards and attach them to your Pokémon in any way you like. Then, shuffle your deck.']], rt: 2 });
P('Pidgey', 50, C, 'Basic', null, [['Call for Family', [C], 0, 'Search your deck for up to 2 Basic Pokémon and put them onto your Bench. Then, shuffle your deck.']]);
P('Pidgeotto', 80, C, 'Stage1', 'Pidgey', [['Gust', [C, C], 40]]);
P('Pidgeot ex', 280, C, 'Stage2', 'Pidgeotto', [['Blustery Wind', [C, C], 120, 'You may discard a Stadium in play.']], { at: ['OBF', 164], b: [['Quick Search', "Once during your turn, you may search your deck for a card and put it into your hand. Then, shuffle your deck. You can't use more than 1 Quick Search Ability each turn."]], rt: 0 });
P('Fezandipiti ex', 210, D, 'Basic', null, [['Cruel Arrow', [C, C, C], 0, "This attack does 100 damage to 1 of your opponent's Pokémon. (Don't apply Weakness and Resistance for Benched Pokémon.)"]], { at: ['SFA', 38], b: [['Flip the Script', 'Once during your turn, if any of your Pokémon were Knocked Out during your opponent\'s last turn, you may draw 3 cards.']] });
P('Bidoof', 60, C, 'Basic', null, [['Tackle', [C], 20]]);
P('Bibarel', 120, C, 'Stage1', 'Bidoof', [['Tail Smash', [C, C, C], 100]], { b: [['Industrious Incisors', 'Once during your turn, you may draw cards until you have 5 cards in your hand.']] });
P('Ralts', 70, Ps, 'Basic', null, [['Memory Skip', [C], 10]]);
P('Kirlia', 80, Ps, 'Stage1', 'Ralts', [['Slap', [Ps, C], 30]], { b: [['Refinement', 'Once during your turn, you must discard a card from your hand in order to use this Ability. Draw 2 cards.']] });
P('Gardevoir ex', 310, Ps, 'Stage2', 'Kirlia', [['Miracle Force', [Ps, Ps, C], 190, 'This Pokémon recovers from all Special Conditions.']], { at: ['SVI', 86], b: [['Psychic Embrace', 'As often as you like during your turn, you may attach a Basic Psychic Energy card from your discard pile to 1 of your Psychic Pokémon. If you do, put 2 damage counters on that Pokémon.']], rt: 2 });
P('Scream Tail', 90, Ps, 'Basic', null, [['Slap', [Ps], 30], ['Roaring Scream', [Ps, C], 0, "Choose 1 of your opponent's Pokémon. This attack does 20 damage for each damage counter on this Pokémon to that Pokémon."]]);
P('Munkidori', 110, Ps, 'Basic', null, [['Mind Bend', [Ps, C], 60, "Your opponent's Active Pokémon is now Confused."]], { b: [['Adrena-Brain', "Once during your turn, if this Pokémon has any Darkness Energy attached, you may move up to 3 damage counters from 1 of your Pokémon to 1 of your opponent's Pokémon."]] });
P('Miraidon ex', 220, L, 'Basic', null, [['Photon Blaster', [L, L, C], 220, "During your next turn, this Pokémon can't attack."]], { at: ['SVI', 81], b: [['Tandem Unit', 'Once during your turn, you may search your deck for up to 2 Basic Lightning Pokémon and put them onto your Bench. Then, shuffle your deck.']] });
P('Iron Hands ex', 230, L, 'Basic', null, [['Arm Press', [L, L, C], 160], ['Amp You Very Much', [L, C, C, C], 120, "If your opponent's Pokémon is Knocked Out by damage from this attack, take 1 more Prize card."]], { at: ['PAR', 70], rt: 4 });
P('Mew ex', 180, Ps, 'Basic', null, [['Genome Hacking', [C, C, C], 0, "Choose 1 of your opponent's Active Pokémon's attacks and use it as this attack."]], { at: ['MEW', 151], b: [['Restart', 'Once during your turn, you may draw cards until you have 3 cards in your hand.']], rt: 0 });
P('Roaring Moon ex', 230, D, 'Basic', null, [['Frenzied Gouging', [D, D, C], 0, "Knock Out your opponent's Active Pokémon. If your opponent's Active Pokémon is Knocked Out in this way, this Pokémon does 200 damage to itself."], ['Calamity Storm', [D, D, C], 100, 'You may discard a Stadium in play. If you do, this attack does 120 more damage.']], { at: ['PAR', 124], rt: 3 });
P('Chien-Pao ex', 220, Wa, 'Basic', null, [['Hail Blade', [Wa, Wa], 60, 'You may discard any amount of Water Energy from your Pokémon. This attack does 60 damage for each card you discarded in this way.']], { at: ['PAL', 61], b: [['Shivery Chill', 'Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Basic Water Energy cards, reveal them, and put them into your hand. Then, shuffle your deck.']], rt: 2 });
P('Frigibax', 70, Wa, 'Basic', null, [['Bite', [C], 20]]);
P('Arctibax', 100, Wa, 'Stage1', 'Frigibax', [['Sharp Fin', [Wa, C], 60]]);
P('Baxcalibur', 160, Wa, 'Stage2', 'Arctibax', [['Buster Tail', [Wa, C, C], 130]], { at: ['PAL', 60], b: [['Super Cold', 'As often as you like during your turn, you may attach a Basic Water Energy card from your hand to 1 of your Water Pokémon.']], rt: 3 });
P('Gimmighoul', 70, Ps, 'Basic', null, [['Minor Errand-Running', [C], 0, 'Search your deck for up to 2 Basic Energy cards, reveal them, and put them into your hand. Then, shuffle your deck.'], ['Tackle', [C, C], 50]], { at: ['PAR', 87] });
P('Gholdengo ex', 260, M, 'Stage1', 'Gimmighoul', [['Make It Rain', [M], 0, 'Discard any amount of Basic Energy from your hand. This attack does 50 damage to 1 of your opponent\'s Pokémon for each card you discarded in this way.']], { at: ['PAR', 139], b: [['Coin Bonus', 'Once during your turn, you may draw a card. If this Pokémon is in the Active Spot, draw 1 more card.']], rt: 2 });
P('Dreepy', 70, 'Dragon', 'Basic', null, [['Petty Grudge', [Ps], 10], ['Bite', [R, Ps], 40]], { at: ['TWM', 128], w: [] });
P('Drakloak', 90, 'Dragon', 'Stage1', 'Dreepy', [['Dragon Headbutt', [R, Ps], 70]], { at: ['TWM', 129], w: [], b: [['Recon Directive', 'Once during your turn, you may look at the top 2 cards of your deck and put 1 of them into your hand. Put the other card on the bottom of your deck.']] });
P('Dragapult ex', 320, 'Dragon', 'Stage2', 'Drakloak', [['Jet Headbutt', [C], 70], ['Phantom Dive', [R, Ps], 200, "Put 6 damage counters on your opponent's Benched Pokémon in any way you like."]], { at: ['TWM', 130], w: [] });
P('Duskull', 60, Ps, 'Basic', null, [['Come and Get You', [Ps], 0, 'Put up to 3 Duskull from your discard pile onto your Bench.'], ['Mumble', [Ps, Ps], 30]]);
P('Dusclops', 90, Ps, 'Stage1', 'Duskull', [['Will-O-Wisp', [Ps, Ps], 50]], { b: [['Cursed Blast', "Once during your turn, you may put 5 damage counters on 1 of your opponent's Pokémon. If you placed any damage counters in this way, this Pokémon is Knocked Out."]] });
P('Dusknoir', 160, Ps, 'Stage2', 'Dusclops', [['Shadow Bind', [Ps, Ps, C], 150, "During your opponent's next turn, the Defending Pokémon can't retreat."]], { b: [['Cursed Blast', "Once during your turn, you may put 13 damage counters on 1 of your opponent's Pokémon. If you placed any damage counters in this way, this Pokémon is Knocked Out."]] });
P('Budew', 30, G, 'Basic', null, [['Itchy Pollen', [], 10, "During your opponent's next turn, they can't play any Item cards from their hand."]], { rt: 0 });
P('Raging Bolt ex', 240, 'Dragon', 'Basic', null, [['Burst Roar', [C], 0, 'Discard your hand and draw 6 cards.'], ['Bellowing Thunder', [L, F], 70, 'You may discard any amount of Basic Energy from your Pokémon. This attack does 70 damage for each card you discarded in this way.']], { at: ['TEF', 123], w: [], rt: 3 });
P('Teal Mask Ogerpon ex', 210, G, 'Basic', null, [['Myriad Leaf Shower', [G, G, C], 30, 'This attack does 30 more damage for each Energy attached to both Active Pokémon.']], { at: ['TWM', 25], b: [['Teal Dance', 'Once during your turn, you may attach a Basic Grass Energy card from your hand to this Pokémon. If you attached Energy to a Pokémon in this way, draw a card.']] });
P("Lillie's Clefairy ex", 190, Ps, 'Basic', null, [['Full Moon Rondo', [Ps, C], 20, 'This attack does 20 more damage for each Benched Pokémon (both yours and your opponent\'s).']], { at: ['JTG', 56], b: [['Fairy Zone', "The Weakness of each of your opponent's Dragon Pokémon in play is now Psychic. (Apply Weakness as ×2.)"]] });
P('Hoothoot', 70, C, 'Basic', null, [['Tackle', [C], 20]]);
P('Noctowl', 100, C, 'Stage1', 'Hoothoot', [['Speed Wing', [C, C], 60]], { b: [['Jewel Seeker', 'When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, if you have any Tera Pokémon in play, you may search your deck for up to 2 Trainer cards, reveal them, and put them into your hand. Then, shuffle your deck.']] });
P('Mega Lucario ex', 340, F, 'Stage1', 'Riolu', [['Aura Jab', [F], 130, 'Attach up to 3 Basic Fighting Energy cards from your discard pile to your Benched Pokémon in any way you like.'], ['Mega Brave', [F, F], 270, "During your next turn, this Pokémon can't use Mega Brave."]], { rt: 2 });
P('Makuhita', 80, F, 'Basic', null, [['Slap Down', [F], 30]]);
P('Hariyama', 150, F, 'Stage1', 'Makuhita', [['Wild Press', [F, F, C], 210, 'This Pokémon also does 70 damage to itself.']], { b: [['Heave-Ho Catcher', "When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch in 1 of your opponent's Benched Pokémon to the Active Spot."]] });
P('Solrock', 110, F, 'Basic', null, [['Cosmic Beam', [F], 70, "If you don't have Lunatone on your Bench, this attack does nothing. This attack's damage isn't affected by Weakness or Resistance."]]);
P('Lunatone', 110, F, 'Basic', null, [['Power Gem', [F, F], 50]], { b: [['Lunar Cycle', 'Once during your turn, if you have Solrock in play, you may discard a Basic Fighting Energy card from your hand in order to use this Ability. Draw 3 cards.']] });
P('Terapagos ex', 230, C, 'Basic', null, [['Unified Beatdown', [C, C], 0, "If you go second, this Pokémon can't use this attack during your first turn. This attack does 30 damage for each of your Benched Pokémon."], ['Crown Opal', [G, Wa, L], 180, "During your opponent's next turn, prevent all damage done to this Pokémon by attacks from Basic non-Colorless Pokémon."]], { at: ['SCR', 128], rt: 2 });
P('Duraludon', 130, M, 'Basic', null, [['Hammer In', [M, C], 30], ['Raging Hammer', [M, M, C], 80, 'This attack does 10 more damage for each damage counter on this Pokémon.']], { w: W('Fire') });
P('Archaludon ex', 300, M, 'Stage1', 'Duraludon', [['Metal Defender', [M, M, M], 220, "During your opponent's next turn, this Pokémon has no Weakness."]], { b: [['Assemble Alloy', 'When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach up to 2 Basic Metal Energy cards from your discard pile to your Metal Pokémon in any way you like.']] });

// ---- Allenatori
for (const nm of ["Professor's Research", 'Iono', "Boss's Orders", 'Arven', "Lillie's Determination", 'Crispin', 'Irida', "Professor Sada's Vitality"]) T(nm, 'Supporter', '(effect implemented by hand)');
for (const nm of ['Poké Ball', 'Potion', 'Switch', 'Energy Retrieval', 'Nest Ball', 'Rare Candy', 'Ultra Ball', 'Super Rod', 'Night Stretcher', 'Counter Catcher', 'Prime Catcher',
  'Earthen Vessel', 'Electric Generator', 'Pokégear 3.0', 'Energy Switch', 'Superior Energy Retrieval', 'Buddy-Buddy Poffin', 'Fighting Gong']) T(nm, 'Item', '(effect implemented by hand)', nm === 'Potion' ? 'Pozione' : undefined);
for (const nm of ['Rescue Board', 'Bravery Charm', 'Defiance Band', 'Vitality Band']) T(nm, 'Tool', '(tool)');
for (const nm of ['Artazon', 'Full Metal Lab', 'Area Zero Underdepths']) T(nm, 'Stadium', '(stadium)');
T('Great Ball', 'Item', 'Look at the top 7 cards of your deck. You may reveal a Pokémon you find there and put it into your hand. Shuffle the other cards back into your deck.');
T('Hyper Potion Test', 'Item', 'Heal 120 damage from 1 of your Pokémon. Draw 2 cards.');
// ---- Energie base
for (const t of ['Grass', 'Fire', 'Water', 'Lightning', 'Psychic', 'Fighting', 'Darkness', 'Metal']) cards.push({ i: `sve-${n}`, e: `${t} Energy`, n: `Energia ${t}`, c: 'E', st: 'fx', no: String(n++), im: '', l: 3, et: 'Basic', y: '', x: '' });

fs.writeFileSync(process.argv[2] || 'tools/fixture_cards.json', JSON.stringify({ cards, sets }));
console.log(cards.length, 'carte di prova');
