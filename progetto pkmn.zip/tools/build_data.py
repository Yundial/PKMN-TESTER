#!/usr/bin/env python3
"""Scarica le carte da TCGdex (inglese + italiano) e prepara i dati compatti della web app.

uso:
  python3 tools/build_data.py --out web/data [--cache .tcgdex-cache] [--bots tools/bot_decks.txt]
  python3 tools/build_data.py --out web/data --fixture tools/fixture_cards.json   (prove senza rete)

File prodotti in <out>/:
  cards.json   elenco delle carte (chiavi corte, vedi `compact`)
  sets.json    espansioni con codice di stampa (es. TWM)
  bots.json    mazzi dell'avversario risolti in id di carte
"""
import argparse, json, os, re, sys, time, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor

API = 'https://api.tcgdex.net/v2'
# serie tenute: da Nero e Bianco in poi (formato Expanded + Standard)
SERIES = {'bw', 'xy', 'sm', 'swsh', 'sv', 'me'}
# codici di stampa (Pokémon TCG Live) -> id TCGdex, usati se l'API non li fornisce
CODE_FALLBACK = {
    'SVI': 'sv01', 'PAL': 'sv02', 'OBF': 'sv03', 'MEW': 'sv03.5', 'PAR': 'sv04', 'PAF': 'sv04.5', 'TEF': 'sv05',
    'TWM': 'sv06', 'SFA': 'sv06.5', 'SCR': 'sv07', 'SSP': 'sv08', 'PRE': 'sv08.5', 'JTG': 'sv09', 'DRI': 'sv10',
    'BLK': 'sv10.5b', 'WHT': 'sv10.5w', 'MEG': 'me01', 'PFL': 'me02', 'SVP': 'svp', 'SVE': 'sve',
    'SSH': 'swsh1', 'RCL': 'swsh2', 'DAA': 'swsh3', 'CPA': 'swsh3.5', 'VIV': 'swsh4', 'SHF': 'swsh4.5', 'BST': 'swsh5',
    'CRE': 'swsh6', 'EVS': 'swsh7', 'CEL': 'cel25', 'FST': 'swsh8', 'BRS': 'swsh9', 'ASR': 'swsh10', 'PGO': 'swsh10.5',
    'LOR': 'swsh11', 'SIT': 'swsh12', 'CRZ': 'swsh12.5', 'PR-SW': 'swshp',
}
TYPES = ['Grass', 'Fire', 'Water', 'Lightning', 'Psychic', 'Fighting', 'Darkness', 'Metal', 'Fairy', 'Dragon', 'Colorless']


# ------------------------------------------------------------------ rete con cache su disco
class Fetcher:
    def __init__(self, cache):
        self.cache = cache
        self.hits = self.miss = self.fail = 0
        if cache: os.makedirs(cache, exist_ok=True)

    def get(self, path, required=False, fresh=False):
        f = os.path.join(self.cache, re.sub(r'[^\w.-]', '_', path.strip('/')) + '.json') if self.cache else None
        if f and not fresh and os.path.exists(f):
            self.hits += 1
            with open(f, encoding='utf-8') as fh:
                return json.load(fh)
        last = None
        for attempt in range(5):
            try:
                req = urllib.request.Request(API + path, headers={'User-Agent': 'pkm-tester-build/1.0', 'Accept': 'application/json'})
                with urllib.request.urlopen(req, timeout=40) as r:
                    data = json.loads(r.read().decode('utf-8'))
                self.miss += 1
                if f:
                    with open(f, 'w', encoding='utf-8') as fh: json.dump(data, fh, ensure_ascii=False)
                return data
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    if f:
                        with open(f, 'w', encoding='utf-8') as fh: json.dump(None, fh)
                    return None
                last = e
            except Exception as e:  # rete instabile: riprova
                last = e
            time.sleep(1.5 * (attempt + 1))
        self.fail += 1
        if required: raise RuntimeError(f'{path}: {last}')
        return None


def fetch_all(cache, workers):
    F = Fetcher(cache)
    briefs = F.get('/en/sets', required=True, fresh=True)
    print(f'{len(briefs)} espansioni in TCGdex')
    with ThreadPoolExecutor(workers) as ex:
        full = list(ex.map(lambda b: F.get(f"/en/sets/{b['id']}", fresh=True), briefs))
        sets = [s for s in full if s and (s.get('serie') or {}).get('id') in SERIES]
        it_sets = dict(zip([s['id'] for s in sets], ex.map(lambda s: F.get(f"/it/sets/{s['id']}"), sets)))
    ids = [c['id'] for s in sets for c in s.get('cards') or []]
    print(f'{len(sets)} espansioni tenute, {len(ids)} carte da leggere')
    done = [0]

    def one(cid):
        en = F.get(f'/en/cards/{cid}')
        it = F.get(f'/it/cards/{cid}')
        done[0] += 1
        if done[0] % 2000 == 0: print(f'  {done[0]}/{len(ids)}', flush=True)
        return cid, en, it
    with ThreadPoolExecutor(workers) as ex:
        cards = [x for x in ex.map(one, ids) if x[1]]
    print(f'rete: {F.miss} scaricati, {F.hits} dalla cache, {F.fail} falliti')
    return sets, it_sets, cards


# ------------------------------------------------------------------ formato compatto
def txt(v):
    if v is None: return ''
    if isinstance(v, dict): return v.get('en') or v.get('it') or next(iter(v.values()), '')
    return str(v)


def en_name(v):
    return txt(v).replace('’', "'").replace('‘', "'").strip()


def stage_of(en):
    st = (en.get('stage') or '').replace(' ', '')
    if st in ('Stage1', 'Stage2', 'Basic', 'VMAX', 'VSTAR', 'BREAK', 'LEVEL-UP', 'MEGA', 'VUNION', 'Restored'):
        return st
    return st or 'Basic'


def compact(en, it):
    it = it or {}
    cat = {'Pokemon': 'P', 'Pokémon': 'P', 'Trainer': 'T', 'Energy': 'E'}.get(en.get('category'), 'T')
    s = en.get('set') or {}
    img = it.get('image') or en.get('image') or ''
    c = {'i': en['id'], 'e': en_name(en.get('name')), 'n': txt(it.get('name')) or txt(en.get('name')), 'c': cat,
         'st': s.get('id', ''), 'no': str(en.get('localId', '')), 'im': img}
    if it.get('image') and en.get('image') and it['image'] != en['image']: c['ie'] = en['image']
    if en.get('rarity'): c['ra'] = en['rarity']
    if en.get('regulationMark'): c['rm'] = en['regulationMark']
    lg = en.get('legal') or {}
    c['l'] = (1 if lg.get('standard') else 0) | (2 if lg.get('expanded') else 0)
    if cat == 'P':
        c['hp'] = int(en.get('hp') or 0)
        c['t'] = [t for t in (en.get('types') or []) if t in TYPES] or ['Colorless']
        c['s'] = stage_of(en)
        if en.get('evolveFrom'): c['f'] = en_name(en['evolveFrom'])
        if en.get('suffix'): c['sx'] = en['suffix']
        if en.get('dexId'): c['dx'] = en['dexId']
        ita = {a.get('name'): a for a in (it.get('attacks') or [])}
        ita_list = it.get('attacks') or []
        atk = []
        for k, a in enumerate(en.get('attacks') or []):
            ia = ita_list[k] if k < len(ita_list) else {}
            atk.append({'e': en_name(a.get('name')), 'n': txt(ia.get('name')) or txt(a.get('name')),
                        'c': [x for x in (a.get('cost') or []) if x in TYPES],
                        'd': str(a.get('damage') if a.get('damage') is not None else ''),
                        'y': txt(a.get('effect')), 'x': txt(ia.get('effect')) or txt(a.get('effect'))})
        if atk: c['a'] = atk
        abl = []
        itb = it.get('abilities') or []
        for k, a in enumerate(en.get('abilities') or []):
            ib = itb[k] if k < len(itb) else {}
            abl.append({'e': en_name(a.get('name')), 'n': txt(ib.get('name')) or txt(a.get('name')), 'k': a.get('type', 'Ability'),
                        'y': txt(a.get('effect')), 'x': txt(ib.get('effect')) or txt(a.get('effect'))})
        if abl: c['b'] = abl
        if en.get('weaknesses'): c['w'] = [{'t': w.get('type'), 'v': str(w.get('value') or '×2')} for w in en['weaknesses']]
        if en.get('resistances'): c['r'] = [{'t': w.get('type'), 'v': str(w.get('value') or '-30')} for w in en['resistances']]
        c['rt'] = int(en.get('retreat') or 0)
        if en.get('item'):  # vecchie carte con Poké-Body/strumento incorporato: lo trattiamo come abilità
            c.setdefault('b', []).append({'e': txt(en['item'].get('name')), 'n': txt(en['item'].get('name')), 'k': 'Item', 'y': txt(en['item'].get('effect')), 'x': txt(en['item'].get('effect'))})
    else:
        c['y'] = txt(en.get('effect'))
        c['x'] = txt(it.get('effect')) or c['y']
        if cat == 'T': c['tt'] = en.get('trainerType') or 'Item'
        else: c['et'] = en.get('energyType') or 'Basic'
    return c


def set_code(s):
    ab = s.get('abbreviation') or {}
    if isinstance(ab, dict) and ab.get('official'): return ab['official'].upper()
    if isinstance(s.get('tcgOnline'), str): return s['tcgOnline'].upper()
    for k, v in CODE_FALLBACK.items():
        if v == s['id']: return k
    return ''


# ------------------------------------------------------------------ mazzi dell'avversario
def parse_bot_file(path):
    decks, cur = [], None
    for raw in open(path, encoding='utf-8'):
        l = raw.strip()
        if not l or l.startswith('#'): continue
        if l.startswith('['):
            meta = dict(p.split('=', 1) for p in l.strip('[]').split('|'))
            cur = {'id': meta['id'], 'level': int(meta['level']), 'name': meta['name'], 'desc': meta.get('desc', ''),
                   'cover': meta.get('cover', ''), 'lines': []}
            decks.append(cur)
        else:
            cur['lines'].append(l)
    return decks


ENERGY_SYM = {'G': 'Grass', 'R': 'Fire', 'W': 'Water', 'L': 'Lightning', 'P': 'Psychic', 'F': 'Fighting', 'D': 'Darkness', 'M': 'Metal', 'Y': 'Fairy'}


class Resolver:
    def __init__(self, cards, sets):
        self.by_id = {c['i']: c for c in cards}
        self.code = {s['code']: s['i'] for s in sets if s.get('code')}
        for k, v in CODE_FALLBACK.items(): self.code.setdefault(k, v)
        self.date = {s['i']: s.get('d', '') for s in sets}
        self.by_name = {}
        for c in cards: self.by_name.setdefault(norm(c['e']), []).append(c)

    def best_by_name(self, name):
        lst = self.by_name.get(norm(name)) or []
        if not lst: return None
        # preferisce le stampe legali in Standard, poi le più recenti, poi l'espansione base invece delle promo
        return sorted(lst, key=lambda c: ((c.get('l', 0) & 1), self.date.get(c['st'], ''), not c['st'].endswith('p')), reverse=True)[0]

    def line(self, l):
        """'4 Dreepy TWM 128' oppure '4 Dreepy' -> (quantità, carta)"""
        m = re.match(r'^(\d+)\s+(.+?)(?:\s+([A-Z][A-Z0-9-]{1,6})\s+(\d+[a-z]?))?$', l)
        if not m: return None, None
        n, name, code, num = int(m.group(1)), m.group(2).strip(), m.group(3), m.group(4)
        name = re.sub(r'\{([GRWLPFDMY])\}', lambda x: ENERGY_SYM[x.group(1)], name)
        name = re.sub(r'^Basic\s+', '', name)
        if code and code in self.code:
            sid = self.code[code]
            for cand in (f'{sid}-{num}', f'{sid}-{num.zfill(3)}', f'{sid}-{num.lstrip("0")}'):
                c = self.by_id.get(cand)
                if c and norm(c['e']) == norm(name): return n, c
            c = self.by_id.get(f'{sid}-{num}') or self.by_id.get(f'{sid}-{num.zfill(3)}')
            if c and norm(c['e']).split(' ')[0] == norm(name).split(' ')[0]: return n, c
        return n, self.best_by_name(name)


def norm(s):
    s = (s or '').lower().replace('é', 'e').replace('’', "'").replace('δ', 'delta')
    s = re.sub(r'\s+', ' ', s).strip()
    if s.endswith(' energy'): s = re.sub(r'^basic ', '', s)   # "Basic Fire Energy" = "Fire Energy"
    return s


def build_bots(path, cards, sets):
    R = Resolver(cards, sets)
    out, missing = [], []
    for d in parse_bot_file(path):
        ids = []
        for l in d['lines']:
            n, c = R.line(l)
            if not c: missing.append(f"{d['id']}: {l}"); continue
            ids += [c['i']] * n
        cover = R.best_by_name(d['cover'])['i'] if d['cover'] and R.best_by_name(d['cover']) else (ids[0] if ids else '')
        out.append({'id': d['id'], 'level': d['level'], 'name': d['name'], 'desc': d['desc'], 'cover': cover, 'cards': ids})
        if len(ids) != 60: print(f"  attenzione: il mazzo {d['id']} ha {len(ids)} carte")
    for m in missing: print('  carta non trovata:', m)
    return out


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--cache', default='.tcgdex-cache')
    ap.add_argument('--bots', default=os.path.join(os.path.dirname(__file__), 'bot_decks.txt'))
    ap.add_argument('--fixture', help='file json con carte già in formato compatto (prove senza rete)')
    ap.add_argument('--workers', type=int, default=16)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    if a.fixture:
        fx = json.load(open(a.fixture, encoding='utf-8'))
        cards, sets = fx['cards'], fx['sets']
    else:
        raw_sets, it_sets, raw_cards = fetch_all(a.cache, a.workers)
        sets = []
        for s in raw_sets:
            its = it_sets.get(s['id']) or {}
            sets.append({'i': s['id'], 'e': s.get('name', ''), 'n': its.get('name') or s.get('name', ''), 'code': set_code(s),
                         'd': s.get('releaseDate', ''), 'sr': (s.get('serie') or {}).get('id', ''), 'tot': (s.get('cardCount') or {}).get('official', 0)})
        cards = []
        for cid, en, it in raw_cards:
            try: cards.append(compact(en, it))
            except Exception as e: print('  carta saltata', cid, e)
        if len(cards) < 1000: sys.exit(f'Troppe poche carte ({len(cards)}): TCGdex non risponde?')

    order = {s['i']: k for k, s in enumerate(sorted(sets, key=lambda s: s.get('d', '')))}
    cards.sort(key=lambda c: (order.get(c['st'], 0), c['st'], int(re.sub(r'\D', '', c['no']) or 0), c['no']))
    with open(os.path.join(a.out, 'cards.json'), 'w', encoding='utf-8') as f:
        json.dump(cards, f, ensure_ascii=False, separators=(',', ':'))
    with open(os.path.join(a.out, 'sets.json'), 'w', encoding='utf-8') as f:
        json.dump(sets, f, ensure_ascii=False, separators=(',', ':'))
    bots = build_bots(a.bots, cards, sets) if os.path.exists(a.bots) else []
    with open(os.path.join(a.out, 'bots.json'), 'w', encoding='utf-8') as f:
        json.dump(bots, f, ensure_ascii=False, separators=(',', ':'))
    ita = sum(1 for c in cards if c['n'] != c['e'])
    print(f'{len(cards)} carte ({ita} con nome italiano diverso), {len(sets)} espansioni, {len(bots)} mazzi avversari -> {a.out}')


if __name__ == '__main__':
    main()
