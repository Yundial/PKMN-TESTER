// Banco di prova del motore: fa giocare i bot tra loro con tutti i mazzi avversari e controlla che nulla si blocchi.
// uso: node tools/test_engine.mjs <cartella dati (cards.json, bots.json)> [partite per mazzo] [livello]
import fs from 'node:fs';
import path from 'node:path';
import { Game } from '../web/js/engine/core.js';
import { LIB } from '../web/js/engine/effects.js';
import { BotAgent } from '../web/js/engine/bot.js';

const dir = process.argv[2] || 'web/data';
const per = +(process.argv[3] || 2);
const onlyLevel = process.argv[4] != null ? +process.argv[4] : null;
const cards = JSON.parse(fs.readFileSync(path.join(dir, 'cards.json'), 'utf8'));
const bots = JSON.parse(fs.readFileSync(path.join(dir, 'bots.json'), 'utf8'));
const byId = new Map(cards.map(c => [c.i, c]));
const db = id => byId.get(id) || null;
LIB.setCards(cards);

function countCards(g, pl) {
  const p = g.P(pl);
  let n = p.deck.length + p.hand.length + p.discard.length + p.prizes.length + p.lost.length;
  for (const sl of g.slots(pl)) n += sl.cards.length + sl.energy.length + sl.tools.length;
  if (g.s.stadium && g.ownerOf(g.s.stadium.uid) === pl) n++;
  return n;
}

let games = 0, errors = 0, draws = 0, totalTurns = 0;
const wins = {}, manual = new Map();
const t0 = Date.now();
for (const a of bots) {
  for (let k = 0; k < per; k++) {
    const b = bots[(bots.indexOf(a) + 1 + k * 3) % bots.length];
    const lvA = onlyLevel ?? Math.min(3, a.level + (k % 2)), lvB = onlyLevel ?? b.level;
    const g = Game.create(db, LIB, [a.cards, b.cards], [a.name, b.name], { seed: 1000 + games * 7919 });
    g.agents = [new BotAgent(lvA), new BotAgent(lvB)];
    g.sim = false;
    try {
      await g.run();
      for (const pl of [0, 1]) {
        const n = countCards(g, pl);
        if (n !== 60) throw new Error(`il giocatore ${pl} ha ${n} carte invece di 60`);
      }
      games++;
      totalTurns += g.s.turn;
      if (g.s.winner === -1) draws++;
      else { const w = g.s.winner === 0 ? a.id : b.id; wins[w] = (wins[w] || 0) + 1; }
      for (const m of g.manualNotes) manual.set(m.card + ' / ' + m.what, m.text);
      if (process.env.VERBOSE) console.log(`${a.id}(L${lvA}) vs ${b.id}(L${lvB}): turni ${g.s.turn}, ${g.s.winner === -1 ? 'pareggio' : 'vince ' + g.P(g.s.winner).name} – ${g.s.reason}`);
    } catch (e) {
      errors++;
      console.log(`ERRORE ${a.id} vs ${b.id} (turno ${g.s.turn}): ${e.stack}`);
      console.log(g.s.log.slice(-15).join('\n'));
    }
  }
}
console.log(`\n${games} partite completate, ${errors} errori, ${draws} pareggi, media ${(totalTurns / Math.max(1, games)).toFixed(1)} turni, ${((Date.now() - t0) / 1000).toFixed(1)} s`);
console.log('vittorie:', Object.entries(wins).sort((x, y) => y[1] - x[1]).map(([k, v]) => `${k} ${v}`).join(', '));
if (manual.size) {
  console.log(`\neffetti non automatici incontrati (${manual.size}):`);
  for (const [k, v] of [...manual].slice(0, 40)) console.log(` - ${k}: ${v}`);
}
process.exit(errors ? 1 : 0);
